
CREATE TABLE IF NOT EXISTS public.titan_approvals(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 plan_id TEXT NOT NULL,
 action_id TEXT NOT NULL,
 scope JSONB NOT NULL DEFAULT '{}'::jsonb,
 approved_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 expires_at TIMESTAMPTZ,
 revoked_at TIMESTAMPTZ,
 revocation_reason TEXT,
 source_device_id TEXT,
 created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_titan_approvals_lookup ON public.titan_approvals(user_id,plan_id,action_id,approved_at DESC);
CREATE INDEX IF NOT EXISTS idx_titan_approvals_active ON public.titan_approvals(user_id,expires_at,revoked_at);
ALTER TABLE public.titan_approvals ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS titan_approvals_owner_all ON public.titan_approvals;
CREATE POLICY titan_approvals_owner_all ON public.titan_approvals FOR ALL TO authenticated
 USING(user_id=auth.uid() OR public.is_admin())
 WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());

ALTER TABLE public.titan_action_runs
 ADD COLUMN IF NOT EXISTS next_retry_at TIMESTAMPTZ,
 ADD COLUMN IF NOT EXISTS last_error_code TEXT,
 ADD COLUMN IF NOT EXISTS last_error_message TEXT,
 ADD COLUMN IF NOT EXISTS resume_metadata JSONB NOT NULL DEFAULT '{}'::jsonb;

NOTIFY pgrst,'reload schema';
