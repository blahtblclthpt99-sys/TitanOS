# TitanOS Staging Verification

Run only against a non-production staging deployment first.

Required:
- `TITAN_STAGING_URL`
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- server-side `SUPABASE_SERVICE_ROLE_KEY` for deployed functions

Verification sequence:
1. apply migrations in timestamp order
2. inspect RLS policies on Titan action-run, approvals, idempotency and audit tables
3. deploy server functions
4. run `node scripts/verify-titan-deployment-env.mjs`
5. run `node scripts/verify-titan-staging.mjs`
6. exercise a low-risk job-creation workflow
7. retry the same idempotency key and verify no duplicate job
8. revoke/expire approval and verify server refuses execution
9. exercise recovery on a second device/session
10. configure external providers only after the control plane passes
