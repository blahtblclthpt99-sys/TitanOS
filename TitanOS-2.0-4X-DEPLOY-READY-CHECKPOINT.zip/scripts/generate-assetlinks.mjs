
import fs from"node:fs";
const pkg="com.titanos.myapp";
const fingerprints=String(process.env.TITAN_ANDROID_SHA256_FINGERPRINTS||"")
 .split(",").map(x=>x.trim()).filter(Boolean);
if(!fingerprints.length){
 console.error("BLOCKED: set TITAN_ANDROID_SHA256_FINGERPRINTS to the Play signing SHA-256 fingerprint(s).");
 process.exit(2);
}
const data=[{
 relation:["delegate_permission/common.handle_all_urls"],
 target:{
  namespace:"android_app",
  package_name:pkg,
  sha256_cert_fingerprints:fingerprints
 }
}];
fs.mkdirSync("public/.well-known",{recursive:true});
fs.writeFileSync("public/.well-known/assetlinks.json",JSON.stringify(data,null,2)+"\n");
console.log(`Generated assetlinks.json for ${pkg} with ${fingerprints.length} fingerprint(s).`);
