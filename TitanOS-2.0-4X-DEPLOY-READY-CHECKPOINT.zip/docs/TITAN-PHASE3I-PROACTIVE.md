# TitanOS 2.0 — Phase 3I Proactive Titan

Titan evaluates open loops and surfaces only the few items that genuinely deserve attention.

Initial sources:
- overdue invoices
- expiring credentials
- stale/open jobs needing follow-up
- vehicle service deadlines
- explicit user promises/open loops
- opportunity inbox (already implemented separately)

Principles:
- default digest cap: 3 items
- urgency threshold before surfacing
- notification cooldowns to prevent nagging
- every item explains why Titan surfaced it
- opening/dismissing/resolving becomes feedback
- "What am I forgetting?" is a first-class Invisible Interface command
- proactive detection does not automatically execute consequential actions
