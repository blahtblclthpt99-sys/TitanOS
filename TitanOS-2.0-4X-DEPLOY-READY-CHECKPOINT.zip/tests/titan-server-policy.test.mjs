
import test from"node:test";
import assert from"node:assert/strict";
import{requiresServerExecution,serverCanExecute,approvalRequired,requiredApprovalScope}from"../api/_lib/titanServerPolicy.js";

test("money never executes client side",()=>{
 assert.equal(requiresServerExecution("money.pay"),true);
 assert.equal(serverCanExecute("money.pay"),false);
 assert.equal(approvalRequired("money.pay"),true);
});
test("job creation is server executable and approved",()=>{
 assert.equal(serverCanExecute("jobs.create"),true);
 assert.equal(approvalRequired("jobs.create"),true);
});
test("payment scope binds amount and recipient",()=>{
 assert.deepEqual(requiredApprovalScope("money.pay",{recipient_id:"r",amount:25}),{recipient_id:"r",amount:25,currency:"USD"});
});
