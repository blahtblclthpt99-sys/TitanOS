# TitanOS 2.0 — Phase 3H Opportunity Inbox

Users define what they want once. Titan stores watches and checks for meaningful new/improved matches.

Rules:
- suppress previously passed/saved/applied opportunities
- deduplicate by stable opportunity key
- surface only strong new matches or materially improved matches
- keep fit score and listing confidence separate
- allow watches to be enabled/disabled at any time
- manual "Check now" is available immediately
- recurring background execution should be scheduled server-side; the client does not pretend to monitor when closed
- reactions become preference evidence, not universal capability judgments
