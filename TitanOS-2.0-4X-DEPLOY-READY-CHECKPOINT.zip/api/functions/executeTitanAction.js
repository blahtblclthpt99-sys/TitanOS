
import{applyCors,handleOptions}from"../_lib/cors.js";
import{getSupabaseAdmin,readJson}from"../_lib/supabase.js";
import{assertRateLimitAsync}from"../_lib/rateLimit.js";
import{approvalRequired,requiredApprovalScope,serverCanExecute,validateActionRequest}from"../_lib/titanServerPolicy.js";

const bearer=req=>String(req.headers.authorization||"").replace(/^Bearer\s+/i,"");

function scopeMatches(granted={},required={}){
 for(const [key,value]of Object.entries(required||{})){
  if(value==null)continue;
  if(granted?.[key]!==value)return false;
 }
 return true;
}

async function findApproval(admin,{userId,planId,actionId,requiredScope}){
 const now=new Date().toISOString();
 const{data,error}=await admin.from("titan_approvals").select("*")
  .eq("user_id",userId).eq("plan_id",planId).eq("action_id",actionId)
  .is("revoked_at",null).order("approved_at",{ascending:false}).limit(20);
 if(error)throw error;
 return(data||[]).find(a=>(!a.expires_at||a.expires_at>now)&&scopeMatches(a.scope||{},requiredScope))||null;
}

async function existingResult(admin,userId,key){
 const{data,error}=await admin.from("titan_action_idempotency").select("*").eq("user_id",userId).eq("idempotency_key",key).limit(1);
 if(error)throw error;
 return data?.[0]||null;
}

async function storeResult(admin,userId,key,planId,actionId,result){
 const{error}=await admin.from("titan_action_idempotency").insert({
  user_id:userId,idempotency_key:key,plan_id:planId,action_id:actionId,result,created_by_id:userId
 });
 if(error&&error.code!=="23505")throw error;
}

async function executeAllowed(admin,userId,tool,payload){
 if(tool==="jobs.create"){
  const row={
   title:String(payload.title||"Titan job").slice(0,200),
   customer_id:payload.customer_id||null,
   scheduled_date:payload.scheduled_date||null,
   status:payload.status||"scheduled",
   notes:String(payload.notes||"Created by Titan").slice(0,4000),
   created_by_id:userId
  };
  const{data,error}=await admin.from("jobs").insert(row).select().single();
  if(error)throw error;
  return{success:true,summary:`Created job ${data.title||data.id}.`,data:{job:data}};
 }
 if(tool==="titan.rules.create"){
  const row={
   user_id:userId,
   name:String(payload.name||payload.command||"Titan rule").slice(0,120),
   command:String(payload.command||"").slice(0,4000),
   trigger_type:payload.trigger_type||"manual",
   conditions:payload.conditions||{},
   actions:payload.actions||[],
   enabled:payload.enabled!==false,
   requires_approval:Boolean(payload.requires_approval),
   created_by_id:userId
  };
  const{data,error}=await admin.from("titan_rules").insert(row).select().single();
  if(error)throw error;
  return{success:true,summary:"Persistent Titan rule created.",data:{rule:data}};
 }
 return{success:false,summary:"This action requires a provider-specific trusted server integration.",data:{integration_required:tool}};
}

export default async function handler(req,res){
 if(handleOptions(req,res))return;
 applyCors(req,res);
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 if(!(await assertRateLimitAsync(req,res,{key:"titan-server-action",limit:30,windowMs:60000})))return;
 try{
  const admin=getSupabaseAdmin();
  const{data:u,error:e}=await admin.auth.getUser(bearer(req));
  if(e||!u?.user)return res.status(401).json({error:"Unauthorized"});
  const user=u.user,body=readJson(req),tool=String(body.tool||"");
  const validation=validateActionRequest({tool,plan_id:body.plan_id,action_id:body.action_id,user_id:user.id});
  if(!validation.ok)return res.status(400).json({error:validation.errors.join(", ")});
  if(!body.idempotency_key)return res.status(400).json({error:"idempotency_key required"});

  const prior=await existingResult(admin,user.id,body.idempotency_key);
  if(prior)return res.status(200).json({...prior.result,idempotent_replay:true});

  const scope=requiredApprovalScope(tool,body.payload||{});
  if(approvalRequired(tool)){
   const approval=await findApproval(admin,{userId:user.id,planId:body.plan_id,actionId:body.action_id,requiredScope:scope});
   if(!approval)return res.status(403).json({error:"Valid scoped approval required",code:"approval_required"});
  }

  const result=serverCanExecute(tool)
   ?await executeAllowed(admin,user.id,tool,body.payload||{})
   :{success:false,summary:"Trusted integration is not connected for this action.",data:{integration_required:tool}};

  await storeResult(admin,user.id,body.idempotency_key,body.plan_id,body.action_id,result);
  return res.status(200).json(result);
 }catch(error){
  return res.status(500).json({error:error?.message||"Server action failed"});
 }
}
