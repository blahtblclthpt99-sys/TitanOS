
import fs from"node:fs";
const fail=[],read=f=>fs.readFileSync(f,"utf8");
const migrations=fs.readdirSync("supabase/migrations").filter(x=>x.endsWith(".sql")).sort();
for(const f of["20260813150000_production_action_runs.sql","20260813160000_permission_recovery.sql","20260813170000_server_execution_control_plane.sql"]){
 if(!migrations.includes(f))fail.push(`missing migration ${f}`);
 const s=migrations.includes(f)?read(`supabase/migrations/${f}`):"";
 if(s&&!/ENABLE ROW LEVEL SECURITY/i.test(s))fail.push(`${f}: no RLS enable`);
}
const tabs=read("src/components/layout/TabStack.jsx");
for(const route of["/titan-action","/titan-activity","/titan-recovery","/work-network","/opportunity-inbox","/threads","/multimodal-review"]){
 if(!tabs.includes(`"${route}"`))fail.push(`route missing ${route}`);
}
const entity=read("src/api/entityTables.js");
for(const name of["TitanActionRun","TitanApproval","TitanExecutionAudit","TitanThread","TitanMemoryNode"]){
 if(!entity.includes(name))fail.push(`entity map missing ${name}`);
}
const adapter=read("src/lib/titanToolAdapters.js");
for(const tool of["jobs.create","money.pay","external.apply","titan.rules.create"]){
 if(!adapter.includes(`"${tool}"`))fail.push(`adapter missing ${tool}`);
}
if(!adapter.includes("executeServerAction"))fail.push("trusted server execution bridge missing");
if(fail.length){console.error(fail.join("\n"));process.exit(1)}
console.log(`Titan release integrity passed (${migrations.length} migrations checked).`);
