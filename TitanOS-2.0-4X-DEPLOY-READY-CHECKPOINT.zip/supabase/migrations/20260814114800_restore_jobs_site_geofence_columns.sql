ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS site_lat double precision;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS site_lng double precision;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS geofence_m integer NOT NULL DEFAULT 150;
ALTER TABLE public.jobs DROP CONSTRAINT IF EXISTS jobs_site_lat_range;
ALTER TABLE public.jobs ADD CONSTRAINT jobs_site_lat_range CHECK (site_lat IS NULL OR site_lat BETWEEN -90 AND 90);
ALTER TABLE public.jobs DROP CONSTRAINT IF EXISTS jobs_site_lng_range;
ALTER TABLE public.jobs ADD CONSTRAINT jobs_site_lng_range CHECK (site_lng IS NULL OR site_lng BETWEEN -180 AND 180);
ALTER TABLE public.jobs DROP CONSTRAINT IF EXISTS jobs_geofence_m_range;
ALTER TABLE public.jobs ADD CONSTRAINT jobs_geofence_m_range CHECK (geofence_m BETWEEN 25 AND 5000);
