
import test from "node:test";
import assert from "node:assert/strict";
import { scoreOpportunityMatch, rankOpportunities } from "../src/lib/workMatchEngine.js";

const profile = { city:"Oklahoma City", state:"OK", minimum_hourly:20, availability_status:"open", remote_ok:false };
const skills = [
  { name:"Route delivery", confidence:92, visible_to_matches:true },
  { name:"Box truck", confidence:88, visible_to_matches:true },
];
test("strong matching work ranks highly", () => {
  const m = scoreOpportunityMatch(profile, skills, { required_skills:["Route delivery","Box truck"], city:"Oklahoma City", state:"OK", pay_type:"hourly", pay_max:24 });
  assert.ok(m.overall >= 85);
  assert.equal(m.missingRequired.length, 0);
});
test("missing required skills are explainable", () => {
  const m = scoreOpportunityMatch(profile, skills, { required_skills:["Electrical"], city:"Oklahoma City", state:"OK" });
  assert.deepEqual(m.missingRequired, ["electrical"]);
  assert.ok(m.overall < 80);
});
test("pay below preference reduces score", () => {
  const low = scoreOpportunityMatch(profile, skills, { required_skills:["Box truck"], city:"Oklahoma City", state:"OK", pay_type:"hourly", pay_max:10 });
  const good = scoreOpportunityMatch(profile, skills, { required_skills:["Box truck"], city:"Oklahoma City", state:"OK", pay_type:"hourly", pay_max:25 });
  assert.ok(good.overall > low.overall);
});
test("ranker sorts best match first", () => {
  const rows = rankOpportunities(profile, skills, [
    { id:"bad", required_skills:["Electrical"], city:"Tulsa", state:"OK" },
    { id:"good", required_skills:["Box truck"], city:"Oklahoma City", state:"OK", pay_type:"hourly", pay_max:25 },
  ]);
  assert.equal(rows[0].opportunity.id, "good");
});
