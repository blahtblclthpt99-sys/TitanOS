import React, { useState } from "react";
import { ShieldCheck, Plus } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import PageHeader from "@/components/shared/PageHeader";
import PageShell from "@/components/shared/PageShell";
import PageLoader from "@/components/shared/PageLoader";
import ErrorState from "@/components/shared/ErrorState";
import EmptyState from "@/components/shared/EmptyState";
import FormField from "@/components/shared/FormField";
import DeleteButton from "@/components/shared/DeleteButton";
import FeatureHonestyBanner from "@/components/shared/FeatureHonestyBanner";
import SyncStatus from "@/components/shared/SyncStatus";
import { useSafeAsync } from "@/hooks/useSafeAsync";
import { getSource, DATA_SOURCE } from "@/lib/dataSource";
import {
  confirmEscrowSide,
  createEscrowHold,
  deleteEscrowHold,
  listEscrowHolds,
  updateEscrowHold,
} from "@/lib/escrowApi";
import { toastDone, toastFail, toastInfo } from "@/lib/interaction";

export default function Escrow() {
  const { user } = useAuth();
  const { data: rows = [], setData: setRows, loading, error, reload } = useSafeAsync(
    () => listEscrowHolds(user.id),
    [user?.id],
    { enabled: Boolean(user?.id), initial: [] }
  );
  const [form, setForm] = useState({ customer_name: "", job_title: "", amount: "" });
  const [saving, setSaving] = useState(false);
  const [rowBusy, setRowBusy] = useState(null); // `${id}:action`
  const deviceOnly = getSource(rows) === DATA_SOURCE.local;

  const add = async (e) => {
    e.preventDefault();
    if (saving || !form.customer_name || !Number(form.amount)) return;
    setSaving(true);
    try {
      const row = await createEscrowHold(user, form);
      setRows((current) => [row, ...current]);
      setForm({ customer_name: "", job_title: "", amount: "" });
      if (getSource(row) === DATA_SOURCE.local) {
        toastInfo("Hold saved on this device only", "Demo status tracking — no funds are held.");
      } else {
        toastDone("Hold record created");
      }
    } catch (error) {
      toastFail("Couldn't create hold", error?.message || "Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const confirm = async (row, side) => {
    const key = `${row.id}:confirm:${side}`;
    if (rowBusy) return;
    setRowBusy(key);
    try {
      const saved = await confirmEscrowSide(user.id, row, side);
      setRows((current) => current.map((r) => (r.id === row.id ? saved : r)));
      toastDone(side === "customer" ? "Customer confirmed" : "Confirmed done");
    } catch {
      toastFail("Couldn't confirm");
    } finally {
      setRowBusy(null);
    }
  };

  const refund = async (row) => {
    const key = `${row.id}:refund`;
    if (rowBusy) return;
    setRowBusy(key);
    try {
      const saved = await updateEscrowHold(user.id, row.id, { status: "refunded" });
      setRows((current) => current.map((r) => (r.id === row.id ? saved : r)));
      toastDone("Marked refunded");
    } catch {
      toastFail("Couldn't update hold");
    } finally {
      setRowBusy(null);
    }
  };

  if (loading) return <PageLoader variant="list" label="Loading job holds" />;
  if (error) return <ErrorState title="Couldn't load job holds" onRetry={reload} />;

  return (
    <PageShell maxWidth="md">
      <PageHeader
        title="Job holds"
        subtitle="Status tracking only — TitanOS does not move or hold real funds yet."
        breadcrumbs={[
          { label: "More", to: "/more" },
          { label: "Labs" },
          { label: "Job holds" },
        ]}
      />
      <FeatureHonestyBanner>
        Practice hold records only. Confirms do not charge cards or release money. Real escrow needs Stripe
        Connect (or similar) before this can go live.
      </FeatureHonestyBanner>
      {deviceOnly ? <SyncStatus source={DATA_SOURCE.local} className="mb-4" /> : null}
      <form onSubmit={add} className="titan-surface p-5 mb-5 space-y-3">
        <div className="flex items-center gap-2 text-primary font-semibold text-sm">
          <ShieldCheck className="w-5 h-5" aria-hidden="true" /> New job hold
        </div>
        <div className="grid sm:grid-cols-3 gap-3">
          <FormField
            label="Customer"
            required
            value={form.customer_name}
            onChange={(e) => setForm({ ...form, customer_name: e.target.value })}
            placeholder="Customer name"
          />
          <FormField
            label="Job title"
            value={form.job_title}
            onChange={(e) => setForm({ ...form, job_title: e.target.value })}
            placeholder="Job title"
          />
          <FormField
            label="Amount ($)"
            required
            type="number"
            step="0.01"
            value={form.amount}
            onChange={(e) => setForm({ ...form, amount: e.target.value })}
            placeholder="0.00"
          />
        </div>
        <Button type="submit" disabled={saving} className="gap-2">
          <Plus className="w-4 h-4" aria-hidden="true" /> {saving ? "Creating…" : "Create hold record"}
        </Button>
      </form>
      <div className="space-y-3">
        {rows.map((row) => (
          <article key={row.id} className="titan-surface p-4">
            <div className="flex flex-wrap justify-between gap-2">
              <div>
                <p className="font-semibold text-foreground">{row.customer_name}</p>
                <p className="text-sm text-muted-foreground">{row.job_title || "Protected job"}</p>
              </div>
              <div className="text-right flex items-start gap-1">
                <div>
                  <p className="text-xl font-bold text-foreground">${Number(row.amount || 0).toLocaleString()}</p>
                  <p className="text-xs capitalize text-primary">{row.status}</p>
                </div>
                <DeleteButton
                  label={`hold for ${row.customer_name}`}
                  disabled={Boolean(rowBusy)}
                  successTitle="Hold deleted"
                  onDelete={async () => {
                    if (rowBusy) return;
                    setRowBusy(`${row.id}:delete`);
                    try {
                      await deleteEscrowHold(user.id, row.id);
                      setRows((prev) => prev.filter((r) => r.id !== row.id));
                    } finally {
                      setRowBusy(null);
                    }
                  }}
                />
              </div>
            </div>
            <div className="flex flex-wrap gap-2 mt-3 text-xs">
              <span className={row.customer_confirmed ? "text-success" : "text-muted-foreground"}>
                Customer {row.customer_confirmed ? "confirmed" : "pending"}
              </span>
              <span className={row.provider_confirmed ? "text-success" : "text-muted-foreground"}>
                You {row.provider_confirmed ? "confirmed" : "pending"}
              </span>
            </div>
            {row.status === "held" && (
              <div className="flex flex-wrap gap-2 mt-3">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={Boolean(rowBusy)}
                  onClick={() => confirm(row, "customer")}
                >
                  {rowBusy === `${row.id}:confirm:customer` ? "Saving…" : "Customer confirms"}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={Boolean(rowBusy)}
                  onClick={() => confirm(row, "provider")}
                >
                  {rowBusy === `${row.id}:confirm:provider` ? "Saving…" : "I confirm done"}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={Boolean(rowBusy)}
                  onClick={() => refund(row)}
                >
                  {rowBusy === `${row.id}:refund` ? "Saving…" : "Mark refunded"}
                </Button>
              </div>
            )}
          </article>
        ))}
        {!rows.length && (
          <EmptyState
            icon={ShieldCheck}
            title="No job holds yet"
            description="Create a hold record for large jobs so both sides can confirm completion."
          />
        )}
      </div>
    </PageShell>
  );
}
