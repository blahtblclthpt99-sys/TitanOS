
import test from"node:test";import assert from"node:assert/strict";
import{canExecuteAction}from"../src/lib/titanActionEngine.js";
test("approval still gates critical execution",()=>{const a={requiresApproval:true,id:"x"};assert.equal(canExecuteAction(a,[]),false);assert.equal(canExecuteAction(a,["x"]),true);});
test("non consequential action can execute without approval",()=>assert.equal(canExecuteAction({requiresApproval:false,id:"x"},[]),true));
