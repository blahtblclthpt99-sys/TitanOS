CREATE TABLE IF NOT EXISTS public.legacy_demo_purge_archive (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  archived_at timestamptz NOT NULL DEFAULT now(),
  source_file text NOT NULL,
  target_table text NOT NULL,
  target_id text NOT NULL,
  source_id text,
  payload jsonb
);
ALTER TABLE public.legacy_demo_purge_archive ENABLE ROW LEVEL SECURITY;

INSERT INTO public.legacy_demo_purge_archive(source_file,target_table,target_id,source_id,payload)
SELECT source_file,target_table,target_id,source_id,payload
FROM public.legacy_import_id_map
WHERE source_file IN ('Customer_export.csv','Job_export.csv','Invoice_export.csv','Expense_export.csv','Vehicle_export.csv');

DELETE FROM public.jobs j USING public.legacy_import_id_map m
WHERE m.source_file='Job_export.csv' AND m.target_table='jobs' AND j.id::text=m.target_id;
DELETE FROM public.invoices i USING public.legacy_import_id_map m
WHERE m.source_file='Invoice_export.csv' AND m.target_table='invoices' AND i.id::text=m.target_id;
DELETE FROM public.expenses e USING public.legacy_import_id_map m
WHERE m.source_file='Expense_export.csv' AND m.target_table='expenses' AND e.id::text=m.target_id;
DELETE FROM public.equipment e USING public.legacy_import_id_map m
WHERE m.source_file='Vehicle_export.csv' AND m.target_table='equipment' AND e.id::text=m.target_id;
DELETE FROM public.customers c USING public.legacy_import_id_map m
WHERE m.source_file='Customer_export.csv' AND m.target_table='customers' AND c.id::text=m.target_id;
DELETE FROM public.legacy_import_id_map
WHERE source_file IN ('Customer_export.csv','Job_export.csv','Invoice_export.csv','Expense_export.csv','Vehicle_export.csv');
