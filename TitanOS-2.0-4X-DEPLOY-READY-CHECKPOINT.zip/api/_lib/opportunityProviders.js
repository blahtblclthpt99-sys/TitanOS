
function cleanText(value, max = 4000) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, max);
}
function numberOrNull(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}
function arr(value) { return Array.isArray(value) ? value : []; }

export function normalizeProviderJob(raw = {}, provider = {}) {
  return {
    external_id: cleanText(raw.external_id || raw.id || raw.job_id, 200) || null,
    source_type: provider.type || "job_provider",
    source_name: provider.name || "External provider",
    source_url: raw.source_url || raw.url || raw.job_url || null,
    canonical_url: raw.canonical_url || raw.apply_url || raw.job_apply_link || raw.url || null,
    title: cleanText(raw.title || raw.job_title || raw.role, 300) || "Untitled opportunity",
    company: cleanText(raw.company || raw.employer || raw.employer_name, 300),
    description: cleanText(raw.description || raw.job_description, 8000),
    city: cleanText(raw.city || raw.job_city, 120),
    state: cleanText(raw.state || raw.job_state, 80),
    remote_ok: Boolean(raw.remote_ok || raw.is_remote),
    employment_type: cleanText(raw.employment_type || raw.job_employment_type, 80) || null,
    pay_min: numberOrNull(raw.pay_min || raw.min_salary),
    pay_max: numberOrNull(raw.pay_max || raw.max_salary),
    pay_type: cleanText(raw.pay_type || raw.salary_period, 40) || null,
    required_skills: arr(raw.required_skills || raw.skills),
    preferred_skills: arr(raw.preferred_skills),
    posted_at: raw.posted_at || raw.job_posted_at_datetime_utc || null,
    expires_at: raw.expires_at || raw.job_offer_expiration_datetime_utc || null,
    fetched_at: new Date().toISOString(),
    provenance: {
      provider: provider.name || "External provider",
      original_url: raw.url || raw.source_url || raw.job_url || null,
      employer_domain: raw.employer_domain || null,
    },
  };
}

export function configuredProviders(env = process.env) {
  const providers = [];
  // Generic provider contract: configure an approved JSON search endpoint.
  // The URL must be fixed in server environment, never supplied by the client.
  if (env.TITAN_JOB_FEED_URL) {
    providers.push({
      name: env.TITAN_JOB_FEED_NAME || "Configured Job Feed",
      type: env.TITAN_JOB_FEED_TYPE || "job_provider",
      url: env.TITAN_JOB_FEED_URL,
      token: env.TITAN_JOB_FEED_TOKEN || "",
    });
  }
  if (env.TITAN_JOB_FEED_2_URL) {
    providers.push({
      name: env.TITAN_JOB_FEED_2_NAME || "Configured Job Feed 2",
      type: env.TITAN_JOB_FEED_2_TYPE || "job_provider",
      url: env.TITAN_JOB_FEED_2_URL,
      token: env.TITAN_JOB_FEED_2_TOKEN || "",
    });
  }
  return providers;
}

export async function searchConfiguredProvider(provider, query = {}) {
  const url = new URL(provider.url);
  if (query.role) url.searchParams.set("role", String(query.role).slice(0, 160));
  if (query.location) url.searchParams.set("location", String(query.location).slice(0, 160));
  if (query.employment_type) url.searchParams.set("employment_type", String(query.employment_type).slice(0, 80));
  if (query.page) url.searchParams.set("page", String(Math.max(1, Number(query.page) || 1)));

  const headers = { Accept: "application/json" };
  if (provider.token) headers.Authorization = `Bearer ${provider.token}`;

  const response = await fetch(url, { headers, signal: AbortSignal.timeout(10000) });
  if (!response.ok) throw new Error(`${provider.name} returned ${response.status}`);
  const body = await response.json();
  const rows = Array.isArray(body) ? body : Array.isArray(body.jobs) ? body.jobs : Array.isArray(body.results) ? body.results : [];
  return rows.slice(0, 100).map((row) => normalizeProviderJob(row, provider));
}
