
import test from"node:test";
import assert from"node:assert/strict";
import fs from"node:fs";

test("run api uses POST operation contract",()=>{
 const s=fs.readFileSync("src/lib/titanRunApi.js","utf8");
 assert.match(s,/operation:"list"/);
 assert.match(s,/operation:"get"/);
});
test("approval api uses POST operation contract",()=>{
 const s=fs.readFileSync("src/lib/titanApprovalsApi.js","utf8");
 assert.match(s,/operation:"grant"/);
 assert.match(s,/operation:"revoke"/);
});
test("server functions avoid req.query for invoke operations",()=>{
 for(const f of["api/functions/titanRunState.js","api/functions/titanApprovals.js"]){
  assert.doesNotMatch(fs.readFileSync(f,"utf8"),/req\.query/);
 }
});
