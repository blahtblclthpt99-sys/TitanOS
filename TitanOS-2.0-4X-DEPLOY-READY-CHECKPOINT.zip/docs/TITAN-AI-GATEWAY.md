# TitanAI Gateway

TitanAI now uses the explicit Vercel AI SDK Gateway provider:

`gateway('openai/gpt-5.4')`

The implementation centralizes model routing in `api/_lib/titanAI.js`.

Environment overrides:
- `TITAN_AI_MODEL`
- `TITAN_AI_REASONING_MODEL`

The gateway is server-side only. TitanAI may interpret intent, reason, and propose plans; consequential execution remains controlled by TitanOS approvals, server-side policy, idempotency, and trusted action adapters.

Requires AI SDK 5.0.36 or later.
