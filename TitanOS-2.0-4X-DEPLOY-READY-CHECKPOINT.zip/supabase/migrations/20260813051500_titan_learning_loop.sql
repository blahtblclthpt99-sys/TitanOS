
-- TitanOS 2.0 Phase 3C — Inspectable learning loop.

CREATE TABLE IF NOT EXISTS public.titan_learning_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  skill_id UUID NOT NULL REFERENCES public.titan_skills(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL CHECK (event_type IN (
    'completed_work','verified_credential','repeat_work','positive_rating','negative_rating',
    'match_accepted','match_rejected','user_correction','skill_declared'
  )),
  evidence_type TEXT NOT NULL,
  evidence_ref TEXT,
  evidence_summary TEXT NOT NULL DEFAULT '',
  rating NUMERIC(3,1),
  verified BOOLEAN NOT NULL DEFAULT false,
  confidence_before INTEGER NOT NULL CHECK (confidence_before BETWEEN 0 AND 100),
  confidence_proposed INTEGER NOT NULL CHECK (confidence_proposed BETWEEN 0 AND 100),
  delta INTEGER NOT NULL DEFAULT 0 CHECK (delta BETWEEN -100 AND 100),
  reasons JSONB NOT NULL DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','corrected')),
  reviewed_at TIMESTAMPTZ,
  reviewed_by_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS public.titan_skill_corrections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  skill_id UUID NOT NULL REFERENCES public.titan_skills(id) ON DELETE CASCADE,
  confidence_before INTEGER NOT NULL CHECK (confidence_before BETWEEN 0 AND 100),
  confidence_after INTEGER NOT NULL CHECK (confidence_after BETWEEN 0 AND 100),
  note TEXT NOT NULL DEFAULT '',
  created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_titan_learning_events_user_status
  ON public.titan_learning_events(user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_titan_learning_events_skill
  ON public.titan_learning_events(skill_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_titan_skill_corrections_user
  ON public.titan_skill_corrections(user_id, created_at DESC);

ALTER TABLE public.titan_learning_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.titan_skill_corrections ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS titan_learning_events_owner_all ON public.titan_learning_events;
CREATE POLICY titan_learning_events_owner_all ON public.titan_learning_events
FOR ALL TO authenticated
USING (user_id = auth.uid() OR public.is_admin())
WITH CHECK (user_id = auth.uid() AND created_by_id = auth.uid());

DROP POLICY IF EXISTS titan_skill_corrections_owner_all ON public.titan_skill_corrections;
CREATE POLICY titan_skill_corrections_owner_all ON public.titan_skill_corrections
FOR ALL TO authenticated
USING (user_id = auth.uid() OR public.is_admin())
WITH CHECK (user_id = auth.uid() AND created_by_id = auth.uid());

NOTIFY pgrst, 'reload schema';
