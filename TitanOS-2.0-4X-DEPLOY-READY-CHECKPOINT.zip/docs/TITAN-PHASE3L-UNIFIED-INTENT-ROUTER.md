# TitanOS 2.0 — Phase 3L Unified Intent Router

Every primary input enters one intake contract: Talk, Type, Photograph, Screenshot, Upload, Share.

Pipeline:
1. classify modality
2. determine what the input represents
3. resolve related context
4. infer intended outcome
5. determine permission/risk
6. route to the correct subsystem
7. generate only the interface needed

Opportunity searches route to Work Network; contextual questions to Threads/Action Engine; persistent instructions to Rules; error screenshots to troubleshooting; documents to document understanding; consequential operations to Action Engine.
