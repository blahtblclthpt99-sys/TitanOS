# Titan Work Network — Phase 3B

One opportunity system supports three directions:

1. **Find work** — user-controlled work profile, skills, availability, pay and travel preferences.
2. **Find workers** — businesses describe the work; Titan ranks discoverable workers by relevant dimensions.
3. **Home/project help** — private users describe or photograph a task; Titan converts it into a project opportunity.

## Matching principles

- No single opaque public worker score.
- Skill confidence is per skill and must carry an explanation/evidence trail.
- Users control discoverability and skill visibility.
- Match ranking exposes component scores and missing requirements.
- Applications, invitations, outreach and payments are consequential actions and require appropriate permission.
- Titan may learn from verified credentials, completed work and explicit user corrections, but must not silently infer protected/sensitive traits.

## Invisible Interface

Opportunity commands route directly to `/work-network`. The generated UI depends on whether Titan infers job seeker, employer, or household/project intent.
