
CREATE TABLE IF NOT EXISTS public.titan_action_plans (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE, command TEXT NOT NULL, title TEXT NOT NULL, domain TEXT NOT NULL DEFAULT 'general',
 context JSONB NOT NULL DEFAULT '{}'::jsonb, actions JSONB NOT NULL DEFAULT '[]'::jsonb,
 status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','ready','waiting_approval','running','completed','failed','cancelled')),
 created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS public.titan_action_approvals (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 plan_id UUID NOT NULL REFERENCES public.titan_action_plans(id) ON DELETE CASCADE, user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 action_id TEXT NOT NULL, approved BOOLEAN NOT NULL, approval_context JSONB NOT NULL DEFAULT '{}'::jsonb, created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS public.titan_action_results (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 plan_id UUID NOT NULL REFERENCES public.titan_action_plans(id) ON DELETE CASCADE, user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 action_id TEXT NOT NULL, tool TEXT, success BOOLEAN NOT NULL DEFAULT false, result_summary TEXT NOT NULL DEFAULT '', result_data JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_titan_action_plans_user ON public.titan_action_plans(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_titan_action_approvals_plan ON public.titan_action_approvals(plan_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_titan_action_results_plan ON public.titan_action_results(plan_id,created_at DESC);
ALTER TABLE public.titan_action_plans ENABLE ROW LEVEL SECURITY;ALTER TABLE public.titan_action_approvals ENABLE ROW LEVEL SECURITY;ALTER TABLE public.titan_action_results ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS titan_action_plans_owner_all ON public.titan_action_plans;
CREATE POLICY titan_action_plans_owner_all ON public.titan_action_plans FOR ALL TO authenticated USING(user_id=auth.uid() OR public.is_admin()) WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
DROP POLICY IF EXISTS titan_action_approvals_owner_all ON public.titan_action_approvals;
CREATE POLICY titan_action_approvals_owner_all ON public.titan_action_approvals FOR ALL TO authenticated USING(user_id=auth.uid() OR public.is_admin()) WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
DROP POLICY IF EXISTS titan_action_results_owner_read ON public.titan_action_results;
CREATE POLICY titan_action_results_owner_read ON public.titan_action_results FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.is_admin());
DROP POLICY IF EXISTS titan_action_results_owner_insert ON public.titan_action_results;
CREATE POLICY titan_action_results_owner_insert ON public.titan_action_results FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
NOTIFY pgrst,'reload schema';
