
import test from"node:test";import assert from"node:assert/strict";import{safeExternalUrl}from"../src/lib/safeExternalUrl.js";
test("https external URL is accepted",()=>assert.equal(safeExternalUrl("https://example.com/a"),"https://example.com/a"));
test("javascript URL is rejected",()=>assert.equal(safeExternalUrl("javascript:alert(1)"),null));
test("http rejected by default",()=>assert.equal(safeExternalUrl("http://example.com"),null));
test("host allowlist is enforced",()=>assert.equal(safeExternalUrl("https://evil.example",{allowedHosts:["good.example"]}),null));
