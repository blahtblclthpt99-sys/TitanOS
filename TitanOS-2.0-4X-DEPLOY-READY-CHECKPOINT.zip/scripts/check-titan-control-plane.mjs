
import fs from"node:fs";
const required=[
 "api/functions/executeTitanAction.js",
 "api/_lib/titanServerPolicy.js",
 "api/_lib/titanIntegrationGateway.js",
 "src/lib/titanRunApi.js",
 "src/lib/titanApprovalsApi.js",
 "src/lib/titanRecoveryEngine.js",
 "supabase/migrations/20260813170000_server_execution_control_plane.sql"
];
const missing=required.filter(x=>!fs.existsSync(x));
const adapter=fs.readFileSync("src/lib/titanToolAdapters.js","utf8");
const failures=[];
if(missing.length)failures.push(`missing: ${missing.join(", ")}`);
for(const tool of["jobs.create","money.pay","external.apply","titan.rules.create"]){
 if(!adapter.includes(`"${tool}"`))failures.push(`adapter missing ${tool}`);
}
if(!adapter.includes("executeServerAction"))failures.push("consequential adapters not wired to server execution");
if(failures.length){
 console.error(failures.join("\n"));
 process.exit(1);
}
console.log("Titan control-plane source audit passed.");
