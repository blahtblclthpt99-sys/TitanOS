export const TITAN_AI_MODELS=Object.freeze({
  default: process.env.TITAN_AI_MODEL || "openai/gpt-5.4",
  reasoning: process.env.TITAN_AI_REASONING_MODEL || process.env.TITAN_AI_MODEL || "openai/gpt-5.4",
});

const GATEWAY_URL="https://ai-gateway.vercel.sh/v1/chat/completions";

function gatewayCredential(){
  // AI_GATEWAY_API_KEY is intended for local/CI environments.
  // VERCEL_OIDC_TOKEN is short-lived and automatically available on Vercel.
  return process.env.AI_GATEWAY_API_KEY || process.env.VERCEL_OIDC_TOKEN || null;
}

export function titanGateway(){
  const credential=gatewayCredential();
  if(!credential){
    throw new Error("TitanAI Gateway authentication is not configured");
  }
  return Object.freeze({endpoint:GATEWAY_URL,credential});
}

export async function titanGenerate({prompt,system,reasoning=false,abortSignal}={}){
  if(!prompt)throw new Error("prompt required");
  const model=reasoning?TITAN_AI_MODELS.reasoning:TITAN_AI_MODELS.default;
  const {endpoint,credential}=titanGateway();
  const messages=[];
  if(system)messages.push({role:"system",content:String(system)});
  messages.push({role:"user",content:String(prompt)});

  const response=await fetch(endpoint,{
    method:"POST",
    headers:{
      Authorization:`Bearer ${credential}`,
      "Content-Type":"application/json",
    },
    body:JSON.stringify({model,messages,stream:false}),
    signal:abortSignal,
  });

  let payload=null;
  try{payload=await response.json()}catch{}
  if(!response.ok){
    const detail=payload?.error?.message||payload?.message||`AI Gateway request failed (${response.status})`;
    throw new Error(detail);
  }
  const text=payload?.choices?.[0]?.message?.content;
  if(typeof text!=="string"||!text.trim())throw new Error("TitanAI Gateway returned an empty response");
  return {text,usage:payload?.usage||null,finishReason:payload?.choices?.[0]?.finish_reason||null,model:payload?.model||model};
}
