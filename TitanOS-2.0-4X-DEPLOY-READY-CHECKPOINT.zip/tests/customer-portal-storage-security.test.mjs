
import test from"node:test";import assert from"node:assert/strict";import fs from"node:fs";
test("customer portal does not persist auth token in browser storage",()=>{
 const s=fs.readFileSync("src/pages/CustomerPortal.jsx","utf8");
 assert.doesNotMatch(s,/sessionStorage\.setItem\(\s*["']portal_token/);
 assert.doesNotMatch(s,/localStorage\.setItem\(\s*["']portal_token/);
 assert.doesNotMatch(s,/sessionStorage\.getItem\(\s*["']portal_token/);
});
