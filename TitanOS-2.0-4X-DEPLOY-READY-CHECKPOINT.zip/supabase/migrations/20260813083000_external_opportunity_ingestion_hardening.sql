
ALTER TABLE public.titan_external_opportunities
  ADD COLUMN IF NOT EXISTS last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS ingestion_run_id TEXT;

CREATE INDEX IF NOT EXISTS idx_external_opportunities_source_seen
  ON public.titan_external_opportunities(source_name, last_seen_at DESC);

-- No INSERT/UPDATE/DELETE policies are created for authenticated users:
-- external ingestion remains service-role/server only.
NOTIFY pgrst,'reload schema';
