import React from "react";
import { CheckCircle2, CreditCard, ExternalLink, ShieldCheck, Sparkles } from "lucide-react";
import { Link } from "react-router";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import PageHeader from "@/components/shared/PageHeader";
import PageShell from "@/components/shared/PageShell";
import { getPlanConfig, resolvePlan, isFoundingUser, getFoundingLockedPrice } from "@/lib/plan";
import { openStripeCustomerPortal } from "@/lib/stripeSubscriptions";
import { isAndroidPlayBuild } from "@/lib/playBilling";
import { toast } from "@/components/ui/use-toast";

export default function Subscription() {
  const { user } = useAuth();
  const planId = resolvePlan(user);
  const plan = getPlanConfig(user);
  const androidPlay = isAndroidPlayBuild();
  const [openingPortal, setOpeningPortal] = React.useState(false);

  const manageBilling = async () => {
    if (androidPlay) {
      window.open("https://play.google.com/store/account/subscriptions", "_blank", "noopener,noreferrer");
      return;
    }
    try {
      setOpeningPortal(true);
      await openStripeCustomerPortal();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Billing portal unavailable",
        description: error.message || "Try again in a moment.",
      });
    } finally {
      setOpeningPortal(false);
    }
  };

  const activePaid = Boolean(user?.paying_subscriber || ["starter", "worker_premium", "business"].includes(planId));

  return (
    <PageShell maxWidth="lg">
      <PageHeader
        title="Subscription"
        subtitle="View your TitanOS plan, upgrade, or manage billing."
      />

      <div className="grid gap-5 lg:grid-cols-[1.25fr_0.75fr]">
        <section className="titan-surface p-5 sm:p-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <div className="mb-2 flex items-center gap-2 text-primary">
                <Sparkles className="h-5 w-5" aria-hidden="true" />
                <span className="text-xs font-bold uppercase tracking-wider">Current plan</span>
              </div>
              <h2 className="text-2xl font-bold text-foreground">{plan?.name || "TitanOS"}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{plan?.blurb || "Your TitanOS account plan."}</p>
            </div>
            <div className="rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-right">
              <p className="text-xs text-muted-foreground">Monthly price</p>
              <p className="text-xl font-bold text-primary">
                {Number(plan?.priceMonthly || 0) === 0 ? "$0" : `$${Number(plan.priceMonthly).toFixed(2)}`}
              </p>
            </div>
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl border border-border p-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <CheckCircle2 className="h-4 w-4 text-primary" /> Status
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                {activePaid ? "Active paid subscription" : "Free plan / no active paid subscription"}
              </p>
            </div>
            <div className="rounded-xl border border-border p-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <ShieldCheck className="h-4 w-4 text-primary" /> Billing provider
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{androidPlay ? "Google Play" : "Stripe"}</p>
            </div>
          </div>

          {isFoundingUser(user) && (
            <div className="mt-4 rounded-xl border border-primary/20 bg-primary/5 p-4 text-sm">
              <p className="font-semibold text-foreground">Founding member pricing</p>
              <p className="mt-1 text-muted-foreground">
                Your locked monthly price is ${Number(getFoundingLockedPrice(user) || 0).toFixed(2)} where applicable.
              </p>
            </div>
          )}

          <div className="mt-6 flex flex-wrap gap-3">
            <Button asChild>
              <Link to="/pricing">View / change plans</Link>
            </Button>
            <Button type="button" variant="outline" onClick={manageBilling} disabled={openingPortal}>
              <CreditCard className="h-4 w-4" />
              {openingPortal ? "Opening billing…" : "Manage billing"}
              <ExternalLink className="h-3.5 w-3.5" />
            </Button>
          </div>
        </section>

        <aside className="titan-surface p-5">
          <h3 className="text-sm font-semibold text-foreground">Billing notes</h3>
          <div className="mt-3 space-y-3 text-sm text-muted-foreground">
            <p>Web subscriptions are managed securely through Stripe.</p>
            <p>Android subscriptions are managed through Google Play Billing.</p>
            <p>Changing or cancelling a subscription does not delete your TitanOS account or business records.</p>
          </div>
        </aside>
      </div>
    </PageShell>
  );
}
