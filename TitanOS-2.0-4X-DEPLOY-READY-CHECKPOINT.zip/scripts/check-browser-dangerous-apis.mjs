
import fs from"node:fs";import path from"node:path";
const files=[];
function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(/\.(js|jsx|ts|tsx)$/.test(e.name))files.push(p)}}
walk("src");
const violations=[];
for(const f of files){
 const s=fs.readFileSync(f,"utf8");
 if(/dangerouslySetInnerHTML/.test(s))violations.push(`${f}: dangerouslySetInnerHTML`);
 if(/\beval\s*\(/.test(s)||/\bnew Function\s*\(/.test(s))violations.push(`${f}: dynamic code execution`);
 if(/window\.open\s*\(/.test(s)&&!f.endsWith("src/lib/safeExternalUrl.js")&&!f.endsWith("src/lib/export/pdf.js"))
  violations.push(`${f}: window.open outside approved wrappers`);
}
if(violations.length){console.error(violations.join("\n"));process.exit(1)}
console.log(`Browser dangerous-API audit passed (${files.length} client files scanned).`);
