
import fs from"node:fs";import path from"node:path";
const exts=/\.(js|jsx|ts|tsx|json|xml|gradle|properties|md|yml|yaml)$/;
const skip=new Set(["node_modules",".git","dist","build"]);
const files=[];
function walk(dir){
 for(const e of fs.readdirSync(dir,{withFileTypes:true})){
  if(skip.has(e.name))continue;
  const p=path.join(dir,e.name);
  if(e.isDirectory())walk(p);else if(exts.test(e.name))files.push(p);
 }
}
walk(".");
const findings=[];
const patterns=[
 ["private key",/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
 ["service role literal",/SUPABASE_SERVICE_ROLE_KEY\s*[:=]\s*["'][A-Za-z0-9._-]{20,}/],
 ["stripe secret literal",/sk_(?:live|test)_[A-Za-z0-9]{16,}/],
 ["google private key",/"private_key"\s*:\s*"-----BEGIN PRIVATE KEY/],
 ["Vercel AI Gateway key literal",/vck_[A-Za-z0-9_-]{20,}/],
 ["createGateway literal api key",/createGateway\s*\(\s*\{[\s\S]{0,400}apiKey\s*:\s*["\'][^"\']{12,}["\']/]
];
for(const f of files){
 const s=fs.readFileSync(f,"utf8");
 for(const [label,rx] of patterns)if(rx.test(s))findings.push(`${f}: ${label}`);
}
if(findings.length){console.error(findings.join("\n"));process.exit(1)}
console.log(`Release secret scan passed (${files.length} files scanned).`);
