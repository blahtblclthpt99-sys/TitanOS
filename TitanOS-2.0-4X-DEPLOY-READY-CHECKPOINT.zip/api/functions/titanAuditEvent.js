
import{applyCors,handleOptions}from"../_lib/cors.js";
import{getSupabaseAdmin,readJson}from"../_lib/supabase.js";
const bearer=req=>String(req.headers.authorization||"").replace(/^Bearer\s+/i,"");

export default async function handler(req,res){
 if(handleOptions(req,res))return;
 applyCors(req,res);
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 try{
  const admin=getSupabaseAdmin();
  const{data:u,error:e}=await admin.auth.getUser(bearer(req));
  if(e||!u?.user)return res.status(401).json({error:"Unauthorized"});
  const b=readJson(req),user=u.user;
  const{data,error}=await admin.from("titan_execution_audit").insert({
   user_id:user.id,
   correlation_id:String(b.correlation_id||"").slice(0,120),
   event_type:String(b.type||"event").slice(0,120),
   status:String(b.status||"unknown").slice(0,40),
   plan_id:b.plan_id||null,action_id:b.action_id||null,tool:b.tool||null,
   duration_ms:Number(b.duration_ms)||null,error_code:b.error_code||null,
   metadata:b.metadata||{},created_by_id:user.id
  }).select().single();
  if(error)throw error;
  return res.status(200).json({event:data});
 }catch(error){
  return res.status(500).json({error:error?.message||"Audit write failed"});
 }
}
