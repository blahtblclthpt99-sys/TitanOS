# TitanOS 2.0 — Phase 3K Contextual Memory + Threads

Titan now has a subject-oriented context layer.

A Thread represents a real-world subject such as a vehicle, customer, project, person or property. Memory nodes can link to threads with explicit confidence and reason metadata.

Examples:
- 2004 Ford Ranger -> repairs, receipts, insurance, photos, reminders
- Customer Robert -> jobs, invoices, conversations, estimates
- Project X -> files, decisions, tasks, open loops

The Action Engine recognizes natural requests such as "What's going on with my truck?" and resolves them into a thread before generating a temporary contextual interface.

High-confidence explicit entity relationships can auto-link. Ambiguous associations should remain suggestions rather than silently rewriting memory.
