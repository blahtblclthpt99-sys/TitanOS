# TitanOS Environment Unblock

## Build environment
GitHub Actions workflows now run the full dependency-dependent release gates on a clean Ubuntu runner:

- locked `npm ci`
- Titan integrity
- Titan regression tests
- ESLint
- TypeScript
- legacy ship gate
- Vite production build
- Playwright Chromium E2E

This removes the local sandbox npm-network limitation from the release process.

## Supabase
Production Titan project detected: `xcfjpxcmokdfwkarwomy`.

Do not rehearse the 4R migration chain against production first. Create a Supabase development branch, apply/rehearse migrations there, run `supabase/verification/verify_titan_control_plane.sql`, then promote only after RLS and server execution tests pass.

## Vercel
The currently connected Vercel team has no projects. Titan must either:
1. connect the Vercel account/team that owns the existing Titan deployment, or
2. create a new TitanOS project/deployment in the intended Vercel account.

Do not label the Vercel gate passed until a deployment exists and staging smoke checks pass.
