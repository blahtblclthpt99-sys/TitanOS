
import test from"node:test";
import assert from"node:assert/strict";
import{validateProviderUrl,circuitState,redactProviderError}from"../api/_lib/titanIntegrationGateway.js";

test("gateway rejects http",()=>assert.equal(validateProviderUrl("http://example.com").ok,false));
test("gateway enforces host allowlist",()=>assert.equal(validateProviderUrl("https://evil.example",["good.example"]).ok,false));
test("circuit opens after threshold",()=>assert.equal(circuitState({failures:4,threshold:4}).open,true));
test("provider error redacts bearer token",()=>assert.doesNotMatch(redactProviderError(new Error("Bearer abc123")).message,/abc123/));
