# TitanOS 2.0 — Checkpoint 4F: Production Control Plane

Completed:
- 4C Server-Side Execution Enforcement
- 4D Trusted Integration Gateway
- 4E Execution Observability
- 4F Hardening / Control-Plane Checkpoint

Hardening:
- server re-validates approval; client state is not authoritative
- consequential actions use a trusted server endpoint
- idempotency is enforced server-side
- payment/application integrations fail closed until connected
- provider URLs require HTTPS and may require hostname allowlists
- run/approval transport corrected to explicit JSON operations over POST
- ordinary authenticated clients can no longer insert idempotency records
- recovery remains durable
- audit metadata filters obvious secret fields

Before the next checkpoint, apply migrations to staging and run deployed environment verification: dependency install, lint, typecheck, build, full legacy suite, e2e, RLS checks, provider secrets, mobile permissions, and recovery drills.
