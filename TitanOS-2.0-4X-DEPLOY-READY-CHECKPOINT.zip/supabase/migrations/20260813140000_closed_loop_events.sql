
CREATE TABLE IF NOT EXISTS public.titan_context_events(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,event_type TEXT NOT NULL,
 thread_id UUID REFERENCES public.titan_threads(id) ON DELETE SET NULL,payload JSONB NOT NULL DEFAULT '{}'::jsonb,
 rule_matches JSONB NOT NULL DEFAULT '[]'::jsonb,created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS public.titan_trust_receipts(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,source_event_id UUID REFERENCES public.titan_context_events(id) ON DELETE SET NULL,
 receipt JSONB NOT NULL DEFAULT '{}'::jsonb,created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_titan_context_events_user ON public.titan_context_events(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_titan_trust_receipts_user ON public.titan_trust_receipts(user_id,created_at DESC);
ALTER TABLE public.titan_context_events ENABLE ROW LEVEL SECURITY;ALTER TABLE public.titan_trust_receipts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS titan_context_events_owner_all ON public.titan_context_events;
CREATE POLICY titan_context_events_owner_all ON public.titan_context_events FOR ALL TO authenticated USING(user_id=auth.uid() OR public.is_admin()) WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
DROP POLICY IF EXISTS titan_trust_receipts_owner_all ON public.titan_trust_receipts;
CREATE POLICY titan_trust_receipts_owner_all ON public.titan_trust_receipts FOR ALL TO authenticated USING(user_id=auth.uid() OR public.is_admin()) WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
NOTIFY pgrst,'reload schema';
