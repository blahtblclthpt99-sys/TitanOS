# TitanOS 2.0 — Checkpoint 4N: Release-Candidate Foundation

Completed block:
- 4K Mobile/deep-link continuity
- 4L staging/deployment verification tooling
- 4M global recovery/trust UI polish
- 4N release-candidate checkpoint

Locally verified code is not the same as a release candidate. 4N requires the environment gate before it can be labeled `candidate`.

Key additions:
- verified HTTPS Android app-link declaration for titanos.app (verification still requires deployed assetlinks.json)
- OAuth deep-link consistency checks
- Android release-shell static audit
- persistent Titan recovery banner
- staging/deployment environment verification scripts
- explicit release-stage model
- release-candidate checkpoint model separating local and deployment gates

Do not bump Android versionCode/versionName or build the Play AAB until the environment gate passes.
