
import test from"node:test";import assert from"node:assert/strict";import{evaluateCheckpoint4V}from"../src/lib/titanCheckpoint4V.js";
test("4V verifies only when every local gate passes",()=>{const keys=["tests","imports","routes","control_plane","release_integrity","autonomy","plan_security","storage","android","secrets","syntax","whitespace"];assert.equal(evaluateCheckpoint4V(Object.fromEntries(keys.map(k=>[k,true]))).status,"verified")});
test("4V reports a missing gate",()=>{const x=evaluateCheckpoint4V({tests:true});assert.equal(x.status,"blocked");assert.ok(x.failed.includes("plan_security"))});
