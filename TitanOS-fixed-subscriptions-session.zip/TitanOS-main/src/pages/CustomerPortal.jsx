import React, { useState, useEffect } from "react";
import { api } from "@/api/apiClient";
import { motion } from "framer-motion";
import {
  Briefcase, FileText, Receipt, LogOut, Clock, CheckCircle, AlertCircle, XCircle,
  Loader2, ArrowLeft, Star, CreditCard, CalendarPlus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const STATUS_CONFIG = {
  scheduled:   { label: "Scheduled",   icon: Clock,         color: "text-titan-cyan",   bg: "bg-titan-cyan/10"  },
  in_progress: { label: "In Progress", icon: Loader2,        color: "text-titan-amber",  bg: "bg-titan-amber/10" },
  completed:   { label: "Completed",   icon: CheckCircle,   color: "text-titan-green",  bg: "bg-green-500/10"   },
  cancelled:   { label: "Cancelled",   icon: XCircle,       color: "text-red-400",      bg: "bg-red-500/10"     },
  draft:       { label: "Draft",       icon: FileText,      color: "text-gray-400",     bg: "bg-gray-500/10"    },
  sent:        { label: "Sent",        icon: FileText,      color: "text-titan-cyan",   bg: "bg-titan-cyan/10"  },
  viewed:      { label: "Viewed",      icon: FileText,      color: "text-titan-indigo", bg: "bg-titan-indigo/10"},
  accepted:    { label: "Accepted",    icon: CheckCircle,   color: "text-titan-green",  bg: "bg-green-500/10"   },
  declined:    { label: "Declined",    icon: XCircle,       color: "text-red-400",      bg: "bg-red-500/10"     },
  expired:     { label: "Expired",     icon: AlertCircle,   color: "text-gray-400",     bg: "bg-gray-500/10"    },
  paid:        { label: "Paid",        icon: CheckCircle,   color: "text-titan-green",  bg: "bg-green-500/10"   },
  overdue:     { label: "Overdue",     icon: AlertCircle,   color: "text-red-400",      bg: "bg-red-500/10"     },
  partial:     { label: "Partial",     icon: AlertCircle,   color: "text-titan-amber",  bg: "bg-titan-amber/10" },
};

function StatusBadge({ status }) {
  const cfg = STATUS_CONFIG[status] || { label: status, icon: FileText, color: "text-gray-400", bg: "bg-gray-500/10" };
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${cfg.color} ${cfg.bg}`}>
      <Icon className="w-3 h-3" />
      {cfg.label}
    </span>
  );
}

function Card({ children, className = "" }) {
  return <div className={`bg-card border border-border rounded-2xl p-4 ${className}`}>{children}</div>;
}

function PortalLogin({ onLogin }) {
  const [step, setStep] = useState("email");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSendCode = async (e) => {
    e.preventDefault();
    setError("");
    if (!email.trim()) return;
    setLoading(true);
    try {
      await api.functions.invoke("portalRequestOtp", { email: email.trim() });
      setStep("code");
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyCode = async (e) => {
    e.preventDefault();
    setError("");
    if (!code.trim()) return;
    setLoading(true);
    try {
      const res = await api.functions.invoke("portalVerifyOtp", { email: email.trim(), otp_code: code.trim() });
      onLogin(res.data.token, res.data.customer);
    } catch (err) {
      setError(err?.response?.data?.error || err?.message || "Invalid or expired code. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-titan-cyan/10 border border-titan-cyan/30 mb-4">
            <span className="text-titan-cyan font-bold text-xl">T</span>
          </div>
          <h1 className="text-2xl font-bold text-foreground">Customer Portal</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {step === "email" ? "Enter your email to view your account" : "Enter the code we sent to your email"}
          </p>
        </div>
        <Card>
          {step === "email" ? (
            <form onSubmit={handleSendCode} className="space-y-4">
              <div>
                <label htmlFor="portal-email" className="block text-sm text-muted-foreground mb-1">
                  Email Address
                </label>
                <Input
                  id="portal-email"
                  type="email"
                  name="email"
                  autoComplete="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-background border-border text-foreground placeholder:text-muted-foreground"
                  autoFocus
                />
              </div>
              {error && <p className="text-red-400 text-xs" role="alert">{error}</p>}
              <Button type="submit" disabled={loading} className="w-full font-semibold hover:bg-titan-cyan/90">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Send Verification Code"}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleVerifyCode} className="space-y-4">
              <div>
                <label htmlFor="portal-otp" className="block text-sm text-muted-foreground mb-1">
                  Verification Code
                </label>
                <Input
                  id="portal-otp"
                  type="text"
                  name="one-time-code"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  placeholder="123456"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="bg-background border-border text-foreground placeholder:text-muted-foreground tracking-widest text-center"
                  autoFocus
                  maxLength={6}
                />
                <p className="text-muted-foreground text-xs mt-2">
                  If an account exists for {email}, a 6-digit code was sent. It expires in 10 minutes.
                </p>
              </div>
              {error && <p className="text-red-400 text-xs" role="alert">{error}</p>}
              <Button type="submit" disabled={loading} className="w-full font-semibold hover:bg-titan-cyan/90">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Verify & Continue"}
              </Button>
              <button
                type="button"
                onClick={() => {
                  setStep("email");
                  setCode("");
                  setError("");
                }}
                className="w-full flex items-center justify-center gap-1 text-muted-foreground hover:text-foreground text-xs transition-colors min-h-[44px]"
              >
                <ArrowLeft className="w-3 h-3" /> Use a different email
              </button>
            </form>
          )}
        </Card>
        <p className="text-center text-muted-foreground text-xs mt-6">Powered by TitanOS Field Service</p>
      </motion.div>
    </div>
  );
}

function PortalDashboard({ token, initialCustomer, onLogout }) {
  const [customer, setCustomer] = useState(initialCustomer);
  const [jobs, setJobs] = useState([]);
  const [estimates, setEstimates] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [activeTab, setActiveTab] = useState("jobs");
  const [busyId, setBusyId] = useState(null);
  const [actionMsg, setActionMsg] = useState("");
  const [reviewDraft, setReviewDraft] = useState({});

  const reload = async () => {
    setLoading(true);
    setLoadError("");
    try {
      const res = await api.functions.invoke("portalGetData", { token });
      const data = res.data || res;
      setCustomer(data.customer);
      setJobs(data.jobs || []);
      setEstimates(data.estimates || []);
      setInvoices(data.invoices || []);
    } catch {
      setLoadError("Your session expired. Please sign in again.");
      setTimeout(onLogout, 1500);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { reload(); }, [token]);

  const acceptEstimate = async (est, decision) => {
    setBusyId(est.id);
    setActionMsg("");
    try {
      const res = await api.functions.invoke("portalAcceptEstimate", { token, estimate_id: est.id, decision });
      const updated = res.estimate || res.data?.estimate;
      if (updated) setEstimates((rows) => rows.map((e) => (e.id === est.id ? { ...e, ...updated } : e)));
      setActionMsg(decision === "declined" ? "Estimate declined." : "Estimate accepted — thank you!");
    } catch (err) {
      setActionMsg(err.message || "Could not update estimate.");
    } finally {
      setBusyId(null);
    }
  };

  const payInvoice = async (inv) => {
    setBusyId(inv.id);
    setActionMsg("");
    try {
      const res = await api.functions.invoke("portalPayInvoice", { token, invoice_id: inv.id });
      const data = res.data || res;
      if (data.url) {
        window.location.href = data.url;
        return;
      }
      if (data.invoice) setInvoices((rows) => rows.map((i) => (i.id === inv.id ? { ...i, ...data.invoice } : i)));
      setActionMsg(data.message || "Payment recorded.");
    } catch (err) {
      setActionMsg(err.message || "Could not start payment.");
    } finally {
      setBusyId(null);
    }
  };

  const leaveReview = async (job) => {
    const draft = reviewDraft[job.id] || { rating: 5, comment: "" };
    setBusyId(job.id);
    setActionMsg("");
    try {
      await api.functions.invoke("portalLeaveReview", {
        token,
        job_id: job.id,
        rating: draft.rating,
        comment: draft.comment,
      });
      setActionMsg("Review submitted — thank you!");
      setReviewDraft((d) => ({ ...d, [job.id]: { rating: 5, comment: "" } }));
    } catch (err) {
      setActionMsg(err.message || "Could not submit review.");
    } finally {
      setBusyId(null);
    }
  };

  const tabs = [
    { id: "jobs", label: "Jobs", icon: Briefcase, count: jobs.length },
    { id: "estimates", label: "Estimates", icon: FileText, count: estimates.filter((e) => ["sent", "viewed", "draft"].includes(e.status)).length },
    { id: "invoices", label: "Invoices", icon: Receipt, count: invoices.filter((i) => ["sent", "overdue", "partial"].includes(i.status)).length },
  ];
  const activeEstimates = estimates.filter((e) => ["sent", "viewed", "draft", "accepted", "declined"].includes(e.status));

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur border-b border-border px-4 py-3 flex items-center justify-between">
        <div>
          <h1 className="text-foreground font-semibold text-base">Hi, {customer?.first_name} 👋</h1>
          <p className="text-muted-foreground text-xs">{customer?.email}</p>
        </div>
        <button onClick={onLogout} className="flex items-center gap-1 text-muted-foreground hover:text-foreground text-xs transition-colors">
          <LogOut className="w-4 h-4" /> Sign out
        </button>
      </div>

      <div className="max-w-lg mx-auto px-4 py-6 space-y-6">
        {actionMsg && <Card className="text-sm text-titan-cyan">{actionMsg}</Card>}
        {loadError && <Card className="text-center py-6"><p className="text-red-400 text-sm">{loadError}</p></Card>}

        <div className="flex gap-2 bg-card rounded-xl p-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-medium transition-all ${activeTab === tab.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
                {tab.count > 0 && <span className={`text-[10px] rounded-full px-1.5 py-0.5 font-bold ${activeTab === tab.id ? "bg-black/20" : "bg-muted"}`}>{tab.count}</span>}
              </button>
            );
          })}
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-titan-cyan animate-spin" /></div>
        ) : (
          <>
            {activeTab === "jobs" && (
              <div className="space-y-3">
                {jobs.length === 0 ? (
                  <Card className="text-center py-8"><Briefcase className="w-8 h-8 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground text-sm">No jobs on record</p></Card>
                ) : jobs.map((job) => (
                  <Card key={job.id} className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-foreground font-medium text-sm">{job.title}</p>
                        {job.service_type && <p className="text-muted-foreground text-xs">{job.service_type}</p>}
                      </div>
                      <StatusBadge status={job.status} />
                    </div>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground pt-1 border-t border-border">
                      {job.scheduled_date && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(job.scheduled_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                          {job.scheduled_time && ` at ${job.scheduled_time}`}
                        </span>
                      )}
                      {job.amount > 0 && <span className="ml-auto font-medium text-foreground">${Number(job.amount).toFixed(2)}</span>}
                    </div>
                    {job.status === "completed" && (
                      <div className="space-y-2 pt-2 border-t border-border">
                        <p className="text-xs text-muted-foreground flex items-center gap-1"><Star className="w-3 h-3 text-titan-amber" /> Leave a review</p>
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map((n) => (
                            <button key={n} type="button" onClick={() => setReviewDraft((d) => ({ ...d, [job.id]: { ...(d[job.id] || { comment: "" }), rating: n } }))} className={`text-lg ${(reviewDraft[job.id]?.rating || 5) >= n ? "text-titan-amber" : "text-muted-foreground"}`}>★</button>
                          ))}
                        </div>
                        <Textarea rows={2} placeholder="How did we do?" value={reviewDraft[job.id]?.comment || ""} onChange={(e) => setReviewDraft((d) => ({ ...d, [job.id]: { rating: d[job.id]?.rating || 5, comment: e.target.value } }))} className="bg-background border-border text-foreground text-sm" />
                        <Button size="sm" disabled={busyId === job.id} onClick={() => leaveReview(job)} className="bg-primary text-primary-foreground">
                          {busyId === job.id ? <Loader2 className="w-3 h-3 animate-spin" /> : "Submit review"}
                        </Button>
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            )}

            {activeTab === "estimates" && (
              <div className="space-y-3">
                {activeEstimates.length === 0 ? (
                  <Card className="text-center py-8"><FileText className="w-8 h-8 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground text-sm">No estimates to review</p></Card>
                ) : activeEstimates.map((est) => (
                  <Card key={est.id} className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-foreground font-medium text-sm">{est.estimate_number || "Estimate"}</p>
                        {est.service_type && <p className="text-muted-foreground text-xs">{est.service_type}</p>}
                      </div>
                      <StatusBadge status={est.status} />
                    </div>
                    {est.line_items?.length > 0 && (
                      <div className="text-xs text-muted-foreground space-y-1">
                        {est.line_items.map((li, idx) => (
                          <div key={idx} className="flex justify-between">
                            <span>{li.description}</span>
                            <span className="text-muted-foreground">${(li.total || 0).toFixed(2)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="flex items-center justify-between pt-1 border-t border-border text-xs">
                      {est.valid_until && <span className="text-muted-foreground">Valid until {new Date(est.valid_until).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>}
                      <span className="font-semibold text-foreground ml-auto">${(est.total || 0).toFixed(2)}</span>
                    </div>
                    {["sent", "viewed", "draft"].includes(est.status) && (
                      <div className="flex gap-2 pt-2">
                        <Button size="sm" disabled={busyId === est.id} onClick={() => acceptEstimate(est, "accepted")} className="flex-1 bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                          {busyId === est.id ? <Loader2 className="w-3 h-3 animate-spin" /> : "Accept"}
                        </Button>
                        <Button size="sm" variant="outline" disabled={busyId === est.id} onClick={() => acceptEstimate(est, "declined")} className="flex-1 border-border text-muted-foreground">
                          Decline
                        </Button>
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            )}

            {activeTab === "invoices" && (
              <div className="space-y-3">
                {invoices.length === 0 ? (
                  <Card className="text-center py-8"><Receipt className="w-8 h-8 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground text-sm">No invoices on record</p></Card>
                ) : invoices.map((inv) => (
                  <Card key={inv.id} className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-foreground font-medium text-sm">{inv.invoice_number || "Invoice"}</p>
                        {inv.due_date && <p className="text-muted-foreground text-xs">Due {new Date(inv.due_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</p>}
                      </div>
                      <StatusBadge status={inv.status} />
                    </div>
                    <div className="flex items-center justify-between pt-1 border-t border-border text-xs">
                      <span className="text-muted-foreground">Total</span>
                      <span className="font-semibold text-foreground">${(inv.total || 0).toFixed(2)}</span>
                    </div>
                    {(inv.balance_due > 0 || ["sent", "overdue", "partial"].includes(inv.status)) && inv.status !== "paid" && (
                      <>
                        {inv.balance_due > 0 && (
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-red-400">Balance due</span>
                            <span className="font-bold text-red-400">${Number(inv.balance_due).toFixed(2)}</span>
                          </div>
                        )}
                        <Button size="sm" disabled={busyId === inv.id} onClick={() => payInvoice(inv)} className="w-full bg-primary text-primary-foreground mt-1">
                          {busyId === inv.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <><CreditCard className="w-3.5 h-3.5 mr-1" /> Pay now</>}
                        </Button>
                      </>
                    )}
                    {inv.status === "paid" && (
                      <a className="inline-flex items-center gap-1 text-xs text-titan-cyan" href={`data:text/plain,Receipt for ${inv.invoice_number || "invoice"} — $${inv.total || 0} paid`} download={`${inv.invoice_number || "receipt"}.txt`}>
                        Download receipt
                      </a>
                    )}
                  </Card>
                ))}
              </div>
            )}

            <Card className="flex items-center gap-3 text-sm text-muted-foreground">
              <CalendarPlus className="w-4 h-4 text-titan-cyan flex-none" />
              <p>Need another appointment? Ask your provider for their TitanOS booking link.</p>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}

export default function CustomerPortal() {
  const [session, setSession] = useState(() => {
    try {
      const token = sessionStorage.getItem("portal_token");
      const customer = JSON.parse(sessionStorage.getItem("portal_customer") || "null");
      return token && customer ? { token, customer } : null;
    } catch {
      return null;
    }
  });

  const handleLogin = (token, customer) => {
    sessionStorage.setItem("portal_token", token);
    sessionStorage.setItem("portal_customer", JSON.stringify(customer));
    setSession({ token, customer });
  };

  const handleLogout = () => {
    sessionStorage.removeItem("portal_token");
    sessionStorage.removeItem("portal_customer");
    setSession(null);
  };

  if (!session) return <PortalLogin onLogin={handleLogin} />;
  return <PortalDashboard token={session.token} initialCustomer={session.customer} onLogout={handleLogout} />;
}
