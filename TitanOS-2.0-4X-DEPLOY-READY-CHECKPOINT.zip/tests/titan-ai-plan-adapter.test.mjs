
import test from"node:test";import assert from"node:assert/strict";import{toActionEnginePlan}from"../src/lib/titanAIPlanAdapter.js";
test("AI plan converts to action-engine plan",()=>{const p=toActionEnginePlan({title:"X",actions:[{id:"a",type:"do",risk:"high",requiresApproval:true,payload:{x:1}}]},"cmd");assert.equal(p.source,"titan_ai_gateway");assert.equal(p.requiresApproval,true);assert.equal(p.actions[0].payload.x,1)});
test("clarifying question blocks draft execution",()=>{const p=toActionEnginePlan({title:"X",clarifying_question:"Which customer?",actions:[]},"cmd");assert.equal(p.status,"needs_clarification")});
