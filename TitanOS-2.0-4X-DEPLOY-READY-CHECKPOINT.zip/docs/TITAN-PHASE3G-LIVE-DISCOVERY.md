# TitanOS 2.0 — Phase 3G Live Discovery

## External opportunities
The server now exposes `searchExternalOpportunities`, backed by server-configured approved JSON feed/API adapters.

Provider URLs and credentials are environment-only. The browser cannot supply arbitrary upstream URLs, preventing SSRF-style provider selection.

Supported environment slots:
- TITAN_JOB_FEED_URL / NAME / TYPE / TOKEN
- TITAN_JOB_FEED_2_URL / NAME / TYPE / TOKEN

Adapters normalize provider responses from a generic array, `{jobs:[]}`, or `{results:[]}` contract and cache them in `titan_external_opportunities`.

## Worker discovery
`discoverWorkers` runs with server access, but only considers profiles where `discoverable=true` and skills where `visible_to_matches=true`. It returns match-relevant fields only—no email, phone, address, or other private identity/contact details.

## Next provider work
Actual third-party providers should be integrated only through documented/authorized APIs or feeds. Each provider gets a dedicated parser/adapter plus contract tests. Never scrape from the mobile client.
