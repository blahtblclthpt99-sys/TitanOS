
import fs from"node:fs";import path from"node:path";
const files=[];
function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(/\.(js|jsx|ts|tsx)$/.test(e.name))files.push(p)}}
walk("src");
const violations=[];
for(const f of files){
 const s=fs.readFileSync(f,"utf8");
 if(/\bconsole\.log\s*\(/.test(s))violations.push(`${f}: console.log`);
 if(/\bdebugger\s*;?/.test(s))violations.push(`${f}: debugger statement`);
}
if(violations.length){console.error(violations.join("\n"));process.exit(1)}
console.log(`Production debug-output audit passed (${files.length} client files scanned).`);
