BEGIN;

REVOKE EXECUTE ON FUNCTION public.assign_active_company_id() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.detach_deleted_customer_references() FROM PUBLIC, anon, authenticated;

REVOKE EXECUTE ON FUNCTION public.is_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;

REVOKE EXECUTE ON FUNCTION public.is_company_member(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_company_member(text) TO authenticated;

COMMIT;
