
import test from"node:test";import assert from"node:assert/strict";import{createRunSnapshot,advanceRun,runCanResume}from"../src/lib/titanRunState.js";
test("run starts waiting approval when plan requires it",()=>{const r=createRunSnapshot({plan:{requiresApproval:true,status:"waiting_approval"}});assert.equal(r.status,"waiting_approval")});
test("completed action is checkpointed",()=>{let r=createRunSnapshot({plan:{requiresApproval:false}});r=advanceRun(r,{type:"completed",action_id:"a1"});assert.deepEqual(r.completed_action_ids,["a1"])});
test("integration block is resumable",()=>{let r=createRunSnapshot({plan:{requiresApproval:false}});r=advanceRun(r,{type:"blocked",action_id:"a1",reason:"integration_required"});assert.equal(r.status,"waiting_integration");assert.equal(runCanResume(r),true)});
