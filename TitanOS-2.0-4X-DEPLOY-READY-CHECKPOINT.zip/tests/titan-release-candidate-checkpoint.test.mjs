
import test from"node:test";import assert from"node:assert/strict";import{evaluateReleaseCandidateCheckpoint}from"../src/lib/titanReleaseCandidateCheckpoint.js";
const local={titan_tests:true,control_plane:true,release_integrity:true,imports:true,autonomy_scan:true,android_shell:true,syntax:true,whitespace:true};
test("4N verifies code but blocks release without environment",()=>{const x=evaluateReleaseCandidateCheckpoint(local);assert.equal(x.code_status,"verified");assert.equal(x.release_status,"blocked");assert.ok(x.environment_blocked.includes("build"))});
test("4N becomes candidate only when environment is verified",()=>{const env={dependencies:true,lint:true,typecheck:true,build:true,legacy_suite:true,e2e:true,staging:true,deployed_rls:true,deployed_functions:true};assert.equal(evaluateReleaseCandidateCheckpoint({...local,...env}).release_status,"candidate")});
