
import test from"node:test";import assert from"node:assert/strict";import{inferActionPlan,summarizePermissions,canExecuteAction,markAction,planProgress}from"../src/lib/titanActionEngine.js";
test("job application plan",()=>{const p=inferActionPlan("Find me a delivery job and apply");assert.equal(p.domain,"opportunity");assert.ok(p.actions.some(a=>a.type==="submit_application"&&a.requiresApproval));});
test("bill payment critical",()=>{const p=inferActionPlan("Pay my electric bill"),x=summarizePermissions(p);assert.equal(x.criticalRiskCount,1);assert.ok(p.requiresApproval);});
test("project finds workers",()=>{const p=inferActionPlan("Find someone to repair my fence Saturday under $500");assert.equal(p.domain,"project");assert.ok(p.actions.some(a=>a.type==="search_workers"));});
test("approval gate",()=>{const p=inferActionPlan("Pay my electric bill"),a=p.actions.find(a=>a.type==="pay_bill");assert.equal(canExecuteAction(a,[]),false);assert.equal(canExecuteAction(a,[a.id]),true);});
test("progress",()=>{let p=inferActionPlan("Schedule Robert Friday at 10");p=markAction(p,p.actions[0].id,"completed");assert.ok(planProgress(p).percent>0);});
