
import test from"node:test";import assert from"node:assert/strict";import fs from"node:fs";
test("known workflows stay deterministic",()=>{const s=fs.readFileSync("src/lib/titanHybridPlanner.js","utf8");assert.match(s,/if\(known\(command\)\)/);assert.match(s,/inferActionPlan/)});
test("ambiguous workflows can use TitanAI",()=>{const s=fs.readFileSync("src/lib/titanHybridPlanner.js","utf8");assert.match(s,/requestAIPlan/)});
