import test from"node:test";import assert from"node:assert/strict";import fs from"node:fs";
test("TitanAI gateway uses environment-backed credentials",()=>{
 const s=fs.readFileSync("api/_lib/titanAI.js","utf8");
 assert.match(s,/AI_GATEWAY_API_KEY/);
 assert.match(s,/VERCEL_OIDC_TOKEN/);
 assert.match(s,/ai-gateway\.vercel\.sh\/v1\/chat\/completions/);
 assert.match(s,/Authorization:`Bearer \$\{credential\}`/);
 assert.doesNotMatch(s,/vck_[A-Za-z0-9_-]{20,}/);
});
test("TitanAI has no literal gateway api key",()=>{
 const s=fs.readFileSync("api/_lib/titanAI.js","utf8");
 assert.doesNotMatch(s,/apiKey\s*:\s*["'][^"']+["']/);
});
