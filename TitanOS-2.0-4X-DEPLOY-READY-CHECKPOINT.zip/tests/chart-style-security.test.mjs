
import test from"node:test";import assert from"node:assert/strict";import fs from"node:fs";
test("chart styles avoid raw HTML injection",()=>{const s=fs.readFileSync("src/components/ui/chart.jsx","utf8");assert.doesNotMatch(s,/dangerouslySetInnerHTML/);assert.match(s,/safeCssColor/);assert.match(s,/safeCssToken/)});
