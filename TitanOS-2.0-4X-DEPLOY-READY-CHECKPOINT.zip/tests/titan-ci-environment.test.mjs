
import test from"node:test";import assert from"node:assert/strict";import fs from"node:fs";
test("release CI runs dependency and ship gates",()=>{
 const s=fs.readFileSync(".github/workflows/titan-release-gates.yml","utf8");
 for(const required of["npm ci","npm run lint","npm run typecheck","npm run gate:ship","npm run build","npm run test:e2e"])assert.match(s,new RegExp(required.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")));
});
test("staging CI uses secrets rather than literals",()=>{
 const s=fs.readFileSync(".github/workflows/titan-staging-gates.yml","utf8");
 assert.match(s,/secrets\.SUPABASE_SERVICE_ROLE_KEY/);
 assert.doesNotMatch(s,/eyJ[A-Za-z0-9_-]{20,}/);
});
