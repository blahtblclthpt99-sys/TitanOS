
import test from"node:test";import assert from"node:assert/strict";import{evaluateCheckpoint}from"../src/lib/titanCheckpoint.js";
test("checkpoint ready only when all gates pass",()=>{const x=evaluateCheckpoint({testsPassing:true,migrationsPresent:true,routerPresent:true,multimodalPresent:true,threadsPresent:true,rulesPresent:true,trustPresent:true});assert.equal(x.status,"ready")});
test("checkpoint reports missing gate",()=>{const x=evaluateCheckpoint({testsPassing:true});assert.equal(x.status,"blocked");assert.ok(x.failed.length>0)});
