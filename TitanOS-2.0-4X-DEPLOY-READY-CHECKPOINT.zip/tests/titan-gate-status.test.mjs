
import test from"node:test";import assert from"node:assert/strict";import{gateStatus}from"../src/lib/titanGateStatus.js";
const local={titan_tests:true,control_plane:true,release_integrity:true,imports:true,autonomy_scan:true,android_shell:true,secret_scan:true};
test("verified local code remains release blocked without env",()=>{const x=gateStatus(local);assert.equal(x.code_status,"verified");assert.equal(x.release_status,"blocked");assert.ok(x.environment_blocked.includes("build"))});
test("full env produces candidate",()=>{const env={dependencies:true,lint:true,typecheck:true,legacy_suite:true,build:true,e2e:true,staging:true,deployed_rls:true,deployed_functions:true};assert.equal(gateStatus({...local,...env}).release_status,"candidate")});
