
const HIGH_RISK=new Set(["money.pay","external.apply","work_network.invite","messages.send","documents.sign"]);
const SERVER_EXECUTABLE=new Set(["jobs.create","titan.rules.create"]);
export function actionRisk(tool=""){if(HIGH_RISK.has(tool))return"critical";if(SERVER_EXECUTABLE.has(tool))return"consequential";return"low"}
export function requiresServerExecution(tool=""){return HIGH_RISK.has(tool)||SERVER_EXECUTABLE.has(tool)}
export function serverCanExecute(tool=""){return SERVER_EXECUTABLE.has(tool)}
export function approvalRequired(tool=""){return HIGH_RISK.has(tool)||SERVER_EXECUTABLE.has(tool)}
export function requiredApprovalScope(tool,payload={}){
 if(tool==="money.pay")return{recipient_id:payload.recipient_id||null,amount:Number(payload.amount)||null,currency:payload.currency||"USD"};
 if(tool==="external.apply")return{destination:payload.destination||null,opportunity_id:payload.opportunity_id||null};
 if(tool==="jobs.create")return{customer_id:payload.customer_id||null,scheduled_date:payload.scheduled_date||null};
 return{};
}
export function validateActionRequest({tool,plan_id,action_id,user_id}={}){
 const errors=[];
 if(!tool)errors.push("tool required");
 if(!plan_id)errors.push("plan_id required");
 if(!action_id)errors.push("action_id required");
 if(!user_id)errors.push("user_id required");
 return{ok:errors.length===0,errors};
}
