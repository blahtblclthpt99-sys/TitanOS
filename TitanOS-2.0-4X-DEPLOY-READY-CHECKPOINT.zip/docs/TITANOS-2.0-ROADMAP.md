# TitanOS 2.0 Development Roadmap

Branch: `dev/titanos-2.0`
Baseline: TitanOS 1.6.9 hardened production release

## Phase 1 — Foundation

Status: **In progress**

- [x] Consolidate product navigation into six domains: Home, Work, Customers, Money, TitanAI, More.
- [x] Align desktop sidebar, mobile tabs, and More menu to the same information architecture.
- [x] Preserve existing routes and deep links while reorganizing discovery.
- [x] Normalize shared page headers, core controls, empty/error states, and responsive action layout.
- [ ] Finish converting remaining one-off page states/cards to shared primitives.
- [ ] Audit duplicate/dead UI paths and quarantine legacy surfaces.
- [x] Normalize primary mobile touch targets to 44px and align six-domain tab state with visible navigation.
- [ ] Complete screen-by-screen safe-area and small-device responsive review.
- [x] Establish TitanOS 2.0 interaction tokens and 44px minimum touch-target standard.

## Phase 2 — Command Center

Status: **Started**

- [x] Add ranked “What needs your attention” brief for overdue money, pending estimates, and today's work.
- Today's jobs and schedule.
- Outstanding invoices and money requiring action.
- [x] Customer lead follow-ups and unresolved loops.
- [x] Driver/team status and today's assignment count.
- [x] Vehicle service/warranty and credential/license alerts.
- [x] TitanAI-generated “Needs Your Attention” ranked actions.
- [x] Contextual Titan actions seeded directly into TitanAI.
- [ ] Add richer customer follow-up signals using last-contact and promised-follow-up timestamps.
- [ ] Add live driver presence/shift status when workspace telemetry is available.

## Phase 3 — TitanAI Operating Layer

- Cross-module intent understanding.
- Read-before-write planning.
- Explicit confirmation for consequential actions.
- Action execution across customers, jobs, estimates, invoices, schedules, and communications.
- Generated task-specific interfaces instead of chat-only responses.

## Phase 4 — Connected Business Workflow

`Lead → Customer → Estimate → Approval → Job → Dispatch → Check-in → Work → Completion → Invoice → Payment → Follow-up`

Every object should retain its relationships and workspace ownership through the complete lifecycle.

## Phase 5 — Production Gate

Critical-path automated tests must cover authentication, workspace/RLS isolation, customer lifecycle, estimates, jobs, geofence/GPS, offline behavior, completion, invoices, payments, Stripe, deep links, Android permissions, and TitanAI actions. Critical failures block release.
