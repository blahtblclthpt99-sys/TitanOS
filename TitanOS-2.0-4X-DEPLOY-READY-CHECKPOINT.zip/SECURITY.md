# TitanOS Security

Do not commit credentials, `.env` files, service-role keys, Google Play upload keystores,
`keystore.properties`, payment secrets, or generated APK/AAB files.

Report suspected credential exposure privately to the repository owner. If a signing key,
payment secret, Supabase service-role key, or OAuth credential is exposed, rotate or reset
it at the provider and remove it from Git history; deleting only the latest file is not enough.

Production changes to authentication, payments, row-level security, Android permissions,
or signing configuration require explicit review and a clean release-gate run.
