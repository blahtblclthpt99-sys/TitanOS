# TitanOS 2.0 — Phase 3E Federated Opportunity Engine

TitanOS must be useful even with zero registered employers.

Search order:
1. Titan-native opportunities
2. approved external job APIs/feeds
3. original employer career sources
4. staffing/contract sources
5. permitted local-work sources

All providers normalize into one Titan opportunity schema. Provider adapters are isolated from matching logic.

## Non-negotiables
- Preserve source provenance and original application URL.
- Never claim an external application was submitted unless a verified adapter result confirms it.
- Prefer original employer destinations when available.
- Deduplicate cross-posted jobs.
- Detect stale/expired listings.
- Flag suspicious payment/contact language.
- Keep **user fit** separate from **listing confidence**.
- External ingestion is server-side/trusted; ordinary clients receive read-only cached opportunities.
- Respect provider API/feed terms; do not build brittle unauthorized scraping into the client.
