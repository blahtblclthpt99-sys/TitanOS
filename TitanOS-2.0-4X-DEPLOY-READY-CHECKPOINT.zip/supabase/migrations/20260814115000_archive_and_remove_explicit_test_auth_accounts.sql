CREATE TABLE IF NOT EXISTS public.legacy_test_account_purge_archive (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  archived_at timestamptz NOT NULL DEFAULT now(),
  user_id uuid NOT NULL,
  email text,
  full_name text,
  profile_created_at timestamptz
);
ALTER TABLE public.legacy_test_account_purge_archive ENABLE ROW LEVEL SECURITY;

WITH doomed AS (
  SELECT p.id,p.email,p.full_name,p.created_at
  FROM public.profiles p
  WHERE p.email ILIKE '%@titanos.test'
     OR p.email IN ('john.doe@example.com','jane.doe@example.com')
     OR p.email ILIKE 'titanos-test-%@example.com'
     OR p.email ILIKE 'titanostest-%@example.com'
)
INSERT INTO public.legacy_test_account_purge_archive(user_id,email,full_name,profile_created_at)
SELECT id,email,full_name,created_at FROM doomed;

DELETE FROM auth.users u
WHERE u.id IN (
  SELECT p.id FROM public.profiles p
  WHERE p.email ILIKE '%@titanos.test'
     OR p.email IN ('john.doe@example.com','jane.doe@example.com')
     OR p.email ILIKE 'titanos-test-%@example.com'
     OR p.email ILIKE 'titanostest-%@example.com'
);
