
import test from"node:test";import assert from"node:assert/strict";import{scoreAttention,rankAttention,shouldNotify,quietDigest}from"../src/lib/titanProactiveEngine.js";
test("overdue invoice gets high attention",()=>{const x=scoreAttention({type:"overdue_invoice",due_at:"2026-08-01",amount:1000},new Date("2026-08-13"));assert.ok(x.score>=80)});
test("expiring credential ranks strongly",()=>{const rows=rankAttention([{type:"credential_expiry",due_at:"2026-08-15",title:"DOT med"},{type:"job_followup",last_activity_at:"2026-08-12",title:"Job"}],new Date("2026-08-13"),1);assert.equal(rows[0].type,"credential_expiry")});
test("notification respects cooldown",()=>{const item={type:"bill_due",due_at:"2026-08-14"};assert.equal(shouldNotify(item,{now:new Date("2026-08-13")}),true);assert.equal(shouldNotify(item,{now:new Date("2026-08-13"),lastNotifiedAt:"2026-08-12T20:00:00Z",cooldownHours:24}),false)});
test("digest limits to three meaningful items",()=>{const items=Array.from({length:8},(_,i)=>({type:"overdue_invoice",due_at:"2026-08-01",amount:100+i,title:`x${i}`}));assert.equal(quietDigest(items,new Date("2026-08-13")).items.length,3)});
