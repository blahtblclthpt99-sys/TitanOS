# TitanOS 2.0 — Phase 3C Learning Loop

Titan does not silently rewrite a user's work identity.

## Evidence sources
- completed work
- verified credentials
- repeat work
- customer ratings
- accepted/rejected matches
- explicit user corrections

## Rules
1. Evidence creates a **learning proposal**.
2. Proposal shows confidence before → proposed confidence and why.
3. User may approve, dismiss, or correct it.
4. Only approved/corrected events change the skill model.
5. Confidence is per skill, not a universal public score.
6. Protected or sensitive traits are never inferred into work confidence.
7. Rejected matches carry only weak negative weight because they may reflect pay, timing, distance or preference rather than capability.
