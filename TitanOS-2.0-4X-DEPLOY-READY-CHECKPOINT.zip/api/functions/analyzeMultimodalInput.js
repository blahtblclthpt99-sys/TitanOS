
import{applyCors,handleOptions}from"../_lib/cors.js";import{getSupabaseAdmin,readJson}from"../_lib/supabase.js";import{assertRateLimit}from"../_lib/rateLimit.js";import{configuredMultimodalProvider,analyzeWithProvider}from"../_lib/multimodalProviders.js";
const bearer=req=>String(req.headers.authorization||"").replace(/^Bearer\s+/i,""),safe=(v,max=500)=>String(v||"").trim().slice(0,max);
export default async function handler(req,res){if(handleOptions(req,res))return;applyCors(req,res);if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
try{await assertRateLimit(req,res,{key:"multimodal-analysis",limit:20,windowMs:60000});const admin=getSupabaseAdmin(),{data:u,error:e}=await admin.auth.getUser(bearer(req));if(e||!u?.user)return res.status(401).json({error:"Unauthorized"});const body=readJson(req),provider=configuredMultimodalProvider(),payload={kind:safe(body.kind,50),file_url:body.file_url||null,file_name:safe(body.file_name,500),file_type:safe(body.file_type,200),text:safe(body.text,12000),context:body.context||{}};
if(!provider)return res.status(200).json({analysis:null,provider_configured:false,message:"Multimodal provider is not configured. Titan preserved the input metadata without pretending it analyzed the media."});
const analysis=await analyzeWithProvider(provider,payload);return res.status(200).json({analysis,provider_configured:true,provider:{name:provider.name}});
}catch(error){return res.status(error?.status||500).json({error:error?.message||"Multimodal analysis failed"})}}
