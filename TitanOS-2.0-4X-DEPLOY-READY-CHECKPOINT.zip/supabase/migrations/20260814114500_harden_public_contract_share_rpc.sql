CREATE OR REPLACE FUNCTION public.get_public_contract_by_share_token(p_token text)
RETURNS jsonb LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT CASE WHEN c.id IS NULL THEN NULL ELSE jsonb_build_object(
    'id',c.id,'customer_name',c.customer_name,'title',c.title,'body',c.body,'status',c.status,
    'signed_at',c.signed_at,'owner_signed',(c.owner_signature IS NOT NULL),'customer_signed',(c.customer_signature IS NOT NULL),'share_token',c.share_token)
  END FROM public.contracts c
  WHERE c.share_token=p_token AND p_token IS NOT NULL AND length(p_token)>=32 AND c.status IN ('sent','signed') LIMIT 1;
$$;
REVOKE EXECUTE ON FUNCTION public.get_contract_by_share_token(text) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.sign_contract_by_share_token(text,text,text) FROM anon, authenticated;
REVOKE ALL ON FUNCTION public.get_public_contract_by_share_token(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_contract_by_share_token(text) TO anon, authenticated;
