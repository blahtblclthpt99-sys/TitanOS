
const ALLOWED_PROTOCOLS=new Set(["https:"]);
export function validateProviderUrl(raw,allowedHosts=[]){
 try{
  const u=new URL(raw);
  if(!ALLOWED_PROTOCOLS.has(u.protocol))return{ok:false,reason:"https required"};
  if(allowedHosts.length&&!allowedHosts.includes(u.hostname))return{ok:false,reason:"host not allowlisted"};
  return{ok:true,url:u};
 }catch{
  return{ok:false,reason:"invalid url"};
 }
}
export function providerConfig(env=process.env,prefix){
 const url=env[`${prefix}_URL`]||"";
 if(!url)return null;
 const hosts=String(env[`${prefix}_ALLOWED_HOSTS`]||"").split(",").map(x=>x.trim()).filter(Boolean);
 const validated=validateProviderUrl(url,hosts);
 if(!validated.ok)throw new Error(`${prefix} provider URL rejected: ${validated.reason}`);
 return{name:env[`${prefix}_NAME`]||prefix,url,token:env[`${prefix}_TOKEN`]||"",allowedHosts:hosts};
}
export function circuitState({failures=0,opened_at=null,threshold=4,cooldown_ms=60000,now=Date.now()}={}){
 if(failures<threshold)return{open:false};
 if(!opened_at)return{open:true,retry_at:new Date(now+cooldown_ms).toISOString()};
 const retryAt=new Date(opened_at).getTime()+cooldown_ms;
 return{open:now<retryAt,retry_at:new Date(retryAt).toISOString()};
}
export function redactProviderError(error){
 const message=String(error?.message||"Provider request failed").replace(/Bearer\s+[A-Za-z0-9._-]+/gi,"Bearer [REDACTED]");
 return{message:message.slice(0,500),code:error?.code||"provider_error"};
}
