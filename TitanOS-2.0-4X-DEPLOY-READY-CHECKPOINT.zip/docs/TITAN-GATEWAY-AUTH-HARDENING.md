# TitanAI Gateway Authentication Hardening

TitanAI never embeds a Vercel AI Gateway key in source.

Authentication order:
1. `AI_GATEWAY_API_KEY` for local development / CI
2. `VERCEL_OIDC_TOKEN` for Vercel deployments

The gateway instance is created server-side with `createGateway`.

Operational rule:
- If a Gateway key is ever pasted into chat, source, logs, screenshots, or issue trackers, revoke it and create a replacement.
- Prefer Vercel OIDC for deployed workloads because it avoids a long-lived application secret.
- Do not expose either credential to browser/client bundles.
