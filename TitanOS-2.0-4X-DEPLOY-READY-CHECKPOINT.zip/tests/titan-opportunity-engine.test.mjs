
import test from"node:test";import assert from"node:assert/strict";
import{normalizeOpportunity,listingConfidence,dedupeOpportunities,shouldExpandExternally,rankFederatedMatches}from"../src/lib/titanOpportunityEngine.js";

test("normalizes external provider into Titan schema",()=>{
 const x=normalizeOpportunity({id:"1",role:"Route Driver",employer:"Acme",apply_url:"https://acme.example/jobs/1"},{name:"Provider A",type:"job_provider"});
 assert.equal(x.title,"Route Driver");assert.equal(x.company,"Acme");assert.equal(x.source_name,"Provider A");
});
test("zero native matches triggers external expansion",()=>assert.equal(shouldExpandExternally([]),true));
test("enough strong native matches avoids unnecessary expansion",()=>{
 const rows=Array.from({length:5},(_,i)=>({match:{overall:80+i}}));assert.equal(shouldExpandExternally(rows),false);
});
test("expired suspicious listing has low confidence",()=>{
 const x=normalizeOpportunity({title:"Driver",company:"X",description:"Pay a training fee via gift card",expires_at:"2020-01-01",url:"https://x.example/job"});
 assert.equal(listingConfidence(x,new Date("2026-08-13")).level,"low");
});
test("dedupe keeps one copy of same opportunity",()=>{
 const a=normalizeOpportunity({id:"1",title:"Driver",company:"Acme",city:"OKC",state:"OK",url:"https://a.example"});
 const b=normalizeOpportunity({id:"2",title:"Driver",company:"Acme",city:"OKC",state:"OK",url:"https://b.example"});
 assert.equal(dedupeOpportunities([a,b]).length,1);
});
test("fit and listing confidence stay separate",()=>{
 const x=normalizeOpportunity({title:"Driver",company:"Acme",url:"https://a.example"});
 const rows=rankFederatedMatches([x],()=>({overall:96,reasons:["skills align"]}));
 assert.equal(rows[0].match.overall,96);assert.ok(rows[0].listing_confidence.score!==96);
});
