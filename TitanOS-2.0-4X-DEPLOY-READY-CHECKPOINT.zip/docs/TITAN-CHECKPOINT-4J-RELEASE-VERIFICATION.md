# TitanOS 2.0 — Checkpoint 4J: Release Verification Foundation

Locally verified gates:
- Titan intelligence/control regression tests
- production control-plane audit
- critical source syntax
- migration continuity and static RLS presence
- core route/entity integrity
- static @/ import resolution
- autonomous execution bypass scan

The bypass scan distinguishes planning from execution: the Action Engine may describe a consequential tool, but only canonical execution modules may invoke the trusted server bridge.

Still blocked until dependency/deployment environment:
- npm dependency installation
- lint and typecheck
- legacy security/integration/final-QA suites
- Vite production build
- Playwright E2E
- deployed migrations/RLS
- deployed server functions
- provider secrets and provider smoke tests

Unknown checks are BLOCKED, never silently PASS.
