
import test from"node:test";import assert from"node:assert/strict";import{classifyInboxItem,dedupeInbox,summarizeInbox}from"../src/lib/opportunityWatchEngine.js";
test("new strong match surfaces",()=>{const x=classifyInboxItem({opportunity:{id:"1"},fitScore:88,listingConfidence:80});assert.equal(x.surface,true);assert.equal(x.priority,"high")});
test("passed opportunity stays suppressed",()=>assert.equal(classifyInboxItem({opportunity:{id:"1"},fitScore:99,listingConfidence:99,passed:true}).surface,false));
test("dedupe inbox removes repeated opportunity",()=>assert.equal(dedupeInbox([{opportunity:{id:"1"}},{opportunity:{id:"1"}}]).length,1));
test("summary counts unread high priority",()=>assert.deepEqual(summarizeInbox([{priority:"high",read_at:null},{priority:"normal",read_at:"x"}]),{total:2,unread:1,high:1}));
