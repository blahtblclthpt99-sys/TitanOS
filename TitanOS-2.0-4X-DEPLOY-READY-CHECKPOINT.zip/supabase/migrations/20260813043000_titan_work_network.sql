
-- TitanOS 2.0 Phase 3B — Titan Work Network
-- User-controlled work profile, explainable skill confidence, opportunities and private match records.

CREATE TABLE IF NOT EXISTS public.titan_work_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  headline TEXT NOT NULL DEFAULT '',
  bio TEXT NOT NULL DEFAULT '',
  availability_status TEXT NOT NULL DEFAULT 'open' CHECK (availability_status IN ('open','limited','unavailable')),
  employment_types JSONB NOT NULL DEFAULT '[]'::jsonb,
  preferred_roles JSONB NOT NULL DEFAULT '[]'::jsonb,
  minimum_hourly NUMERIC(10,2),
  travel_radius_miles INTEGER NOT NULL DEFAULT 25 CHECK (travel_radius_miles BETWEEN 0 AND 500),
  city TEXT NOT NULL DEFAULT '',
  state TEXT NOT NULL DEFAULT '',
  remote_ok BOOLEAN NOT NULL DEFAULT false,
  discoverable BOOLEAN NOT NULL DEFAULT true,
  household_requests_enabled BOOLEAN NOT NULL DEFAULT true,
  created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS public.titan_skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'General',
  declared_level INTEGER NOT NULL DEFAULT 50 CHECK (declared_level BETWEEN 0 AND 100),
  confidence INTEGER NOT NULL DEFAULT 50 CHECK (confidence BETWEEN 0 AND 100),
  confidence_reason TEXT NOT NULL DEFAULT 'Declared by user',
  years_experience NUMERIC(5,1) NOT NULL DEFAULT 0,
  verified BOOLEAN NOT NULL DEFAULT false,
  visible_to_matches BOOLEAN NOT NULL DEFAULT true,
  evidence JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  UNIQUE(user_id, name)
);

CREATE TABLE IF NOT EXISTS public.titan_opportunities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  owner_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  owner_type TEXT NOT NULL DEFAULT 'person' CHECK (owner_type IN ('person','business','household')),
  opportunity_type TEXT NOT NULL DEFAULT 'work' CHECK (opportunity_type IN ('work','project')),
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  required_skills JSONB NOT NULL DEFAULT '[]'::jsonb,
  preferred_skills JSONB NOT NULL DEFAULT '[]'::jsonb,
  city TEXT NOT NULL DEFAULT '',
  state TEXT NOT NULL DEFAULT '',
  remote_ok BOOLEAN NOT NULL DEFAULT false,
  pay_min NUMERIC(12,2),
  pay_max NUMERIC(12,2),
  pay_type TEXT NOT NULL DEFAULT 'hourly' CHECK (pay_type IN ('hourly','fixed','salary','negotiable')),
  start_at TIMESTAMPTZ,
  end_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('draft','open','matched','filled','closed','cancelled')),
  visibility TEXT NOT NULL DEFAULT 'network' CHECK (visibility IN ('private','network','public')),
  created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS public.titan_opportunity_matches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  opportunity_id UUID NOT NULL REFERENCES public.titan_opportunities(id) ON DELETE CASCADE,
  worker_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  score INTEGER NOT NULL CHECK (score BETWEEN 0 AND 100),
  score_components JSONB NOT NULL DEFAULT '{}'::jsonb,
  reasons JSONB NOT NULL DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'suggested' CHECK (status IN ('suggested','saved','invited','applied','declined','accepted','closed')),
  created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  UNIQUE(opportunity_id, worker_id)
);

CREATE INDEX IF NOT EXISTS idx_titan_work_profiles_discoverable
  ON public.titan_work_profiles(discoverable, state, city);
CREATE INDEX IF NOT EXISTS idx_titan_skills_user
  ON public.titan_skills(user_id, visible_to_matches);
CREATE INDEX IF NOT EXISTS idx_titan_opportunities_open
  ON public.titan_opportunities(status, opportunity_type, state, city, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_titan_matches_worker
  ON public.titan_opportunity_matches(worker_id, score DESC);
CREATE INDEX IF NOT EXISTS idx_titan_matches_opportunity
  ON public.titan_opportunity_matches(opportunity_id, score DESC);

ALTER TABLE public.titan_work_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.titan_skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.titan_opportunities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.titan_opportunity_matches ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS titan_work_profiles_owner_all ON public.titan_work_profiles;
CREATE POLICY titan_work_profiles_owner_all ON public.titan_work_profiles
FOR ALL TO authenticated
USING (user_id = auth.uid() OR public.is_admin())
WITH CHECK (user_id = auth.uid() AND created_by_id = auth.uid());

DROP POLICY IF EXISTS titan_work_profiles_discoverable_read ON public.titan_work_profiles;
CREATE POLICY titan_work_profiles_discoverable_read ON public.titan_work_profiles
FOR SELECT TO authenticated
USING (discoverable = true OR user_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS titan_skills_owner_all ON public.titan_skills;
CREATE POLICY titan_skills_owner_all ON public.titan_skills
FOR ALL TO authenticated
USING (user_id = auth.uid() OR public.is_admin())
WITH CHECK (user_id = auth.uid() AND created_by_id = auth.uid());

DROP POLICY IF EXISTS titan_skills_visible_read ON public.titan_skills;
CREATE POLICY titan_skills_visible_read ON public.titan_skills
FOR SELECT TO authenticated
USING (
  user_id = auth.uid()
  OR public.is_admin()
  OR (
    visible_to_matches = true
    AND EXISTS (
      SELECT 1 FROM public.titan_work_profiles p
      WHERE p.user_id = titan_skills.user_id AND p.discoverable = true
    )
  )
);

DROP POLICY IF EXISTS titan_opportunities_owner_write ON public.titan_opportunities;
CREATE POLICY titan_opportunities_owner_write ON public.titan_opportunities
FOR ALL TO authenticated
USING (owner_id = auth.uid() OR public.is_admin())
WITH CHECK (owner_id = auth.uid() AND created_by_id = auth.uid());

DROP POLICY IF EXISTS titan_opportunities_network_read ON public.titan_opportunities;
CREATE POLICY titan_opportunities_network_read ON public.titan_opportunities
FOR SELECT TO authenticated
USING (
  owner_id = auth.uid()
  OR public.is_admin()
  OR (status = 'open' AND visibility IN ('network','public'))
);

DROP POLICY IF EXISTS titan_matches_participant_read ON public.titan_opportunity_matches;
CREATE POLICY titan_matches_participant_read ON public.titan_opportunity_matches
FOR SELECT TO authenticated
USING (
  worker_id = auth.uid()
  OR public.is_admin()
  OR EXISTS (
    SELECT 1 FROM public.titan_opportunities o
    WHERE o.id = titan_opportunity_matches.opportunity_id
      AND o.owner_id = auth.uid()
  )
);

DROP POLICY IF EXISTS titan_matches_worker_update ON public.titan_opportunity_matches;
CREATE POLICY titan_matches_worker_update ON public.titan_opportunity_matches
FOR UPDATE TO authenticated
USING (
  worker_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.titan_opportunities o
    WHERE o.id = titan_opportunity_matches.opportunity_id
      AND o.owner_id = auth.uid()
  )
)
WITH CHECK (
  worker_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.titan_opportunities o
    WHERE o.id = titan_opportunity_matches.opportunity_id
      AND o.owner_id = auth.uid()
  )
);

NOTIFY pgrst, 'reload schema';
