
import test from"node:test";import assert from"node:assert/strict";import{createApproval,isApprovalValid,idempotencyKey}from"../src/lib/titanApprovalLedger.js";
test("fresh approval is valid",()=>assert.equal(isApprovalValid(createApproval({planId:"p",actionId:"a",userId:"u"})),true));
test("expired approval is invalid",()=>assert.equal(isApprovalValid(createApproval({planId:"p",actionId:"a",userId:"u",expiresAt:"2020-01-01"}),new Date("2026-08-13")),false));
test("idempotency key is deterministic",()=>assert.equal(idempotencyKey("p","a",2),"p:a:2"));
