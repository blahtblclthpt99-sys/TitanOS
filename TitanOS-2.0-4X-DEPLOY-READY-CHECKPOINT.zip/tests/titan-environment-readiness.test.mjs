
import test from"node:test";import assert from"node:assert/strict";import{environmentReadiness,productionClaimAllowed}from"../src/lib/titanEnvironmentReadiness.js";
test("production remains blocked without deployed checks",()=>{const r=environmentReadiness({dependency_install:true});assert.equal(r.status,"blocked");assert.equal(productionClaimAllowed(r),false)});
test("all environment gates allow production claim",()=>{const r=environmentReadiness({supabase_migrations_applied:true,rls_verified:true,server_functions_deployed:true,provider_secrets_configured:true,dependency_install:true,lint:true,typecheck:true,build:true,e2e:true});assert.equal(r.status,"ready");assert.equal(productionClaimAllowed(r),true)});
