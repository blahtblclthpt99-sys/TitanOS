
import test from"node:test";import assert from"node:assert/strict";import{classifyInputEnvelope,buildUnifiedIntakePlan}from"../src/lib/titanIntentRouter.js";
test("voice envelope classified",()=>assert.equal(classifyInputEnvelope({transcript:"find me work"}),"voice"));
test("job request routes to opportunity",()=>{const x=buildUnifiedIntakePlan({kind:"text",text:"Find me a delivery job"});assert.equal(x.domain,"opportunity");assert.equal(x.destination,"/work-network")});
test("looking for work routes to opportunity",()=>{const x=buildUnifiedIntakePlan({kind:"text",text:"I'm looking for work near me"});assert.equal(x.domain,"opportunity")});
test("from now on routes to rule action",()=>{const x=buildUnifiedIntakePlan({kind:"text",text:"From now on remind me two days before appointments"});assert.equal(x.intent,"teach_rule");assert.equal(x.destination,"/titan-action")});
test("context request routes to action context",()=>{const x=buildUnifiedIntakePlan({kind:"text",text:"What's going on with my truck?"});assert.equal(x.domain,"context");assert.equal(x.surface,"context")});
test("error screenshot routes to troubleshooting",()=>{const x=buildUnifiedIntakePlan({kind:"screenshot",text:"Error: customer not found"});assert.equal(x.domain,"troubleshoot");assert.equal(x.destination,"/multimodal-review")});
test("file resume routes to document understanding",()=>{const x=buildUnifiedIntakePlan({kind:"file",file_name:"resume.pdf"});assert.equal(x.domain,"document")});
