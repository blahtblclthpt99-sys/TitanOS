# TitanOS 2.0 — Phase 4B Production Permission & Recovery Layer

Phase 4B adds durable, scoped approvals and user-facing recovery.

Approvals:
- bound to plan + action + user
- may carry scope (recipient, amount, etc.)
- expire
- can be revoked
- record source device

Recovery:
- waiting approval
- missing integration
- reauthentication
- clarification
- retryable failures

Retry policy uses bounded exponential backoff and refuses to retry errors that require user correction or authorization.

The new Titan Needs You page converts blocked workflows into actionable recovery items. Cross-device resume metadata is stored separately from the action plan so the same account can continue a workflow on another device.
