
import test from "node:test";
import assert from "node:assert/strict";
import {
  proposeSkillConfidenceChange,
  applyApprovedLearning,
  summarizeLearningHistory,
} from "../src/lib/titanLearningEngine.js";

const skill = { id:"s1", name:"Route delivery", confidence:70 };

test("verified credential proposes a meaningful confidence increase", () => {
  const p = proposeSkillConfidenceChange(skill, { event_type:"verified_credential", verified:true });
  assert.ok(p.proposed > 70);
  assert.ok(p.reasons.some((x)=>x.includes("credential")));
});

test("negative rating reduces confidence", () => {
  const p = proposeSkillConfidenceChange(skill, { event_type:"negative_rating", rating:2, verified:true });
  assert.ok(p.proposed < 70);
});

test("user correction overrides learned confidence", () => {
  const p = proposeSkillConfidenceChange(skill, { event_type:"user_correction", corrected_confidence:55, verified:true });
  assert.equal(p.proposed, 55);
});

test("approved learning updates confidence but keeps explainability", () => {
  const proposal = proposeSkillConfidenceChange(skill, { event_type:"completed_work", verified:true });
  const next = applyApprovedLearning(skill, proposal);
  assert.equal(next.confidence, proposal.proposed);
  assert.ok(next.confidence_reason.length > 0);
});

test("history summary separates pending and approved events", () => {
  const s = summarizeLearningHistory([{status:"pending"},{status:"approved"},{status:"rejected"}]);
  assert.deepEqual(s, { total:3, approved:1, pending:1, rejected:1 });
});
