# TitanOS 2.0 — Production Deployment Source

This is the genuine TitanOS 2.0 4X source tree with the later production hardening merged into it.

## Vercel
- Root Directory: repository root (`.` / blank)
- Framework: Vite
- Build Command: `npm run build`
- Output Directory: `dist`
- Install Command is defined by `vercel.json`

Do not point Vercel at any nested directory. This release intentionally contains only one buildable web application.

## Included post-4X production fixes
- Founding 25 lifetime Pro + one-time 3-day Starter trial contract
- Stripe duplicate/early subscription guards
- Same-origin API portability
- App update endpoint portability
- Plans & Billing discoverability
- job_checkins geofence forward migration
- live Supabase RPC/index hardening migrations
- Vercel deployment-root verification
- Vite router dependency correction

## Preserved TitanOS 2.0 systems
Invisible Interface, Titan intent routing, multimodal understanding, contextual planning, proactive attention, memory graph/rules, context threads, approval policy/ledger, action execution runtime, opportunity engine, learning loop, AI gateway and 4X gateway-auth hardening.
