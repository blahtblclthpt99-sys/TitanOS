
const required=["TITAN_STAGING_URL","SUPABASE_URL","SUPABASE_ANON_KEY"];
const missing=required.filter(k=>!process.env[k]);
if(missing.length){
 console.error(`BLOCKED: missing staging environment variables: ${missing.join(", ")}`);
 process.exit(2);
}
const base=process.env.TITAN_STAGING_URL.replace(/\/+$/,"");
const checks=[
 {name:"web root",url:`${base}/`,expect:[200,301,302]},
 {name:"privacy",url:`${base}/privacy`,expect:[200,301,302]},
];
let failed=0;
for(const c of checks){
 try{
  const r=await fetch(c.url,{redirect:"manual",signal:AbortSignal.timeout(10000)});
  const ok=c.expect.includes(r.status);
  console.log(`${ok?"PASS":"FAIL"} ${c.name}: HTTP ${r.status}`);
  if(!ok)failed++;
 }catch(e){
  failed++;console.log(`FAIL ${c.name}: ${e.message}`);
 }
}
if(failed)process.exit(1);
console.log("Staging web smoke checks passed.");
