
import test from"node:test";import assert from"node:assert/strict";import{eventFromObject,evaluateRules}from"../src/lib/titanEventEngine.js";
test("receipt event triggers receipt rule",()=>{const e=eventFromObject({object_type:"receipt"});const m=evaluateRules(e,[{id:"r1",trigger_type:"receipt_captured",enabled:true}]);assert.equal(m.length,1)});
test("disabled rule does not trigger",()=>{const e=eventFromObject({object_type:"receipt"});assert.equal(evaluateRules(e,[{trigger_type:"receipt_captured",enabled:false}]).length,0)});
