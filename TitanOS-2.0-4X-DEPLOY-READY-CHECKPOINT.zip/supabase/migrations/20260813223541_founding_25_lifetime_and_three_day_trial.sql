BEGIN;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS app_trial_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS app_trial_ends_at timestamptz;

COMMENT ON COLUMN public.profiles.founding_user IS 'Founding 25 member with server-protected lifetime full access.';
COMMENT ON COLUMN public.profiles.app_trial_started_at IS 'Start of the one-time three-day TitanOS Starter trial.';
COMMENT ON COLUMN public.profiles.app_trial_ends_at IS 'End of the one-time three-day TitanOS Starter trial.';

UPDATE public.platform_launch
SET founding_cap = 25,
    founding_claimed = LEAST(COALESCE(founding_claimed, 0), 25),
    beta_active = COALESCE(founding_claimed, 0) < 25,
    updated_at = now()
WHERE id = 1;

CREATE OR REPLACE FUNCTION public.claim_founding_slot(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  cap int := 25;
  claimed int := 0;
  slot int;
  profile_exists boolean;
  already_founder boolean;
  trial_end timestamptz;
BEGIN
  IF p_user_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'missing_user');
  END IF;

  SELECT true, founding_user INTO profile_exists, already_founder
  FROM public.profiles WHERE id = p_user_id;

  IF profile_exists IS NOT TRUE THEN
    RETURN jsonb_build_object('ok', false, 'error', 'profile_missing');
  END IF;

  IF already_founder IS TRUE THEN
    SELECT founding_number INTO slot FROM public.profiles WHERE id = p_user_id;
    RETURN jsonb_build_object('ok', true, 'already', true, 'slot', slot, 'lifetime', true);
  END IF;

  PERFORM pg_advisory_xact_lock(87231401);

  SELECT COALESCE(founding_cap, 25) INTO cap
  FROM public.platform_launch WHERE id = 1 FOR UPDATE;
  cap := LEAST(COALESCE(cap, 25), 25);

  SELECT COUNT(*)::int INTO claimed FROM public.profiles WHERE founding_user = true;

  IF claimed < cap THEN
    slot := claimed + 1;
    UPDATE public.profiles
    SET founding_user = true,
        founding_number = slot,
        lifetime_premium = true,
        is_pro = true,
        plan_tier = 'worker_premium',
        founding_trial_ends_at = NULL,
        founding_price_lock = NULL,
        founding_locked_plan = 'worker_premium',
        app_trial_started_at = NULL,
        app_trial_ends_at = NULL,
        updated_at = now()
    WHERE id = p_user_id AND founding_user = false;

    UPDATE public.platform_launch
    SET founding_cap = 25,
        founding_claimed = slot,
        beta_active = slot < 25,
        beta_closed_at = CASE WHEN slot >= 25 THEN COALESCE(beta_closed_at, now()) ELSE NULL END,
        updated_at = now()
    WHERE id = 1;

    RETURN jsonb_build_object('ok', true, 'slot', slot, 'cap', 25, 'lifetime', true,
      'beta_active', slot < 25, 'membership_payments_live', true);
  END IF;

  trial_end := now() + interval '3 days';
  UPDATE public.profiles
  SET app_trial_started_at = COALESCE(app_trial_started_at, now()),
      app_trial_ends_at = COALESCE(app_trial_ends_at, trial_end),
      updated_at = now()
  WHERE id = p_user_id;

  UPDATE public.platform_launch
  SET founding_cap = 25,
      founding_claimed = claimed,
      beta_active = false,
      beta_closed_at = COALESCE(beta_closed_at, now()),
      updated_at = now()
  WHERE id = 1;

  RETURN jsonb_build_object('ok', true, 'founding', false, 'cap', 25,
    'trial_ends_at', trial_end, 'membership_payments_live', true);
END;
$$;

CREATE OR REPLACE FUNCTION public.profiles_auto_claim_founding()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  PERFORM public.claim_founding_slot(NEW.id);
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.claim_founding_slot(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.profiles_auto_claim_founding() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_founding_slot(uuid) TO service_role;
GRANT EXECUTE ON FUNCTION public.profiles_auto_claim_founding() TO service_role;

DROP TRIGGER IF EXISTS trg_profiles_auto_claim_founding ON public.profiles;
CREATE TRIGGER trg_profiles_auto_claim_founding
AFTER INSERT ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.profiles_auto_claim_founding();

COMMIT;
