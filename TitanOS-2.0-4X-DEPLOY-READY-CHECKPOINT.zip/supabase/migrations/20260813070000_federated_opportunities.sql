
-- TitanOS Phase 3E — provider-independent federated opportunity cache.
CREATE TABLE IF NOT EXISTS public.titan_external_opportunities (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 source_type TEXT NOT NULL,
 source_name TEXT NOT NULL,
 external_id TEXT,
 source_url TEXT,
 canonical_url TEXT,
 title TEXT NOT NULL,
 company TEXT NOT NULL DEFAULT '',
 description TEXT NOT NULL DEFAULT '',
 city TEXT NOT NULL DEFAULT '',
 state TEXT NOT NULL DEFAULT '',
 remote_ok BOOLEAN NOT NULL DEFAULT false,
 employment_type TEXT,
 pay_min NUMERIC(12,2),
 pay_max NUMERIC(12,2),
 pay_type TEXT,
 required_skills JSONB NOT NULL DEFAULT '[]'::jsonb,
 preferred_skills JSONB NOT NULL DEFAULT '[]'::jsonb,
 posted_at TIMESTAMPTZ,
 expires_at TIMESTAMPTZ,
 fetched_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 listing_confidence INTEGER CHECK(listing_confidence BETWEEN 0 AND 100),
 confidence_reasons JSONB NOT NULL DEFAULT '[]'::jsonb,
 safety_flags JSONB NOT NULL DEFAULT '[]'::jsonb,
 provenance JSONB NOT NULL DEFAULT '{}'::jsonb,
 active BOOLEAN NOT NULL DEFAULT true,
 UNIQUE(source_name,external_id)
);
CREATE INDEX IF NOT EXISTS idx_external_opportunities_active ON public.titan_external_opportunities(active,state,city,fetched_at DESC);
CREATE INDEX IF NOT EXISTS idx_external_opportunities_company_title ON public.titan_external_opportunities(company,title);
ALTER TABLE public.titan_external_opportunities ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS titan_external_opportunities_read ON public.titan_external_opportunities;
CREATE POLICY titan_external_opportunities_read ON public.titan_external_opportunities
FOR SELECT TO authenticated USING(active=true OR public.is_admin());
-- Writes are intentionally not granted to ordinary authenticated clients.
-- Ingestion should run through a trusted server/Edge Function using provider-approved APIs/feeds.
NOTIFY pgrst,'reload schema';
