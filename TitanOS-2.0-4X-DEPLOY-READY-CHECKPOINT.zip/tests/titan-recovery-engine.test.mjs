
import test from"node:test";import assert from"node:assert/strict";import{recoveryForRun,rankRecoveryQueue}from"../src/lib/titanRecoveryEngine.js";
test("approval run maps to approval recovery",()=>assert.equal(recoveryForRun({status:"waiting_approval"}).kind,"approval"));
test("auth failure maps to reauth",()=>assert.equal(recoveryForRun({status:"failed",last_error_code:"unauthorized"}).kind,"reauth"));
test("approval recovery ranks above retry",()=>{const q=rankRecoveryQueue([{id:"r1",status:"failed",updated_at:"2026-08-13"},{id:"r2",status:"waiting_approval",updated_at:"2026-08-13"}]);assert.equal(q[0].run.id,"r2")});
