
import fs from"node:fs";import path from"node:path";
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(/\.(js|jsx|ts|tsx)$/.test(e.name))files.push(p)}}
walk("src");
const allowedExecute=new Set([
 "src/lib/titanToolAdapters.js",
 "src/lib/titanServerExecutionApi.js",
 "src/lib/titanExecutionRuntime.js",
 "src/pages/TitanActionCenter.jsx"
]);
const planningFiles=new Set([
 "src/lib/titanActionEngine.js",
 "src/lib/titanRulesEngine.js",
 "src/lib/titanClosedLoop.js",
 "src/lib/titanTrustReceipt.js"
]);
const violations=[];
for(const f of files){
 const s=fs.readFileSync(f,"utf8");
 if(!allowedExecute.has(f)&&/executeServerAction\s*\(/.test(s)){
  violations.push(`${f}: executes trusted server action outside approved execution modules`);
 }
 if(!planningFiles.has(f)&&!allowedExecute.has(f)){
  if(/registerTitanTool\s*\(\s*["'](?:money\.pay|external\.apply|jobs\.create|titan\.rules\.create)["']/.test(s)){
   violations.push(`${f}: registers consequential Titan tool outside canonical adapter`);
  }
 }
}
if(violations.length){console.error(violations.join("\n"));process.exit(1)}
console.log(`Titan autonomous-bypass scan passed (${files.length} client source files scanned).`);
