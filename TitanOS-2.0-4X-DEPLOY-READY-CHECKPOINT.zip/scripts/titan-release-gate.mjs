
import fs from"node:fs";
import{spawnSync}from"node:child_process";

const results={};
const run=(name,cmd,args=[])=>{
 const p=spawnSync(cmd,args,{stdio:"inherit",shell:false});
 results[name]=p.status===0;
 return p.status===0;
};

run("titan_tests","node",["--test",...fs.readdirSync("tests").filter(x=>x.endsWith(".test.mjs")).sort().map(x=>`tests/${x}`)]);
run("control_plane","node",["scripts/check-titan-control-plane.mjs"]);
run("release_integrity","node",["scripts/check-titan-release-integrity.mjs"]);
run("imports","node",["scripts/check-titan-imports.mjs"]);
run("autonomy_scan","node",["scripts/check-titan-autonomy-bypass.mjs"]);
run("android_shell","node",["scripts/check-android-release-shell.mjs"]);

const dependencyReady=fs.existsSync("node_modules/.bin/eslint");
results.dependencies=dependencyReady;
if(dependencyReady){
 run("lint","npm",["run","lint"]);
 run("typecheck","npm",["run","typecheck"]);
 run("legacy_suite","npm",["run","gate:ship"]);
 run("build","npm",["run","build"]);
 run("e2e","npm",["run","test:e2e"]);
}else{
 for(const key of["lint","typecheck","legacy_suite","build","e2e"])results[key]=null;
 console.error("BLOCKED dependency-dependent gates: node_modules/.bin is unavailable.");
}

const envReady=Boolean(process.env.TITAN_STAGING_URL&&process.env.SUPABASE_URL&&process.env.SUPABASE_ANON_KEY);
results.staging_environment=envReady;
if(envReady){
 run("staging","node",["scripts/verify-titan-staging.mjs"]);
}else{
 results.staging=null;
 console.error("BLOCKED staging gate: staging/Supabase environment variables unavailable.");
}

fs.writeFileSync("release-gate-results.json",JSON.stringify({
 generated_at:new Date().toISOString(),
 results,
 blocked:Object.entries(results).filter(([k,v])=>v===null||((k==="dependencies"||k==="staging_environment")&&v===false)).map(([k])=>k)
},null,2));

const localRequired=["titan_tests","control_plane","release_integrity","imports","autonomy_scan","android_shell"];
const localFail=localRequired.filter(k=>results[k]!==true);
if(localFail.length){
 console.error(`FAILED local release gates: ${localFail.join(", ")}`);
 process.exit(1);
}
if(!dependencyReady||!envReady){
 console.log("LOCAL CHECKPOINT VERIFIED; RELEASE CANDIDATE REMAINS BLOCKED.");
 process.exit(2);
}
console.log("ALL RELEASE GATES AVAILABLE IN THIS ENVIRONMENT PASSED.");
