
import test from"node:test";import assert from"node:assert/strict";import{hardenPlan,planCanAutoExecute}from"../src/lib/titanPlanHardening.js";
test("critical tool is forced to approval",()=>{const p=hardenPlan({actions:[{id:"a",tool:"money.pay",type:"pay",risk:"low",requiresApproval:false}]});assert.equal(p.actions[0].requiresApproval,true);assert.equal(p.actions[0].risk,"high")});
test("safe informational plan may auto execute",()=>assert.equal(planCanAutoExecute({actions:[{type:"read",risk:"low",requiresApproval:false}]}),true));
test("consequential no-tool plan is still approval gated",()=>{const p=hardenPlan({actions:[{id:"a",type:"send customer message",risk:"low",requiresApproval:false,tool:null}]});assert.equal(p.actions[0].requiresApproval,true)});
