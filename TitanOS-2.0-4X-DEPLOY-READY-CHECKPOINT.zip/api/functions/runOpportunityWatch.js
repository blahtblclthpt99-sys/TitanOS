
import { applyCors, handleOptions } from "../_lib/cors.js";
import { getSupabaseAdmin, readJson } from "../_lib/supabase.js";
import { assertRateLimit } from "../_lib/rateLimit.js";
import { configuredProviders, searchConfiguredProvider } from "../_lib/opportunityProviders.js";

const bearer=req=>String(req.headers.authorization||"").replace(/^Bearer\s+/i,"");
const key=o=>String(o.external_id||o.id||`${o.source_name}|${o.company}|${o.title}|${o.city}|${o.state}`);

function scoreFit(profile, skills, o) {
  const required=Array.isArray(o.required_skills)?o.required_skills.map(x=>String(x).toLowerCase()):[];
  const map=new Map((skills||[]).map(s=>[String(s.name||"").toLowerCase(),s]));
  const hits=required.filter(x=>map.has(x));
  let score=required.length?Math.round(hits.length/required.length*75):65;
  if(profile?.city && o.city && String(profile.city).toLowerCase()===String(o.city).toLowerCase()) score+=10;
  if(profile?.state && o.state && String(profile.state).toLowerCase()===String(o.state).toLowerCase()) score+=5;
  if(profile?.remote_ok && o.remote_ok) score+=8;
  const floor=Number(profile?.minimum_hourly)||0, offered=Number(o.pay_max||o.pay_min)||0;
  if(floor&&offered&&offered>=floor) score+=12;
  return Math.max(0,Math.min(100,score));
}

function listingConfidence(o) {
  let score=50;
  if(o.canonical_url) score+=15;
  if(o.company) score+=10;
  if(o.posted_at){const age=(Date.now()-new Date(o.posted_at))/86400000;if(age<=7)score+=15;else if(age>60)score-=20;}
  if(o.expires_at && new Date(o.expires_at)<new Date()) score-=40;
  return Math.max(0,Math.min(100,score));
}

export default async function handler(req,res){
  if(handleOptions(req,res))return; applyCors(req,res);
  if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
  try{
    await assertRateLimit(req,res,{key:"opportunity-watch",limit:10,windowMs:60_000});
    const admin=getSupabaseAdmin(),{data:userData,error:userError}=await admin.auth.getUser(bearer(req));
    if(userError||!userData?.user)return res.status(401).json({error:"Unauthorized"});
    const user=userData.user,body=readJson(req);
    let q=admin.from("titan_opportunity_watches").select("*").eq("user_id",user.id).eq("enabled",true);
    if(body.watch_id) q=q.eq("id",body.watch_id);
    const {data:watches,error:wErr}=await q;if(wErr)throw wErr;

    const {data:profiles}=await admin.from("titan_work_profiles").select("*").eq("user_id",user.id).limit(1);
    const profile=profiles?.[0]||null;
    const {data:skills}=await admin.from("titan_skills").select("*").eq("user_id",user.id).eq("visible_to_matches",true);
    const {data:reactions}=await admin.from("titan_opportunity_reactions").select("opportunity_key,reaction").eq("user_id",user.id);
    const reactionMap=new Map((reactions||[]).map(r=>[r.opportunity_key,r.reaction]));

    const providers=configuredProviders(),created=[];
    for(const watch of watches||[]){
      const query=watch.query||{};
      let external=[];
      for(const provider of providers){
        try{external.push(...await searchConfiguredProvider(provider,query));}catch{}
      }

      const {data:native}=await admin.from("titan_opportunities").select("*").eq("status","open").limit(100);
      const rows=[...(native||[]),...external];

      for(const o of rows){
        const k=key(o),reaction=reactionMap.get(k);
        if(reaction==="pass"||reaction==="saved"||reaction==="applied")continue;
        const fit=scoreFit(profile,skills||[],o),confidence=listingConfidence(o);
        if(fit<70||confidence<50)continue;

        const {data:existing}=await admin.from("titan_opportunity_inbox")
          .select("id,fit_score,listing_confidence")
          .eq("user_id",user.id).eq("opportunity_key",k).limit(1);

        if(existing?.length){
          const prior=existing[0];
          if(fit<=Number(prior.fit_score||0) && confidence<=Number(prior.listing_confidence||0)) continue;
          await admin.from("titan_opportunity_inbox").update({
            fit_score:fit,listing_confidence:confidence,priority:fit>=85?"high":"normal",
            reason:"match improved",opportunity:o,updated_at:new Date().toISOString(),read_at:null
          }).eq("id",prior.id);
          continue;
        }

        const {data:inserted}=await admin.from("titan_opportunity_inbox").insert({
          user_id:user.id,watch_id:watch.id,opportunity_key:k,source_name:o.source_name||"TitanOS",
          opportunity:o,fit_score:fit,listing_confidence:confidence,priority:fit>=85?"high":"normal",
          reason:"new strong match",created_by_id:user.id
        }).select().single();
        if(inserted)created.push(inserted);
      }

      await admin.from("titan_opportunity_watches").update({last_checked_at:new Date().toISOString()}).eq("id",watch.id);
    }
    return res.status(200).json({created_count:created.length,created});
  }catch(error){return res.status(error?.status||500).json({error:error?.message||"Opportunity watch failed"});}
}
