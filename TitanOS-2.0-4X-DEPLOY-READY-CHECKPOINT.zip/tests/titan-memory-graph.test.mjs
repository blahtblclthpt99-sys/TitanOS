
import test from"node:test";import assert from"node:assert/strict";import{receiptMemory,relationship}from"../src/lib/titanMemoryGraph.js";
test("receipt becomes structured memory",()=>{const m=receiptMemory({merchant:"Store",amount:42.5,date:"2026-08-13"});assert.equal(m.type,"receipt");assert.equal(m.data.amount,42.5)});
test("memory relationship preserves graph link",()=>{const e=relationship("car1","receipt1","has_receipt");assert.equal(e.relationship_type,"has_receipt")});
