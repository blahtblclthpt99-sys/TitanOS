
import test from"node:test";import assert from"node:assert/strict";import{buildPlannerContext}from"../src/lib/titanPlannerContext.js";
test("multimodal object becomes planner context",()=>{const x=buildPlannerContext({intake:{kind:"photo",input:{file_name:"x.jpg"}},multimodal:{object:{object_type:"receipt",confidence:.9,data:{amount:42}}}});assert.equal(x.input.kind,"photo");assert.equal(x.understood_object.object_type,"receipt");assert.equal(x.understood_object.data.amount,42)});
test("planner context truncates memory",()=>{const memory=Array.from({length:30},(_,i)=>({type:"x",label:String(i)}));assert.equal(buildPlannerContext({memory}).recent_memory.length,12)});
