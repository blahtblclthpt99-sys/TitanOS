
import test from"node:test";import assert from"node:assert/strict";import{configuredMultimodalProvider}from"../api/_lib/multimodalProviders.js";
test("multimodal provider is server-configured only",()=>{const p=configuredMultimodalProvider({TITAN_MULTIMODAL_URL:"https://ai.example/analyze",TITAN_MULTIMODAL_NAME:"Vision"});assert.equal(p.url,"https://ai.example/analyze");assert.equal(p.name,"Vision")});
test("no provider configured returns null",()=>assert.equal(configuredMultimodalProvider({}),null));
