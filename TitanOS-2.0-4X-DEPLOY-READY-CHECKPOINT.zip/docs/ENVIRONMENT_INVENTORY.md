# TitanOS 2.0 4X Environment Inventory

## Client-safe variables
Only values intended to be shipped into the browser may use these names.

- `VITE_SUPABASE_URL` — required for browser Supabase.
- `VITE_SUPABASE_ANON_KEY` or `VITE_SUPABASE_PUBLISHABLE_KEY` — required browser publishable key.
- `VITE_API_BASE_URL` — optional API override; production should normally use same-origin APIs.
- `VITE_APP_URL`, `VITE_TITANOS_PUBLIC_ORIGIN` — public origin hints.
- `VITE_APP_VERSION` — release label; TitanOS 2.0 4X default is 2.0.0.
- `VITE_CAPACITOR_BUILD` — native shell build flag.
- `VITE_FEATURE_FLAGS_JSON` — public feature flags only; never secrets.
- `VITE_MAX_PROFILE_ACHIEVEMENTS` — public UI limit.
- `VITE_SENTRY_DSN` — client DSN, safe to expose by design.
- `VITE_AUTOPILOT_ONETIME_CHECKOUT` — public checkout behavior flag.
- `VITE_TITANOS_AAB_URL`, `VITE_TITANOS_APK_URL`, `VITE_TITANOS_PLAY_STORE_URL`, `VITE_TITANOS_PLAY_TESTING_URL` — public release links.
- `VITE_USE_HASH_ROUTER` — public routing flag.
- `VITE_VERCEL_ENV`, `VITE_VERCEL_GIT_COMMIT_SHA` — public release metadata.
- `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` — compatibility aliases if used.

## Server-only secrets / privileged configuration
These must never be bundled into client JavaScript.

### Core backend
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY` **secret**
- `SUPABASE_ANON_KEY` publishable but server-side compatibility variable
- `CORS_ALLOWED_ORIGINS`
- `PUBLIC_APP_URL`, `APP_ORIGIN`
- `APP_LATEST_VERSION`, `APP_MINIMUM_VERSION`
- `FEATURE_FLAGS_JSON`
- `REGISTER_REQUIRE_EMAIL_CONFIRM`

### Stripe billing
Required when Stripe subscriptions/payments are enabled:
- `STRIPE_SECRET_KEY` **secret**
- `STRIPE_WEBHOOK_SECRET` **secret**
- `STRIPE_PRICE_STARTER_MONTHLY`
- `STRIPE_PRICE_PRO_MONTHLY`
- `STRIPE_PRICE_BUSINESS_MONTHLY`
- `STRIPE_AUTOPILOT_PRICE_ID` when Autopilot billing is enabled
- `STRIPE_PROFILE_ID` if used by the deployment
- `TITANOS_BILLING_HOOK_SECRET` **secret**

### AI
- `AI_GATEWAY_API_KEY` **secret**
- `TITAN_AI_MODEL`
- `TITAN_AI_REASONING_MODEL`
- `OPENAI_API_KEY` **secret** when direct OpenAI fallback is enabled
- `OPENAI_MODEL`, `OPENAI_VISION_MODEL`

### Email / messaging
- `RESEND_API_KEY` **secret**
- `RESEND_FROM`
- `SLACK_WEBHOOK_URL` **secret**
- `OPS_ALERT_WEBHOOK_URL` **secret**

### Security / operations
- `AUDIT_IP_PEPPER` **secret**
- `PORTAL_OTP_PEPPER` **secret**
- `PORTAL_OTP_ALLOW_LEGACY`
- `PORTAL_TOKEN_ALLOW_LEGACY`
- `HEALTH_DEEP_SECRET` **secret**
- `TITANOS_OPS_SECRET` **secret**
- `SIGNUP_EMAILS_EXPORT_KEY` **secret**
- `SEED_MARKETPLACE_SECRET` **secret**
- `OWNER_SEED_EMAIL`
- `ADMIN_EMAIL`, `FEEDBACK_ADMIN_EMAIL`
- `UPSTASH_REDIS_REST_URL`
- `UPSTASH_REDIS_REST_TOKEN` **secret**
- `SENTRY_DSN`, `SENTRY_ENVIRONMENT`, `SENTRY_RELEASE`, `SENTRY_PROFILING`

### Google Play / Android
- `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` **secret**
- `TITAN_ANDROID_SHA256_FINGERPRINTS`
- `ANDROID_STORE_URL`

### PayPal / optional money rails
- `PAYPAL_CLIENT_ID`
- `PAYPAL_CLIENT_SECRET` **secret**
- `PAYPAL_WEBHOOK_ID` **secret/config**
- `PAYPAL_MODE`
- `MPP_SECRET_KEY` and other `MPP_*` values when MPP is enabled

### CI / smoke only
- `SMOKE_AUTH_EMAIL`, `SMOKE_AUTH_PASSWORD` **test secrets**
- `TITAN_STAGING_URL`
- `VERCEL_GIT_COMMIT_SHA`, `VERCEL_GIT_COMMIT_REF`, `VERCEL_ENV`, `VERCEL_OIDC_TOKEN`

## Production rule
Production must fail clearly when a required secret/configuration is missing. No server-only variable may be placed under `VITE_*` or `NEXT_PUBLIC_*`.
