# TitanOS 2.0 — Phase 3M Multimodal Understanding

Photos, screenshots and uploads now route through a multimodal understanding layer first.

Initial structured object types:
- receipt
- error screenshot
- job-site condition
- vehicle
- equipment
- document
- general/shared item

Actual extraction requires a server-configured multimodal provider. If none is connected, Titan explicitly says so and does not fabricate analysis.

Structured results can become Memory nodes, attach to Threads, or hand off into troubleshooting and Action Engine workflows.
