
import test from"node:test";import assert from"node:assert/strict";import{validateAIPlan,safeFallbackPlan}from"../src/lib/titanAIPlanSchema.js";
test("critical AI action always requires approval",()=>{const x=validateAIPlan({title:"Pay",actions:[{type:"pay_bill",risk:"critical",requiresApproval:false}]});assert.equal(x.ok,true);assert.equal(x.plan.actions[0].requiresApproval,true)});
test("invalid empty AI plan is rejected",()=>assert.equal(validateAIPlan({}).ok,false));
test("fallback never executes consequential action",()=>{const x=safeFallbackPlan("do something");assert.equal(x.actions[0].risk,"low");assert.equal(x.actions[0].tool,"titan.reason")});
