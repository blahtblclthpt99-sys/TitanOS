## TitanOS change

### What changed
- 

### Release impact
- [ ] No database migration
- [ ] Database migration reviewed and reversible
- [ ] No Android permission/signing/version change
- [ ] Android change reviewed
- [ ] No payment/auth/RLS change
- [ ] Payment/auth/RLS change reviewed

### Verification
- [ ] Lint
- [ ] Typecheck
- [ ] Tests
- [ ] Production build
- [ ] Mobile smoke test
- [ ] No secrets or release binaries added
