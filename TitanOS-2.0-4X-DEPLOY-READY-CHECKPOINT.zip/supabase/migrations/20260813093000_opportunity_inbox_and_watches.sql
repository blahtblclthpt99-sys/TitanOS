
CREATE TABLE IF NOT EXISTS public.titan_opportunity_watches(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),created_at TIMESTAMPTZ NOT NULL DEFAULT now(),updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,name TEXT NOT NULL,query JSONB NOT NULL DEFAULT '{}'::jsonb,
 enabled BOOLEAN NOT NULL DEFAULT true,cadence TEXT NOT NULL DEFAULT 'daily' CHECK(cadence IN('hourly','daily','weekly')),
 last_checked_at TIMESTAMPTZ,created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS public.titan_opportunity_inbox(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),created_at TIMESTAMPTZ NOT NULL DEFAULT now(),updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,watch_id UUID REFERENCES public.titan_opportunity_watches(id) ON DELETE SET NULL,
 opportunity_key TEXT NOT NULL,source_name TEXT NOT NULL,opportunity JSONB NOT NULL DEFAULT '{}'::jsonb,
 fit_score INTEGER NOT NULL CHECK(fit_score BETWEEN 0 AND 100),listing_confidence INTEGER NOT NULL CHECK(listing_confidence BETWEEN 0 AND 100),
 priority TEXT NOT NULL DEFAULT 'normal' CHECK(priority IN('normal','high')),reason TEXT NOT NULL DEFAULT '',read_at TIMESTAMPTZ,
 created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,UNIQUE(user_id,opportunity_key));
CREATE TABLE IF NOT EXISTS public.titan_opportunity_reactions(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),created_at TIMESTAMPTZ NOT NULL DEFAULT now(),user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 opportunity_key TEXT NOT NULL,source_name TEXT NOT NULL,reaction TEXT NOT NULL CHECK(reaction IN('saved','pass','applied','dismissed')),
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb,created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_titan_watch_user_enabled ON public.titan_opportunity_watches(user_id,enabled,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_titan_inbox_user_unread ON public.titan_opportunity_inbox(user_id,read_at,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_titan_reactions_user_key ON public.titan_opportunity_reactions(user_id,opportunity_key,created_at DESC);
ALTER TABLE public.titan_opportunity_watches ENABLE ROW LEVEL SECURITY;ALTER TABLE public.titan_opportunity_inbox ENABLE ROW LEVEL SECURITY;ALTER TABLE public.titan_opportunity_reactions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS titan_watches_owner_all ON public.titan_opportunity_watches;CREATE POLICY titan_watches_owner_all ON public.titan_opportunity_watches FOR ALL TO authenticated USING(user_id=auth.uid() OR public.is_admin()) WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
DROP POLICY IF EXISTS titan_inbox_owner_all ON public.titan_opportunity_inbox;CREATE POLICY titan_inbox_owner_all ON public.titan_opportunity_inbox FOR ALL TO authenticated USING(user_id=auth.uid() OR public.is_admin()) WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
DROP POLICY IF EXISTS titan_reactions_owner_all ON public.titan_opportunity_reactions;CREATE POLICY titan_reactions_owner_all ON public.titan_opportunity_reactions FOR ALL TO authenticated USING(user_id=auth.uid() OR public.is_admin()) WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
NOTIFY pgrst,'reload schema';
