
import test from"node:test";import assert from"node:assert/strict";import{evaluateReleaseGate}from"../src/lib/titanReleaseGate.js";
test("release gate stays blocked when environment gates unknown",()=>{const x=evaluateReleaseGate({titan_tests:true,source_audit:true});assert.equal(x.status,"blocked");assert.ok(x.blocked.includes("build"))});
test("explicit failure dominates blocked",()=>{const x=evaluateReleaseGate({titan_tests:false});assert.equal(x.status,"failed");assert.ok(x.failed.includes("titan_tests"))});
test("all gates passing permits ready",()=>{const keys=["titan_tests","source_audit","syntax","migration_integrity","route_integrity","autonomous_bypass_scan","lint","typecheck","legacy_security","integration_merge","final_qa","build","e2e","deployed_rls","deployed_functions","provider_secrets"];assert.equal(evaluateReleaseGate(Object.fromEntries(keys.map(k=>[k,true]))).status,"ready")});
