# Legacy / reference material

`TitanOS-prototype/` is the older standalone prototype that previously lived beside the
production application. It is retained only for reference and is not part of the Google
Play or web production build.

Production application paths are the repository root (`src/`, `api/`, `supabase/`) and
`android/` for the Capacitor Android wrapper.
