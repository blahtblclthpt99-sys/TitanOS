ALTER TABLE public.contracts ADD COLUMN IF NOT EXISTS customer_signature_image text;
ALTER TABLE public.contracts ADD COLUMN IF NOT EXISTS owner_signature_image text;
ALTER TABLE public.contracts ADD COLUMN IF NOT EXISTS signed_user_agent text;
