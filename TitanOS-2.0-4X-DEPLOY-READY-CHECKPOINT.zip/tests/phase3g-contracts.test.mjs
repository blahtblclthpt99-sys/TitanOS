
import test from"node:test";import assert from"node:assert/strict";
import{configuredProviders,normalizeProviderJob}from"../api/_lib/opportunityProviders.js";

test("provider config is server-environment driven",()=>{
 const rows=configuredProviders({TITAN_JOB_FEED_URL:"https://jobs.example/search",TITAN_JOB_FEED_NAME:"Example"});
 assert.equal(rows.length,1);assert.equal(rows[0].url,"https://jobs.example/search");
});
test("client cannot choose arbitrary provider URL through provider config",()=>{
 const rows=configuredProviders({});assert.equal(rows.length,0);
});
test("provider job normalizes into external opportunity contract",()=>{
 const row=normalizeProviderJob({job_id:"7",job_title:"Driver",employer_name:"Acme",job_apply_link:"https://acme.example/apply"},{name:"Feed",type:"job_provider"});
 assert.equal(row.title,"Driver");assert.equal(row.company,"Acme");assert.equal(row.source_name,"Feed");
});
