CREATE OR REPLACE FUNCTION public.sign_public_contract_by_share_token(p_token text,p_signature text,p_signature_image text DEFAULT NULL)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE c public.contracts%ROWTYPE;
BEGIN
 IF p_token IS NULL OR length(p_token)<32 THEN RETURN NULL; END IF;
 IF nullif(trim(coalesce(p_signature,'')),'') IS NULL THEN RAISE EXCEPTION 'Signature is required'; END IF;
 UPDATE public.contracts SET customer_signature=trim(p_signature), customer_signature_image=coalesce(nullif(p_signature_image,''),customer_signature_image),
 status=CASE WHEN owner_signature IS NOT NULL THEN 'signed' ELSE status END,
 signed_at=CASE WHEN owner_signature IS NOT NULL THEN now() ELSE signed_at END, updated_at=now()
 WHERE share_token=p_token AND status='sent' RETURNING * INTO c;
 IF c.id IS NULL THEN SELECT * INTO c FROM public.contracts WHERE share_token=p_token AND status IN ('sent','signed') LIMIT 1; END IF;
 IF c.id IS NULL THEN RETURN NULL; END IF;
 RETURN jsonb_build_object('id',c.id,'customer_name',c.customer_name,'title',c.title,'body',c.body,'status',c.status,'signed_at',c.signed_at,'owner_signed',(c.owner_signature IS NOT NULL),'customer_signed',(c.customer_signature IS NOT NULL),'share_token',c.share_token);
END; $$;
REVOKE ALL ON FUNCTION public.sign_public_contract_by_share_token(text,text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.sign_public_contract_by_share_token(text,text,text) TO anon, authenticated;
