
import{applyCors,handleOptions}from"../_lib/cors.js";
import{getSupabaseAdmin,readJson}from"../_lib/supabase.js";
const bearer=req=>String(req.headers.authorization||"").replace(/^Bearer\s+/i,"");

export default async function handler(req,res){
 if(handleOptions(req,res))return;
 applyCors(req,res);
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 const admin=getSupabaseAdmin();
 const{data:u,error:e}=await admin.auth.getUser(bearer(req));
 if(e||!u?.user)return res.status(401).json({error:"Unauthorized"});
 const user=u.user,body=readJson(req),operation=body.operation||"save";
 try{
  if(operation==="get"){
   if(!body.id)return res.status(400).json({error:"id required"});
   const{data,error}=await admin.from("titan_action_runs").select("*").eq("id",String(body.id)).eq("user_id",user.id).single();
   if(error)throw error;
   return res.status(200).json({run:data});
  }
  if(operation==="list"){
   const{data,error}=await admin.from("titan_action_runs").select("*").eq("user_id",user.id).order("updated_at",{ascending:false}).limit(50);
   if(error)throw error;
   return res.status(200).json({runs:data||[]});
  }
  if(operation==="save"){
   const{operation:_,...raw}=body;
   const payload={...raw,user_id:user.id,created_by_id:user.id,updated_at:new Date().toISOString()};
   if(body.id){
    const{data,error}=await admin.from("titan_action_runs").update(payload).eq("id",body.id).eq("user_id",user.id).select().single();
    if(error)throw error;
    return res.status(200).json({run:data});
   }
   const{data,error}=await admin.from("titan_action_runs").insert(payload).select().single();
   if(error)throw error;
   return res.status(200).json({run:data});
  }
  return res.status(400).json({error:"Unknown operation"});
 }catch(error){
  return res.status(500).json({error:error?.message||"Run state failed"});
 }
}
