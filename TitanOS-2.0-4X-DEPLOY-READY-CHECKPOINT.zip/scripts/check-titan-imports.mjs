
import fs from"node:fs";import path from"node:path";
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(/\.(js|jsx|ts|tsx)$/.test(e.name))files.push(p)}}
walk("src");
const missing=[];
for(const f of files){
 const s=fs.readFileSync(f,"utf8"),rx=/from\s+["'](@\/[^"']+)["']/g;let m;
 while((m=rx.exec(s))){
  const base=m[1].replace(/^@\//,"src/");
  const c=[base,base+".js",base+".jsx",base+".ts",base+".tsx",path.join(base,"index.js"),path.join(base,"index.jsx"),path.join(base,"index.ts"),path.join(base,"index.tsx")];
  if(!c.some(x=>fs.existsSync(x)))missing.push(`${f}: ${m[1]}`);
 }
}
if(missing.length){console.error(missing.slice(0,100).join("\n"));console.error(`Missing imports: ${missing.length}`);process.exit(1)}
console.log(`Static import integrity passed (${files.length} files scanned).`);
