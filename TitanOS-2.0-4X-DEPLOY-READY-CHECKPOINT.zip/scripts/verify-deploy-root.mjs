import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const required = ['src','api','public','vercel.json','vite.config.js'];
const missing = required.filter(p => !fs.existsSync(path.join(root,p)));
if (pkg.name !== 'titanos' || pkg.version !== '2.0.0' || missing.length) {
  console.error('ERROR: Wrong TitanOS deployment root. Deploy the repository root containing TitanOS 2.0.0.');
  if (missing.length) console.error('Missing:', missing.join(', '));
  process.exit(1);
}
console.log('TitanOS deployment root verified: 2.0.0');
