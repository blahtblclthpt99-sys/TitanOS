import test from"node:test";import assert from"node:assert/strict";import fs from"node:fs";
test("TitanAI uses explicit Vercel AI Gateway transport",()=>{
 const s=fs.readFileSync("api/_lib/titanAI.js","utf8");
 assert.match(s,/ai-gateway\.vercel\.sh\/v1\/chat\/completions/);
 assert.match(s,/body:JSON\.stringify\(\{model,messages,stream:false\}\)/);
 assert.match(s,/openai\/gpt-5\.4/);
});
test("TitanAI model routing is centralized",()=>{
 const s=fs.readFileSync("api/_lib/titanAI.js","utf8");
 assert.match(s,/TITAN_AI_MODEL/);
 assert.match(s,/TITAN_AI_REASONING_MODEL/);
});
test("reasoning endpoint preserves action-engine authority",()=>{
 const s=fs.readFileSync("api/functions/titanReason.js","utf8");
 assert.match(s,/Never claim an external or consequential action was executed/);
 assert.match(s,/permission-gated action engine/);
});
