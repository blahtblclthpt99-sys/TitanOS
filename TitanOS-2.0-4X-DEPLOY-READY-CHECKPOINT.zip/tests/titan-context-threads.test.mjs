
import test from"node:test";import assert from"node:assert/strict";import{threadKey,inferThreadCandidates,shouldAutoLink,summarizeThread,generateThreadInterface}from"../src/lib/titanContextThreads.js";
test("stable thread key",()=>assert.equal(threadKey("vehicle","2004 Ford Ranger"),"vehicle:2004-ford-ranger"));
test("receipt can infer known vehicle thread",()=>{const c=inferThreadCandidates({label:"Oil filter for 2004 Ford Ranger",data:{}},{vehicles:[{id:"v1",year:2004,make:"Ford",model:"Ranger"}]});assert.equal(c[0].entity_id,"v1");assert.equal(shouldAutoLink(c[0]),true)});
test("explicit customer id produces perfect candidate",()=>{const c=inferThreadCandidates({label:"Invoice",data:{customer_id:"c1",customer_name:"Robert"}},{});assert.equal(c[0].confidence,1)});
test("thread summary counts open loops",()=>{const x=summarizeThread({thread:{label:"Truck",type:"vehicle"},nodes:[{id:"1",created_at:"2026-08-13"}],openLoops:[{status:"open"}],actions:[]});assert.equal(x.open_loop_count,1)});
test("invisible thread interface is generated from context",()=>{const ui=generateThreadInterface({title:"Truck",memory_count:2,recent:[{id:"1"}],open_loop_count:1,suggested_actions:[]});assert.equal(ui.kind,"thread_interface");assert.equal(ui.sections.length,2)});
