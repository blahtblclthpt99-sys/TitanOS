# TitanOS 2.0 — Checkpoint 4R: Release Operations

4R closes the release-process gap.

Added:
- one-command Titan release gate runner
- machine-readable `release-gate-results.json`
- staging control-plane SQL verification
- Android Digital Asset Links generator
- release secret scanner
- explicit local-vs-environment gate status

The release gate intentionally exits as BLOCKED when dependencies or staging credentials are unavailable. A blocked external gate is not converted into a pass.

To fully pass:
1. restore/install locked dependencies
2. run `node scripts/titan-release-gate.mjs`
3. run staging DB verification SQL after migrations
4. deploy server functions and test server-enforced approvals/idempotency
5. set Play signing SHA-256 fingerprints and generate/deploy `assetlinks.json`
6. run Android runtime regression
7. only then bump Android version and build AAB
