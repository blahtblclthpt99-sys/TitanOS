
import{applyCors,handleOptions}from"../_lib/cors.js";
import{getSupabaseAdmin,readJson}from"../_lib/supabase.js";
import{assertRateLimitAsync}from"../_lib/rateLimit.js";
import{titanGenerate}from"../_lib/titanAI.js";

const bearer=req=>String(req.headers.authorization||"").replace(/^Bearer\s+/i,"");

export default async function handler(req,res){
 if(handleOptions(req,res))return;
 applyCors(req,res);
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 if(!(await assertRateLimitAsync(req,res,{key:"titan-reason",limit:30,windowMs:60000})))return;
 try{
  const admin=getSupabaseAdmin();
  const{data:u,error:e}=await admin.auth.getUser(bearer(req));
  if(e||!u?.user)return res.status(401).json({error:"Unauthorized"});
  const body=readJson(req);
  const prompt=String(body.prompt||"").trim();
  if(!prompt)return res.status(400).json({error:"prompt required"});
  if(prompt.length>12000)return res.status(413).json({error:"prompt too large"});
  const result=await titanGenerate({
   prompt,
   reasoning:Boolean(body.reasoning),
   system:"You are TitanAI's reasoning layer. Interpret the user's goal and return useful reasoning or a proposed plan. Never claim an external or consequential action was executed. Execution authority belongs to TitanOS's permission-gated action engine."
  });
  return res.status(200).json({text:result.text,usage:result.usage||null});
 }catch(error){
  return res.status(500).json({error:"TitanAI reasoning failed"});
 }
}
