import fs from"node:fs";
const s=fs.readFileSync("api/_lib/titanAI.js","utf8");
const errors=[];
const usesSdk=s.includes("createGateway");
const usesRest=s.includes("https://ai-gateway.vercel.sh/v1/chat/completions")&&s.includes("Authorization:`Bearer ${credential}`");
if(!usesSdk&&!usesRest)errors.push("TitanAI is not using an approved Vercel AI Gateway transport");
if(!s.includes("AI_GATEWAY_API_KEY"))errors.push("AI_GATEWAY_API_KEY fallback missing");
if(!s.includes("VERCEL_OIDC_TOKEN"))errors.push("Vercel OIDC fallback missing");
if(/vck_[A-Za-z0-9_-]{20,}/.test(s))errors.push("literal Vercel Gateway key found");
if(/apiKey\s*:\s*["'][^"']+["']/.test(s))errors.push("literal Gateway apiKey found");
if(errors.length){console.error(errors.join("\n"));process.exit(1)}
console.log(`TitanAI Gateway authentication audit passed (${usesRest?"direct REST":"SDK"}).`);
