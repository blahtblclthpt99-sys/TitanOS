
import test from"node:test";import assert from"node:assert/strict";import{permissionClass,canExecuteWithoutPrompt,buildTrustReceipt}from"../src/lib/titanTrustReceipt.js";
test("payment remains critical",()=>assert.equal(permissionClass({type:"pay_bill"}),"critical"));
test("remember action can execute without prompt",()=>assert.equal(canExecuteWithoutPrompt({type:"remember"}),true));
test("receipt explains association",()=>{const x=buildTrustReceipt({plan:{object:{object_type:"receipt"},association:{mode:"auto",best:{thread:{label:"Truck"},score:1}},matches:[]}});assert.equal(x.association.thread,"Truck")});
