
import test from"node:test";import assert from"node:assert/strict";import{parsePersistentRule,evaluateRule,approvalRequired}from"../src/lib/titanRulesEngine.js";
test("receipt rule learns fields",()=>{const r=parsePersistentRule("From now on when I photograph a receipt remember the amount and merchant");assert.equal(r.trigger,"receipt_captured");assert.equal(r.actions[0].type,"remember_receipt_fields")});
test("appointment reminder parses days",()=>{const r=parsePersistentRule("From now on remind me 3 days before appointments");assert.equal(r.trigger,"appointment_created");assert.equal(r.actions[0].offset_days,-3)});
test("overdue invoice rule waits threshold",()=>{const r=parsePersistentRule("From now on when an invoice is 7 days overdue prepare a follow-up");assert.equal(evaluateRule(r,{type:"invoice_overdue",overdue_days:3}).matched,false);assert.equal(evaluateRule(r,{type:"invoice_overdue",overdue_days:8}).matched,true)});
test("sending followup requires approval",()=>{const r=parsePersistentRule("From now on when an invoice is 7 days overdue send a follow-up");assert.equal(approvalRequired(r.actions),true)});
