BEGIN;

ALTER TABLE public.job_checkins
  ADD COLUMN IF NOT EXISTS geofence_ok boolean,
  ADD COLUMN IF NOT EXISTS geofence_m integer;

CREATE INDEX IF NOT EXISTS idx_job_checkins_geofence_ok
  ON public.job_checkins (geofence_ok)
  WHERE geofence_ok IS NOT NULL;

COMMENT ON COLUMN public.job_checkins.geofence_ok IS
  'Whether the captured check-in coordinates were inside the job geofence.';
COMMENT ON COLUMN public.job_checkins.geofence_m IS
  'Measured distance in meters from the configured job site at check-in time.';

COMMIT;
