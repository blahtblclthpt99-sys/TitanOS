# Dependency gate

The source now requires `ai` >= 5.0.36 and package.json declares `^5.0.36`.

Run `npm install` or `npm ci` in the cloud CI environment to regenerate/validate the lockfile before merge. Do not release with package.json/package-lock out of sync.
