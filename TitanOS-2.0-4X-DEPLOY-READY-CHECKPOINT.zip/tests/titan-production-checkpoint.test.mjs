
import test from"node:test";
import assert from"node:assert/strict";
import{evaluateProductionControlCheckpoint}from"../src/lib/titanProductionCheckpoint.js";

test("4F ready with all control-plane gates",()=>{
 const x=evaluateProductionControlCheckpoint({
  server_enforcement:true,approval_server_check:true,idempotency:true,recovery:true,
  provider_allowlist:true,audit:true,tests:true,transport_contract:true
 });
 assert.equal(x.status,"ready");
 assert.equal(x.checkpoint,"4F");
});
test("4F blocks missing security gate",()=>{
 const x=evaluateProductionControlCheckpoint({tests:true});
 assert.equal(x.status,"blocked");
 assert.ok(x.failed.includes("server_enforcement"));
});
