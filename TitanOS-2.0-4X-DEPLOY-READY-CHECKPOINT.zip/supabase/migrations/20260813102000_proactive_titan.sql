
CREATE TABLE IF NOT EXISTS public.titan_open_loops(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),created_at TIMESTAMPTZ NOT NULL DEFAULT now(),updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,title TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',
 due_at TIMESTAMPTZ,important BOOLEAN NOT NULL DEFAULT false,context JSONB NOT NULL DEFAULT '{}'::jsonb,
 status TEXT NOT NULL DEFAULT 'open' CHECK(status IN('open','resolved','dismissed')),resolved_at TIMESTAMPTZ,
 created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS public.titan_attention_events(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),created_at TIMESTAMPTZ NOT NULL DEFAULT now(),user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 attention_type TEXT NOT NULL,source_table TEXT,source_id TEXT,event_type TEXT NOT NULL CHECK(event_type IN('shown','opened','dismissed','resolved','snoozed')),
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb,created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_titan_open_loops_user_status ON public.titan_open_loops(user_id,status,due_at);
CREATE INDEX IF NOT EXISTS idx_titan_attention_user_created ON public.titan_attention_events(user_id,created_at DESC);
ALTER TABLE public.titan_open_loops ENABLE ROW LEVEL SECURITY;ALTER TABLE public.titan_attention_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS titan_open_loops_owner_all ON public.titan_open_loops;CREATE POLICY titan_open_loops_owner_all ON public.titan_open_loops FOR ALL TO authenticated USING(user_id=auth.uid() OR public.is_admin()) WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
DROP POLICY IF EXISTS titan_attention_owner_all ON public.titan_attention_events;CREATE POLICY titan_attention_owner_all ON public.titan_attention_events FOR ALL TO authenticated USING(user_id=auth.uid() OR public.is_admin()) WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
NOTIFY pgrst,'reload schema';
