# TitanOS 1.6.9 Release Audit

Release candidate: `com.titanos.myapp` — versionName `1.6.9`, versionCode `32`.

## Whole-repository audit

- 1,087 source/config/resource files were read and inventoried after release binaries/signing secrets were excluded from the clean package.
- 113 Python files compile successfully.
- 333 JavaScript/MJS/CJS files pass Node syntax checking.
- All JSON files parse successfully after removing a UTF-8 BOM from `titan_memory.json`.
- No unresolved Git merge-conflict markers were found.
- The clean source package contains no upload keystore, `keystore.properties`, APK, or AAB.
- One historical migration-version collision remains: `041_titan_autopilot.sql` and `041_google_play_subscriptions.sql`. It was not renamed blindly because changing an already-applied migration identifier can desynchronize production migration history. Reconcile it against the production Supabase migration table before renaming either historical migration.

## Critical tester fixes

- Added canonical `job_checkins.geofence_m` and `job_checkins.geofence_ok` fields via an idempotent Supabase migration and triggers a PostgREST schema reload.
- Added workspace/company ownership to customers, jobs, estimates, and invoices; active workspace membership can read/update legitimate shared CRM records.
- Added server-side workspace assignment on inserts so older clients cannot accidentally create owner-only records.
- Customer deletion now detaches stale references from jobs, estimates, and invoices.
- Customer lookup failures keep sensitive details out of the UI while retaining development-only diagnostics.
- Job Create/Edit now includes Job Site Location, address geocoding/pinning, latitude/longitude persistence, and a configurable geofence radius.
- Field Ops now provides an Add location action instead of telling users to edit hidden raw coordinates.
- Check-in database failures no longer masquerade as successful check-ins. Only genuinely offline check-ins are queued with `pending_sync=true`.

## Android / Google Play hardening

- Version advanced above the uploaded baseline AAB (`1.6.8` / versionCode `31`) to `1.6.9` / versionCode `32`.
- Package identity remains `com.titanos.myapp`.
- Android backup is disabled in the release manifest.
- Location permissions required by job/geofence workflows are present.
- Launcher/PWA/splash branding was refreshed with the supplied TitanOS artwork.
- The supplied artwork is incorporated into the authentication/brand layout.
- Frontend JavaScript source maps were removed from the release AAB to reduce unnecessary source disclosure.
- Repository signing material is gitignored and the CI release-hygiene gate rejects committed keystores, live signing properties, APKs, and AABs.
- GitHub ownership/security files, Dependabot configuration, PR template, and read-only Actions permissions are included.
- The obsolete nested Android/prototype project is quarantined under `legacy/` rather than competing with the production project.

## Release verification

- AAB ZIP integrity: PASS.
- Patched production JavaScript chunks (`AuthLayout`, `Jobs`): syntax PASS.
- JAR/AAB signature verification: PASS.
- Upload certificate matches the previous AAB: PASS (`27:1D:F7:34:AD:18:7E:81:72:F2:06:59:08:E5:31:48:01:4D:B2:8C`).
- New AAB SHA-256: `af930208ee3080c59161174b9392e9931b5b81c64b848437933ed1f950d92edd`.

## Deployment dependency

Apply `supabase/migrations/20260812183000_tester_critical_workspace_geofence.sql` to the production Supabase project before or alongside the Play rollout. The mobile bundle cannot apply a server database migration by itself.

## Validation limitation

This environment could not perform a fresh dependency-driven Vite/Gradle rebuild or run Bundletool because the external package/dependency download path was unavailable. The release AAB was updated from the existing signed production bundle, patched at the bundle/resource level, syntax/integrity checked, and re-signed with the same TitanOS upload certificate. Google Play Console remains the final authoritative bundle validator at upload time.
