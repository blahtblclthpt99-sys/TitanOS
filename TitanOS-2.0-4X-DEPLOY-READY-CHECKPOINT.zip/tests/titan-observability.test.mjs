
import test from"node:test";
import assert from"node:assert/strict";
import{safeAuditEvent,workflowHealth}from"../src/lib/titanObservability.js";

test("audit strips secret metadata keys",()=>{
 const x=safeAuditEvent({type:"x",status:"ok",metadata:{token:"secret",safe:"yes"}});
 assert.equal(x.metadata.token,undefined);
 assert.equal(x.metadata.safe,"yes");
});
test("health distinguishes failed and blocked",()=>{
 assert.deepEqual(workflowHealth([{status:"ok"},{status:"failed"},{status:"blocked"}]),{total:3,failed:1,blocked:1,success_rate:33});
});
