# TitanOS 2.0 — Checkpoint 4W: Application Polish + Browser Hardening

Whole-app polish and security pass on top of 4V.

- Centralized outbound URL validation/opening.
- External opener rejects javascript/data/file protocols and HTTP by default.
- AI markdown external links restricted to HTTPS.
- Removed chart `dangerouslySetInnerHTML`; generated CSS is emitted as text after sanitizing chart IDs, keys and colors.
- Added dangerous browser API audit.
- Added production debug-output audit.
- Kept the PDF print-window exception because it opens an empty local document rather than an untrusted external URL.
- Customer Portal authentication remains memory-only from 4V.
- Existing server-side approval/idempotency boundaries remain unchanged.

Dependency/build/E2E/deployed readiness remains governed by the environment release gates.
