
ALTER TABLE public.titan_action_results
  ADD COLUMN IF NOT EXISTS action_type TEXT,
  ADD COLUMN IF NOT EXISTS blocked BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS integration_required TEXT;

CREATE INDEX IF NOT EXISTS idx_titan_action_results_user_created
  ON public.titan_action_results(user_id, created_at DESC);

NOTIFY pgrst,'reload schema';
