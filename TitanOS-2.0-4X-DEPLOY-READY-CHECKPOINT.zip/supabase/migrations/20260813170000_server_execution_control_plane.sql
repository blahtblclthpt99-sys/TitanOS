
CREATE TABLE IF NOT EXISTS public.titan_execution_audit(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 correlation_id TEXT NOT NULL,
 event_type TEXT NOT NULL,
 status TEXT NOT NULL,
 plan_id TEXT,
 action_id TEXT,
 tool TEXT,
 duration_ms INTEGER,
 error_code TEXT,
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_titan_execution_audit_user
 ON public.titan_execution_audit(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_titan_execution_audit_corr
 ON public.titan_execution_audit(user_id,correlation_id);

ALTER TABLE public.titan_execution_audit ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS titan_execution_audit_owner_read ON public.titan_execution_audit;
CREATE POLICY titan_execution_audit_owner_read ON public.titan_execution_audit
 FOR SELECT TO authenticated
 USING(user_id=auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS titan_execution_audit_owner_insert ON public.titan_execution_audit;
CREATE POLICY titan_execution_audit_owner_insert ON public.titan_execution_audit
 FOR INSERT TO authenticated
 WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());

DROP POLICY IF EXISTS titan_idempotency_owner_all ON public.titan_action_idempotency;
DROP POLICY IF EXISTS titan_idempotency_owner_read ON public.titan_action_idempotency;
CREATE POLICY titan_idempotency_owner_read ON public.titan_action_idempotency
 FOR SELECT TO authenticated
 USING(user_id=auth.uid() OR public.is_admin());

NOTIFY pgrst,'reload schema';
