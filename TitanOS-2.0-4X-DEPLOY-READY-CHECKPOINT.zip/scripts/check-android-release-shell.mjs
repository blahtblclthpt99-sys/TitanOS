
import fs from"node:fs";
const manifest=fs.readFileSync("android/app/src/main/AndroidManifest.xml","utf8");
const gradle=fs.readFileSync("android/app/build.gradle","utf8");
const cap=JSON.parse(fs.readFileSync("capacitor.config.json","utf8"));
const fail=[];
if(!manifest.includes('android:allowBackup="false"'))fail.push("Android backups must remain disabled");
if(!manifest.includes('android:usesCleartextTraffic="false"'))fail.push("Cleartext traffic must remain disabled");
if(!manifest.includes('android:launchMode="singleTask"'))fail.push("Main activity should remain singleTask for deep-link continuity");
if(!manifest.includes('android:autoVerify="true"'))fail.push("Verified HTTPS app link filter missing");
if(!manifest.includes('android:scheme="com.titanos.myapp"'))fail.push("OAuth callback scheme missing");
if(cap.appId!=="com.titanos.myapp")fail.push("Capacitor appId mismatch");
if(!gradle.includes('applicationId "com.titanos.myapp"'))fail.push("Android applicationId mismatch");
const vc=gradle.match(/versionCode\s+(\d+)/)?.[1];
if(!vc||Number(vc)<1)fail.push("Invalid Android versionCode");
if(/storePassword\s+["'][^"']+["']/.test(gradle)||/keyPassword\s+["'][^"']+["']/.test(gradle))fail.push("Hard-coded signing password detected");
if(fail.length){console.error(fail.join("\n"));process.exit(1)}
console.log(`Android release shell passed (appId ${cap.appId}, versionCode ${vc}).`);
