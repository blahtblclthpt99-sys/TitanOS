
import fs from"node:fs";import path from"node:path";
const files=[];
function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(/\.(js|jsx|ts|tsx)$/.test(e.name))files.push(p)}}
walk("src");
const violations=[];
for(const f of files){
 const s=fs.readFileSync(f,"utf8");
 if(/localStorage\.setItem\([^,]+,\s*(?:token|accessToken|refreshToken|password|secret)/i.test(s))
  violations.push(`${f}: sensitive value appears to be persisted in localStorage`);
 if(/sessionStorage\.setItem\([^,]+,\s*(?:token|accessToken|refreshToken|password|secret)/i.test(s))
  violations.push(`${f}: sensitive value appears to be persisted in sessionStorage`);
}
if(violations.length){console.error(violations.join("\n"));process.exit(1)}
console.log(`Titan browser-storage audit passed (${files.length} client files scanned).`);
