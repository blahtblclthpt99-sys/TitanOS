import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const forbidden = [
  "titanos-upload.jks",
  "titanos-upload.keystore",
  "keystore.properties",
  "UPLOAD_KEY_CREDENTIALS.txt",
];
const present = forbidden.filter((name) => fs.existsSync(path.join(root, name)));
if (present.length) {
  console.error(`Release signing material must not be committed: ${present.join(", ")}`);
  process.exit(1);
}

const trackedBinaryNames = ["TitanOS.aab", "TitanOS.apk"];
const binaries = trackedBinaryNames.filter((name) => fs.existsSync(path.join(root, name)));
if (binaries.length) {
  console.error(`Generated release binaries belong in GitHub Releases/Actions artifacts, not source: ${binaries.join(", ")}`);
  process.exit(1);
}

console.log("Release hygiene gate passed.");
