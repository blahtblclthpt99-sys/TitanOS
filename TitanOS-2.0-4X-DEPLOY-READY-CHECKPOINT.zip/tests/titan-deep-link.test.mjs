
import test from"node:test";import assert from"node:assert/strict";import{sanitizeTitanDeepLink,recoveryDeepLink,authCallbackDeepLink}from"../src/lib/titanDeepLink.js";
test("known route survives deep link sanitize",()=>assert.equal(sanitizeTitanDeepLink("https://titanos.app/titan-recovery"),"/titan-recovery"));
test("unknown route is rejected",()=>assert.equal(sanitizeTitanDeepLink("https://titanos.app/admin-secret"),"/"));
test("thread detail is allowed",()=>assert.equal(sanitizeTitanDeepLink("https://titanos.app/threads/123?x=1"),"/threads/123?x=1"));
test("recovery deep link encodes run id",()=>assert.equal(recoveryDeepLink("a b"),"/titan-action?resume_run=a%20b"));
test("oauth callback remains app-specific",()=>assert.equal(authCallbackDeepLink(),"com.titanos.myapp://auth/callback"));
