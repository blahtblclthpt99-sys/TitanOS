
-- TitanOS control-plane verification. Run in staging after migrations.
DO $$
DECLARE
  missing_count integer;
BEGIN
  SELECT count(*) INTO missing_count
  FROM (VALUES
    ('titan_action_runs'),
    ('titan_approvals'),
    ('titan_action_idempotency'),
    ('titan_execution_audit'),
    ('titan_action_plans'),
    ('titan_action_results')
  ) AS required(name)
  WHERE NOT EXISTS (
    SELECT 1 FROM information_schema.tables t
    WHERE t.table_schema='public' AND t.table_name=required.name
  );
  IF missing_count > 0 THEN
    RAISE EXCEPTION 'Titan control-plane tables missing: %', missing_count;
  END IF;
END $$;

DO $$
DECLARE
  unsecured integer;
BEGIN
  SELECT count(*) INTO unsecured
  FROM pg_class c
  JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE n.nspname='public'
    AND c.relname IN ('titan_action_runs','titan_approvals','titan_action_idempotency','titan_execution_audit','titan_action_plans','titan_action_results')
    AND NOT c.relrowsecurity;
  IF unsecured > 0 THEN
    RAISE EXCEPTION 'Titan control-plane tables without RLS: %', unsecured;
  END IF;
END $$;

-- There must be no authenticated INSERT policy for titan_action_idempotency.
DO $$
BEGIN
 IF EXISTS (
   SELECT 1 FROM pg_policies
   WHERE schemaname='public'
     AND tablename='titan_action_idempotency'
     AND roles::text LIKE '%authenticated%'
     AND cmd IN ('INSERT','ALL')
 ) THEN
   RAISE EXCEPTION 'Authenticated clients must not insert titan_action_idempotency rows';
 END IF;
END $$;

SELECT 'Titan control-plane schema verification passed' AS result;
