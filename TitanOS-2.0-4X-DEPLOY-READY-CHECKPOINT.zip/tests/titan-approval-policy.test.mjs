
import test from"node:test";import assert from"node:assert/strict";import{createScopedApproval,approvalIsUsable,revokeApproval}from"../src/lib/titanApprovalPolicy.js";
test("scoped approval validates matching plan/action/user",()=>{const a=createScopedApproval({plan_id:"p",action_id:"a",user_id:"u",scope:{amount:50}});assert.equal(approvalIsUsable(a,{plan_id:"p",action_id:"a",user_id:"u",required_scope:{amount:50}}),true)});
test("revoked approval is unusable",()=>{const a=revokeApproval(createScopedApproval({plan_id:"p",action_id:"a",user_id:"u"}));assert.equal(approvalIsUsable(a),false)});
test("scope mismatch invalidates approval",()=>{const a=createScopedApproval({plan_id:"p",action_id:"a",user_id:"u",scope:{recipient:"x"}});assert.equal(approvalIsUsable(a,{required_scope:{recipient:"y"}}),false)});
