
const groups={
 supabase:["SUPABASE_URL","SUPABASE_ANON_KEY"],
 server:["SUPABASE_SERVICE_ROLE_KEY"],
 multimodal:["TITAN_MULTIMODAL_URL"],
 jobs:["TITAN_JOB_FEED_URL"]
};
const result={};
for(const [group,keys]of Object.entries(groups)){
 const present=keys.filter(k=>Boolean(process.env[k]));
 result[group]={configured:present.length===keys.length,present,missing:keys.filter(k=>!process.env[k])};
}
console.log(JSON.stringify(result,null,2));
if(!result.supabase.configured||!result.server.configured){
 console.error("BLOCKED: core Supabase server environment is incomplete.");
 process.exit(2);
}
console.log("Core deployment environment variables are present. Provider integrations may remain optional/blocking by feature.");
