import React, { useState, useEffect, useCallback } from "react";
import { api } from "@/api/apiClient";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate, useLocation } from "react-router";
import { Briefcase, Search, Clock, MapPin, User, Calendar, CheckSquare, Square, X, ChevronDown, UserCheck, Camera, LogIn, LogOut } from "lucide-react";
import DeleteButton from "@/components/shared/DeleteButton";
import { usePullToRefresh } from "@/hooks/usePullToRefresh";
import PullToRefreshIndicator from "@/components/shared/PullToRefreshIndicator";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import NativeSelect from "@/components/shared/NativeSelect";
import EmptyState from "@/components/shared/EmptyState";
import StatusBadge from "@/components/shared/StatusBadge";
import FormField from "@/components/shared/FormField";
import PageLoader from "@/components/shared/PageLoader";
import PageHeader from "@/components/shared/PageHeader";
import PageShell from "@/components/shared/PageShell";
import FilterChip from "@/components/shared/FilterChip";
import ErrorState from "@/components/shared/ErrorState";
import VirtualList, { shouldVirtualize } from "@/components/shared/VirtualList";
import ReviewForm from "@/components/shared/ReviewForm";
import ExportMenu from "@/components/shared/ExportMenu";
import { useEntityData } from "@/hooks/useEntityData";
import { todayISO, formatMonthDay } from "@/lib/date-utils";
import { useAuth } from "@/lib/AuthContext";
import { addJobPhoto, listJobPhotos, recordCheckin } from "@/lib/jobOpsApi";
import { checklistForService } from "@/lib/checklistTemplates";
import { enqueueFollowUpsForJob } from "@/lib/followUpApi";
import { toast } from "@/components/ui/use-toast";
import { googleMapsLink, jobSiteCoords, openStreetMapEmbed } from "@/lib/geofence";
import { generateJobSummary } from "@/lib/jobSummary";
import { usePrefersReducedMotion } from "@/hooks/usePrefersReducedMotion";
import { listItemMotion } from "@/lib/listMotion";
import { jobsExportSpec } from "@/lib/export/moduleSpecs";

const PRIORITY_COLORS = {
  low: "text-muted-foreground", medium: "text-primary",
  high: "text-titan-amber", urgent: "text-red-400",
};

const BLANK_FORM = {
  title: "", description: "", customer_id: "", customer_name: "",
  status: "scheduled", priority: "medium", service_type: "",
  scheduled_date: todayISO(), scheduled_time: "09:00",
  estimated_duration: 2, address: "", amount: 0, color: "#00C7D9",
};

const JOB_STATUSES = ["scheduled", "in_progress", "completed", "cancelled"];

function normalizeChecklist(job) {
  if (Array.isArray(job?.checklist)) return job.checklist;
  return checklistForService(job?.service_type).map((label) => ({ label, done: false }));
}

function customerDisplayName(c) {
  if (!c) return "";
  const name = [c.first_name, c.last_name].filter(Boolean).join(" ").trim();
  return name || c.company_name || c.email || "Customer";
}

function moneyAmount(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export default function Jobs({ isActive = true }) {
  const reduceMotion = usePrefersReducedMotion();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const { data: [jobs, customers, employees], loading, error, reload } = useEntityData([
    { entity: "Job",      method: "list", args: ["-scheduled_date", 100] },
    { entity: "Customer", method: "list", args: ["-created_date",   100] },
    { entity: "Employee", method: "list", args: ["-created_date",   50]  },
  ], { enabled: isActive });

  const [search, setSearch]         = useState("");
  const [filter, setFilter]         = useState("all");
  const [form, setForm]             = useState(BLANK_FORM);
  const [saving, setSaving]         = useState(false);
  const [localJobs, setLocalJobs]   = useState(null);

  // Bulk selection state
  const [bulkMode, setBulkMode]     = useState(false);
  const [selected, setSelected]     = useState(new Set());
  const [bulkSaving, setBulkSaving] = useState(false);
  const [showBulkStatus, setShowBulkStatus] = useState(false);
  const [showBulkAssign, setShowBulkAssign] = useState(false);
  const [completingId, setCompletingId] = useState(null);
  const [expandedJobId, setExpandedJobId] = useState(null);
  const [jobPhotos, setJobPhotos] = useState({});
  const [opsSaving, setOpsSaving] = useState(false);
  const [checklists, setChecklists] = useState({});
  const [focusJobId, setFocusJobId] = useState(null);

  const searchParams = new URLSearchParams(location.search);
  const showForm = searchParams.get("new") === "1";
  const deepLinkId = searchParams.get("id");
  const openForm  = () => navigate("?new=1");
  const closeForm = () => navigate("/jobs", { replace: true });

  const displayJobs = localJobs ?? jobs;

  useEffect(() => { setLocalJobs(null); }, [jobs]);

  // Home / deep links: /jobs?id=...
  useEffect(() => {
    if (!isActive || !deepLinkId) return undefined;
    let alive = true;
    (async () => {
      const inList = (localJobs ?? jobs).find((j) => String(j.id) === String(deepLinkId));
      let job = inList;
      if (!job) {
        try {
          job = await api.entities.Job.get(deepLinkId);
          if (alive && job) {
            setLocalJobs((prev) => {
              const base = prev ?? jobs;
              if (base.some((j) => String(j.id) === String(job.id))) return base;
              return [job, ...base];
            });
          }
        } catch {
          if (alive) {
            toast({ title: "Job not found", description: "That job may have been deleted.", variant: "destructive" });
          }
          return;
        }
      }
      if (!alive || !job) return;
      setFocusJobId(job.id);
      setExpandedJobId(job.id);
      setChecklists((current) => ({
        ...current,
        [job.id]: current[job.id] || normalizeChecklist(job),
      }));
      try {
        const photos = await listJobPhotos(job.id);
        if (alive) setJobPhotos((current) => ({ ...current, [job.id]: photos }));
      } catch {
        if (alive) setJobPhotos((current) => ({ ...current, [job.id]: [] }));
      }
      navigate("/jobs", { replace: true });
      requestAnimationFrame(() => {
        document.getElementById(`job-row-${job.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
      });
    })();
    return () => {
      alive = false;
    };
  }, [isActive, deepLinkId, jobs, localJobs, navigate]);

  // Hydrate field-ops when panel auto-opens for in-progress/completed
  useEffect(() => {
    if (!isActive || !displayJobs.length) return undefined;
    let alive = true;
    const autoOpen = displayJobs.filter((j) => ["in_progress", "completed"].includes(j.status));
    autoOpen.forEach(async (job) => {
      if (!checklists[job.id]) {
        setChecklists((current) =>
          current[job.id] ? current : { ...current, [job.id]: normalizeChecklist(job) }
        );
      }
      if (jobPhotos[job.id] === undefined) {
        try {
          const photos = await listJobPhotos(job.id);
          if (alive) setJobPhotos((current) => ({ ...current, [job.id]: photos }));
        } catch {
          if (alive) setJobPhotos((current) => ({ ...current, [job.id]: [] }));
        }
      }
    });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isActive, displayJobs.map((j) => `${j.id}:${j.status}`).join("|")]);

  const f = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const handleSave = async () => {
    if (!form.title?.trim()) {
      toast({ title: "Title required", description: "Add a job title before creating.", variant: "destructive" });
      return;
    }
    if (!form.scheduled_date) {
      toast({ title: "Date required", description: "Pick a scheduled date.", variant: "destructive" });
      return;
    }
    setSaving(true);
    const payload = { ...form };
    const tempId = `temp_${Date.now()}`;
    setLocalJobs((prev) => [{ ...payload, id: tempId }, ...(prev ?? jobs)]);
    setForm(BLANK_FORM);
    closeForm();
    try {
      await api.entities.Job.create(payload);
      reload();
      toast({ title: "Job created" });
    } catch (err) {
      setLocalJobs(null);
      toast({
        title: "Couldn't create job",
        description: err?.message || "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const { containerRef, pullProgress, isRefreshing, pullDist } = usePullToRefresh(
    useCallback(async () => { await reload(); }, [reload])
  );

  const filtered = displayJobs
    .filter(j => filter === "all" || j.status === filter)
    .filter(j => `${j.title} ${j.customer_name ?? ""}`.toLowerCase().includes(search.toLowerCase()));

  // --- Bulk helpers ---
  const toggleSelect = (id) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleAll = () => {
    if (selected.size === filtered.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(filtered.map(j => j.id)));
    }
  };

  const exitBulk = () => {
    setBulkMode(false);
    setSelected(new Set());
  };

  const bulkUpdateStatus = async (status) => {
    setBulkSaving(true);
    setShowBulkStatus(false);
    try {
      await Promise.all([...selected].map(id => api.entities.Job.update(id, { status })));
      setLocalJobs(prev =>
        (prev ?? jobs).map(j => selected.has(j.id) ? { ...j, status } : j)
      );
      exitBulk();
      toast({ title: "Jobs updated" });
    } catch (err) {
      toast({
        title: "Couldn't update jobs",
        description: err?.message || "Please try again.",
        variant: "destructive",
      });
    } finally { setBulkSaving(false); }
  };

  const bulkAssign = async (employee) => {
    setBulkSaving(true);
    setShowBulkAssign(false);
    try {
      await Promise.all([...selected].map(id =>
        api.entities.Job.update(id, { assigned_to: employee.id, assigned_name: employee.name })
      ));
      setLocalJobs(prev =>
        (prev ?? jobs).map(j => selected.has(j.id) ? { ...j, assigned_name: employee.name, assigned_to: employee.id } : j)
      );
      exitBulk();
      toast({ title: "Assignees updated" });
    } catch (err) {
      toast({
        title: "Couldn't assign jobs",
        description: err?.message || "Please try again.",
        variant: "destructive",
      });
    } finally { setBulkSaving(false); }
  };

  const markComplete = async (job) => {
    if (job.status === "completed" || completingId) return;
    setCompletingId(job.id);
    try {
      const photos = jobPhotos[job.id] || [];
      const checklist = Array.isArray(checklists[job.id])
        ? checklists[job.id]
        : normalizeChecklist(job);
      const summary = await generateJobSummary(job, { photos, checklist });
      await api.entities.Job.update(job.id, {
        status: "completed",
        completed_at: new Date().toISOString(),
        completion_summary: summary.completion_report,
        follow_up_draft: summary.follow_up_message,
        customer_notes_draft: summary.customer_notes,
        maintenance_reminder: summary.maintenance_reminder,
      });
      try {
        if (user?.id) await enqueueFollowUpsForJob(user, job, customers.find((customer) => customer.id === job.customer_id));
      } catch {
        /* follow-up enqueue is best-effort after complete */
      }
      setLocalJobs((prev) =>
        (prev ?? jobs).map((item) =>
          item.id === job.id
            ? {
                ...item,
                status: "completed",
                completion_summary: summary.completion_report,
                follow_up_draft: summary.follow_up_message,
              }
            : item
        )
      );
      toast({
        title: "Job completed",
        description:
          summary.source === "local"
            ? "Summary written on this device."
            : summary.follow_up_message?.slice(0, 100) || summary.completion_report?.slice(0, 100),
      });
    } catch (err) {
      toast({
        title: "Couldn't complete job",
        description: err.message || "Please try again.",
        variant: "destructive",
      });
    } finally {
      setCompletingId(null);
    }
  };

  const openOps = async (job) => {
    const nextId = expandedJobId === job.id ? null : job.id;
    setExpandedJobId(nextId);
    if (nextId && !checklists[job.id]) {
      setChecklists((current) => ({ ...current, [job.id]: normalizeChecklist(job) }));
    }
    if (nextId && jobPhotos[job.id] === undefined) {
      try {
        const photos = await listJobPhotos(job.id);
        setJobPhotos((current) => ({ ...current, [job.id]: photos }));
      } catch {
        setJobPhotos((current) => ({ ...current, [job.id]: [] }));
      }
    }
  };

  const checkin = async (job, eventType) => {
    if (!user?.id || opsSaving) return;
    setOpsSaving(true);
    try {
      const result = await recordCheckin(user, { jobId: job.id, eventType, job });
      const g = result?.geofence;
      if (g?.ok === true) {
        toast({ title: "Checked in on-site", description: `${g.meters}m from job site` });
      } else if (g?.ok === false) {
        toast({ title: "Checked in (outside geofence)", description: `${g.meters}m away — site radius ${g.radius}m`, variant: "destructive" });
      } else if (g?.reason === "no_site_coords") {
        toast({ title: eventType === "check_in" ? "Checked in" : "Checked out", description: "No site coords on job — GPS logged if available" });
      } else {
        toast({ title: eventType === "check_in" ? "Checked in" : "Checked out" });
      }
    } catch (err) {
      toast({ title: "Check-in failed", description: err.message, variant: "destructive" });
    } finally {
      setOpsSaving(false);
    }
  };

  const uploadPhoto = async (job, kind, file) => {
    if (!user?.id || !file || opsSaving) return;
    setOpsSaving(true);
    try {
      const { file_url } = await api.integrations.Core.UploadFile({ file });
      const photo = await addJobPhoto(user, { jobId: job.id, kind, url: file_url });
      setJobPhotos((current) => ({ ...current, [job.id]: [photo, ...(current[job.id] || [])] }));
      toast({ title: "Photo uploaded" });
    } catch (err) {
      toast({
        title: "Couldn't upload photo",
        description: err?.message || "Please try again.",
        variant: "destructive",
      });
    } finally { setOpsSaving(false); }
  };
  const toggleChecklist = async (job, index) => {
    const base = Array.isArray(checklists[job.id]) ? checklists[job.id] : normalizeChecklist(job);
    const items = base.map((item, itemIndex) =>
      itemIndex === index ? { ...item, done: !item.done } : item
    );
    setChecklists((current) => ({ ...current, [job.id]: items }));
    try {
      await api.entities.Job.update(job.id, { checklist: items });
    } catch (err) {
      setChecklists((current) => ({ ...current, [job.id]: base }));
      toast({
        title: "Couldn't save checklist",
        description: err?.message || "Please try again.",
        variant: "destructive",
      });
    }
  };

  if (!isActive && !jobs.length) return null;
  if (loading && !jobs.length) return <PageLoader variant="list" label="Loading jobs" />;
  if (error) return <ErrorState title="Couldn't load jobs" onRetry={reload} />;

  const renderJobRow = (job) => (
    <div
      id={`job-row-${job.id}`}
      onClick={() => (bulkMode ? toggleSelect(job.id) : openOps(job))}
      className={`titan-surface p-4 transition-all ${bulkMode ? "cursor-pointer" : "titan-surface-interactive cursor-pointer"} ${
        bulkMode && selected.has(job.id) ? "border border-primary/40 bg-primary/5" : ""
      } ${focusJobId === job.id ? "ring-2 ring-primary/40" : ""}`}
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:gap-4">
        <div className="flex items-start gap-3 sm:gap-4 min-w-0 flex-1">
          {bulkMode && (
            <div className="flex-shrink-0 mt-1">
              {selected.has(job.id)
                ? <CheckSquare className="w-4 h-4 text-primary" />
                : <Square className="w-4 h-4 text-muted-foreground" />}
            </div>
          )}
          <div className="w-1 h-14 rounded-full flex-shrink-0 mt-1" style={{ backgroundColor: job.color || "#00C7D9" }} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <p className="text-sm font-semibold text-foreground break-words">{job.title}</p>
              <StatusBadge status={job.status} />
              <span className={`text-xs font-semibold ${PRIORITY_COLORS[job.priority] || PRIORITY_COLORS.medium}`}>
                ● {job.priority || "medium"}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
              {job.customer_name && <span className="flex items-center gap-1 text-xs text-muted-foreground"><User className="w-3 h-3 flex-shrink-0" />{job.customer_name}</span>}
              {job.assigned_name && <span className="flex items-center gap-1 text-xs text-muted-foreground"><UserCheck className="w-3 h-3 flex-shrink-0" />{job.assigned_name}</span>}
              <span className="flex items-center gap-1 text-xs text-muted-foreground"><Calendar className="w-3 h-3 flex-shrink-0" />{formatMonthDay(job.scheduled_date)}</span>
              {job.scheduled_time && <span className="flex items-center gap-1 text-xs text-muted-foreground"><Clock className="w-3 h-3 flex-shrink-0" />{job.scheduled_time}</span>}
              {job.address && <span className="flex items-center gap-1 text-xs text-muted-foreground max-w-full sm:max-w-[200px]"><MapPin className="w-3 h-3 flex-shrink-0" /><span className="truncate">{job.address}</span></span>}
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 sm:flex-shrink-0 sm:justify-end pl-4 sm:pl-0">
          {moneyAmount(job.amount) > 0 && (
            <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
              ${moneyAmount(job.amount).toLocaleString()}
            </p>
          )}
          {job.status !== "completed" && !bulkMode && (
            <Button
              onClick={(e) => {
                e.stopPropagation();
                markComplete(job);
              }}
              disabled={completingId === job.id}
              size="sm"
              className="bg-emerald-400/15 hover:bg-emerald-400/25 text-emerald-700 dark:text-emerald-300 border border-emerald-400/20 rounded-lg text-xs min-h-[36px]"
            >
              {completingId === job.id ? "Saving…" : "Complete"}
            </Button>
          )}
          {!bulkMode && (
            <Button
              onClick={(e) => {
                e.stopPropagation();
                openOps(job);
              }}
              variant="outline"
              size="sm"
              className="border-border text-foreground/90 rounded-lg text-xs min-h-[36px]"
            >
              Field ops
            </Button>
          )}
          {!bulkMode && (
            <div onClick={(e) => e.stopPropagation()}>
              <DeleteButton
                label={job.title || "this job"}
                onDelete={async () => {
                  await api.entities.Job.delete(job.id);
                  setLocalJobs((prev) => (prev ?? jobs).filter((j) => j.id !== job.id));
                  reload();
                }}
              />
            </div>
          )}
        </div>
      </div>
      {(expandedJobId === job.id || ["in_progress", "completed"].includes(job.status)) && !bulkMode && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => checkin(job, "check_in")} disabled={opsSaving} size="sm" className="bg-primary/15 text-primary border border-primary/20"><LogIn className="w-4 h-4 mr-1" />Check in</Button>
            <Button onClick={() => checkin(job, "check_out")} disabled={opsSaving} size="sm" variant="outline" className="border-border text-foreground"><LogOut className="w-4 h-4 mr-1" />Check out</Button>
            {["before", "after"].map((kind) => <label key={kind} className="inline-flex items-center cursor-pointer h-9 px-3 rounded-md border border-border text-xs text-foreground/90 hover:bg-muted"><Camera className="w-4 h-4 mr-1" />{kind === "before" ? "Before photo" : "After photo"}<input type="file" accept="image/*" className="hidden" onChange={(e) => uploadPhoto(job, kind, e.target.files?.[0])} /></label>)}
          </div>
          {(() => {
            const site = jobSiteCoords(job);
            if (!site) return <p className="text-xs text-muted-foreground mt-2">Add site lat/lng on the job for geofence proof.</p>;
            return (
              <div className="mt-3 rounded-xl overflow-hidden border border-border">
                <iframe title="Job site map" src={openStreetMapEmbed(site.lat, site.lng)} className="w-full h-36 border-0" loading="lazy" />
                <a href={googleMapsLink(site.lat, site.lng)} target="_blank" rel="noreferrer" className="block text-xs text-primary px-3 py-2 bg-muted/40">Open site in Maps · geofence {job.geofence_m || 150}m</a>
              </div>
            );
          })()}
          {!!(checklists[job.id] || normalizeChecklist(job)).length && (
            <div className="mt-3 grid sm:grid-cols-2 gap-2">
              {(checklists[job.id] || normalizeChecklist(job)).map((item, index) => (
                <button
                  key={`${item.label}-${index}`}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleChecklist(job, index);
                  }}
                  className="text-left text-xs text-foreground/85 flex items-center gap-2"
                >
                  <span className={item.done ? "text-primary" : "text-muted-foreground"}>
                    {item.done ? "✓" : "○"}
                  </span>
                  {item.label}
                </button>
              ))}
            </div>
          )}
          {!!jobPhotos[job.id]?.length && (
            <div className="mt-3 space-y-2">
              <div className="flex flex-wrap gap-2">
                {jobPhotos[job.id].map((photo) => (
                  <a key={photo.id} href={photo.url} target="_blank" rel="noreferrer" className="relative">
                    <img src={photo.url} alt={`${photo.kind || "Job"} photo`} className="w-16 h-16 object-cover rounded-lg border border-border" />
                    <span className="absolute bottom-0 left-0 right-0 text-[9px] text-center bg-black/60 capitalize">{photo.kind}</span>
                  </a>
                ))}
              </div>
              <Button
                size="sm"
                variant="outline"
                className="border-border text-foreground text-xs"
                onClick={() => {
                  const after = jobPhotos[job.id].find((p) => p.kind === "after") || jobPhotos[job.id][0];
                  const text = `Before & after from ${job.title || "our latest job"} — powered by TitanOS`;
                  if (navigator.share) {
                    navigator.share({ title: job.title || "Job gallery", text, url: after.url }).catch(() => {});
                  } else {
                    navigator.clipboard?.writeText(`${text}\n${after.url}`);
                    toast({ title: "Gallery link copied" });
                  }
                }}
              >
                Share before/after
              </Button>
            </div>
          )}
        </div>
      )}
      {job.status === "completed" && !bulkMode && (
        <div className="mt-4 pt-4 border-t border-border space-y-3">
          {(job.completion_summary || job.follow_up_draft) && (
            <div className="rounded-xl bg-muted/50 p-3 text-xs text-foreground/90 space-y-2">
              <p className="font-semibold text-primary">Job summary</p>
              {job.completion_summary && <p>{job.completion_summary}</p>}
              {job.follow_up_draft && (
                <button
                  type="button"
                  className="text-primary underline"
                  onClick={() => {
                    navigator.clipboard?.writeText(job.follow_up_draft);
                    toast({ title: "Follow-up copied" });
                  }}
                >
                  Copy follow-up message
                </button>
              )}
            </div>
          )}
          <ReviewForm
            jobId={job.id}
            revieweeId={job.customer_id || job.assigned_to || ""}
            reviewerRole="worker"
            onSubmitted={reload}
          />
        </div>
      )}
    </div>
  );

  return (
    <PageShell maxWidth="xl" className="overflow-y-auto" style={{ overscrollBehavior: "contain" }} ref={containerRef}>
      <PullToRefreshIndicator pullProgress={pullProgress} isRefreshing={isRefreshing} pullDist={pullDist} />

      <PageHeader
        eyebrow="Daily work"
        title="Jobs"
        subtitle={`${jobs.length} total · Create, assign, and track every job from quote to done.`}
        actions={
          <>
            <ExportMenu spec={jobsExportSpec(jobs)} size="sm" />
            {!bulkMode && (
              <Button type="button" variant="outline" size="sm" onClick={() => setBulkMode(true)} className="gap-1.5">
                <CheckSquare className="w-3.5 h-3.5" aria-hidden="true" /> Bulk edit
              </Button>
            )}
          </>
        }
        onAdd={openForm}
        addLabel="New job"
      />

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
          <Input
            placeholder="Search jobs…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Search jobs"
            className="pl-11 bg-card border-border text-foreground rounded-md h-11 placeholder:text-muted-foreground/80"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1" role="group" aria-label="Filter by status">
          {["all", "scheduled", "in_progress", "completed", "cancelled"].map((s) => (
            <FilterChip key={s} active={filter === s} onClick={() => setFilter(s)}>
              {s === "all" ? "All" : s.replace("_", " ")}
            </FilterChip>
          ))}
        </div>
      </div>

      {/* Bulk mode header */}
      {bulkMode && (
        <div className="flex items-center gap-3 mb-4 p-3 bg-primary/5 border border-primary/20 rounded-2xl">
          <button onClick={toggleAll} className="flex items-center gap-2 text-sm text-foreground/90 hover:text-foreground transition-colors">
            {selected.size === filtered.length && filtered.length > 0
              ? <CheckSquare className="w-4 h-4 text-primary" />
              : <Square className="w-4 h-4" />}
            {selected.size > 0 ? `${selected.size} selected` : "Select all"}
          </button>
          <button onClick={exitBulk} className="ml-auto text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {filtered.length === 0 && !search && filter === "all" ? (
        <EmptyState icon={Briefcase} title="No jobs yet" description="Create your first job to start tracking work." onAction={openForm} actionLabel="New Job" />
      ) : filtered.length === 0 ? (
        <EmptyState title="No matches" description="No jobs match your filter. Try clearing search or status." className="py-12" />
      ) : shouldVirtualize(filtered.length) && !expandedJobId ? (
        <VirtualList
          items={filtered}
          renderItem={renderJobRow}
          estimateSize={180}
          className="pb-28"
          scrollRef={containerRef}
        />
      ) : (
        <div className="space-y-2 pb-28">
          {filtered.map((job, i) => (
            <motion.div key={job.id} {...listItemMotion(reduceMotion, i)}>
              {renderJobRow(job)}
            </motion.div>
          ))}
        </div>
      )}

      {/* Floating bulk action bar */}
      <AnimatePresence>
        {bulkMode && selected.size > 0 && (
          <motion.div
            initial={reduceMotion ? false : { y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={reduceMotion ? { opacity: 0 } : { y: 80, opacity: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.2 }}
            className="fixed left-1/2 -translate-x-1/2 z-[60] flex flex-wrap items-center justify-center gap-2 bg-card border border-border rounded-2xl shadow-2xl px-4 py-3 max-w-[calc(100vw-1.5rem)]"
            style={{
              bottom: "var(--mobile-chrome-bottom, calc(6.75rem + env(safe-area-inset-bottom, 0px)))",
            }}
          >
            <span className="text-xs text-muted-foreground mr-1">{selected.size} job{selected.size > 1 ? "s" : ""}</span>

            {/* Status dropdown */}
            <div className="relative">
              <button
                onClick={() => { setShowBulkStatus(p => !p); setShowBulkAssign(false); }}
                className="flex items-center gap-1.5 bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20 rounded-xl px-3 py-2 text-xs font-medium transition-all"
              >
                Set Status <ChevronDown className="w-3 h-3" />
              </button>
              {showBulkStatus && (
                <div className="absolute bottom-full mb-2 left-0 bg-muted border border-border rounded-xl overflow-hidden shadow-xl min-w-[140px]">
                  {JOB_STATUSES.map(s => (
                    <button key={s} onClick={() => bulkUpdateStatus(s)}
                      className="w-full text-left px-4 py-2.5 text-xs text-foreground hover:bg-muted hover:text-foreground capitalize transition-colors">
                      {s.replace("_", " ")}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Assign dropdown */}
            <div className="relative">
              <button
                onClick={() => { setShowBulkAssign(p => !p); setShowBulkStatus(false); }}
                className="flex items-center gap-1.5 bg-titan-indigo/10 hover:bg-titan-indigo/20 text-purple-300 border border-titan-indigo/20 rounded-xl px-3 py-2 text-xs font-medium transition-all"
              >
                Assign To <ChevronDown className="w-3 h-3" />
              </button>
              {showBulkAssign && (
                <div className="absolute bottom-full mb-2 left-0 bg-muted border border-border rounded-xl overflow-hidden shadow-xl min-w-[160px]">
                  {(employees || []).filter(e => e.status === "active").map(emp => (
                    <button key={emp.id} onClick={() => bulkAssign(emp)}
                      className="w-full text-left px-4 py-2.5 text-xs text-foreground hover:bg-muted hover:text-foreground transition-colors">
                      {emp.name}
                    </button>
                  ))}
                  {(employees || []).filter(e => e.status === "active").length === 0 && (
                    <p className="px-4 py-3 text-xs text-muted-foreground">No active employees</p>
                  )}
                </div>
              )}
            </div>

            {bulkSaving && <span className="text-xs text-muted-foreground ml-1">Saving…</span>}
          </motion.div>
        )}
      </AnimatePresence>

      <Dialog open={showForm} onOpenChange={open => { if (!open) closeForm(); }}>
        <DialogContent className="bg-card border-border text-foreground max-w-lg  max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-foreground text-lg">New Job</DialogTitle>
            <DialogDescription>Schedule a job with customer, timing, and site details.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <FormField label="Job Title" value={form.title} onChange={e => f("title", e.target.value)} placeholder="e.g. Full house cleaning" />
            <FormField label="Customer">
              <NativeSelect
                value={form.customer_id}
                onValueChange={v => {
                  const c = customers.find(c => c.id === v);
                  setForm(prev => ({
                    ...prev,
                    customer_id: v,
                    customer_name: customerDisplayName(c),
                    address: c?.address || prev.address,
                  }));
                }}
                placeholder="Select customer"
                options={customers.map(c => ({ value: c.id, label: customerDisplayName(c) }))}
                className="mt-1"
              />
            </FormField>
            <div className="grid grid-cols-2 gap-3">
              <FormField label="Date" type="date" value={form.scheduled_date} onChange={e => f("scheduled_date", e.target.value)} />
              <FormField label="Time" type="time" value={form.scheduled_time} onChange={e => f("scheduled_time", e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <FormField label="Priority">
                <NativeSelect
                  value={form.priority}
                  onValueChange={v => f("priority", v)}
                  placeholder="Priority"
                  options={["low","medium","high","urgent"].map(p => ({ value: p, label: p }))}
                  className="mt-1"
                />
              </FormField>
              <FormField label="Amount ($)" type="number" value={form.amount} onChange={e => f("amount", parseFloat(e.target.value) || 0)} />
            </div>
            <FormField label="Address" value={form.address} onChange={e => f("address", e.target.value)} />
            <FormField label="Description">
              <Textarea
                id="job-description"
                value={form.description}
                onChange={(e) => f("description", e.target.value)}
                className="bg-muted border-border text-foreground rounded-md min-h-[80px]"
              />
            </FormField>
            <Button onClick={handleSave} disabled={saving || !form.title?.trim() || !form.scheduled_date} className="w-full h-11">
              {saving ? "Creating..." : "Create job"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </PageShell>
  );
}