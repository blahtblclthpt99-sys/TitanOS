/**
 * Founding 25 lifetime Pro + 3-day Starter trial + catalog prices (pure).
 */
import assert from "node:assert/strict";
import { describe, it, beforeEach } from "node:test";
import { readFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import {
  FOUNDING_USER_CAP,
  normalizeLaunchStatus,
  applyLaunchStatus,
  isBetaActive,
  isMembershipCheckoutLive,
} from "../src/lib/launchStatus.js";
import {
  isFreeDuringBeta,
  getPlanCheckoutUrl,
  betaBadgeLabel,
  isFoundingUser,
  isFoundingTrialActive,
  canAccessFeature,
  PRO_FEATURES,
  PLANS,
} from "../src/lib/plan.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

beforeEach(() => {
  applyLaunchStatus({
    foundingCap: 25,
    foundingClaimed: 0,
    betaActive: true,
    membershipPaymentsLive: true,
  });
});

describe("founding launch status", () => {
  it("cap is 25", () => {
    assert.equal(FOUNDING_USER_CAP, 25);
  });

  it("normalizes spots; checkout stays live while enrollment open", () => {
    const open = normalizeLaunchStatus({ founding_cap: 25, founding_claimed: 12, beta_active: true });
    assert.equal(open.spotsRemaining, 13);
    assert.equal(open.membershipPaymentsLive, true);

    const closed = normalizeLaunchStatus({
      foundingCap: 25,
      foundingClaimed: 25,
      betaActive: false,
      membershipPaymentsLive: true,
    });
    assert.equal(closed.spotsRemaining, 0);
    assert.equal(closed.membershipPaymentsLive, true);
  });

  it("uses server-created Stripe checkout while founding enrollment is open", () => {
    assert.equal(isFreeDuringBeta(), true);
    assert.equal(isMembershipCheckoutLive(), true);
    assert.equal(getPlanCheckoutUrl("worker_premium"), null);
    assert.equal(getPlanCheckoutUrl("starter"), null);
    const pricing = readFileSync(join(root, "src/pages/Pricing.jsx"), "utf8");
    assert.match(pricing, /startStripeSubscription/);
    assert.doesNotMatch(pricing, /paypal\.com/i);
  });

  it("catalog prices are Starter 4.99 / Pro 9.99 / Business 19.99", () => {
    assert.equal(PLANS.starter.priceMonthly, 4.99);
    assert.equal(PLANS.worker_premium.priceMonthly, 9.99);
    assert.equal(PLANS.worker_premium.mostPopular, true);
    assert.equal(PLANS.business.priceMonthly, 19.99);
  });

  it("Founding 25 is lifetime Pro and post-cap trial is Starter-only", () => {
    applyLaunchStatus({ foundingCap: 25, foundingClaimed: 25, betaActive: false, membershipPaymentsLive: true });
    const founder = { id: "u1", founding_user: true, founding_number: 7, lifetime_premium: true, plan_tier: "worker_premium" };
    assert.ok(isFoundingUser(founder));
    assert.match(betaBadgeLabel(founder), /Founding #7/);
    assert.equal(canAccessFeature(founder, PRO_FEATURES.aiAssistant), true);

    const trial = { id: "u2", founding_user: false, app_trial_ends_at: new Date(Date.now() + 86400000).toISOString(), plan_tier: "worker_free" };
    assert.equal(canAccessFeature(trial, PRO_FEATURES.driverAddons), true);
    assert.equal(canAccessFeature(trial, PRO_FEATURES.aiAssistant), false);
  });

  it("current Founding 25 migration ships lifetime access and post-cap trial", () => {
    const migration = join(root, "supabase/migrations/20260813223541_founding_25_lifetime_and_three_day_trial.sql");
    assert.ok(existsSync(migration));
    const sql = readFileSync(migration, "utf8");
    assert.match(sql, /25/);
    assert.match(sql, /lifetime_premium/);
    assert.match(sql, /app_trial_ends_at/);
    assert.match(sql, /3 days/);
  });
});
