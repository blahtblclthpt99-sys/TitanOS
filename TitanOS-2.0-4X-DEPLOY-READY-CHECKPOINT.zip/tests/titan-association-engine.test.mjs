
import test from"node:test";import assert from"node:assert/strict";import{rankThreadAssociations,associationDecision}from"../src/lib/titanAssociationEngine.js";
test("explicit vehicle relation auto associates",()=>{const r=rankThreadAssociations({object_type:"receipt",data:{vehicle_id:"v1"}},[{id:"t1",type:"vehicle",label:"Ford Ranger",entity_id:"v1"}]);assert.equal(associationDecision(r).mode,"auto")});
test("weak unrelated object does not silently link",()=>{const r=rankThreadAssociations({object_type:"document",data:{title:"Lease"}},[{id:"t1",type:"vehicle",label:"Ford Ranger"}]);assert.equal(associationDecision(r).mode,"none")});
