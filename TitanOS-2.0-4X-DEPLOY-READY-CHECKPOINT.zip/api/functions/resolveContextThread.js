
import{applyCors,handleOptions}from"../_lib/cors.js";
import{getSupabaseAdmin,readJson}from"../_lib/supabase.js";
import{assertRateLimit}from"../_lib/rateLimit.js";
const bearer=req=>String(req.headers.authorization||"").replace(/^Bearer\s+/i,"");
const norm=v=>String(v||"").trim().toLowerCase();

export default async function handler(req,res){
 if(handleOptions(req,res))return;applyCors(req,res);
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 try{
  await assertRateLimit(req,res,{key:"context-thread",limit:30,windowMs:60_000});
  const admin=getSupabaseAdmin(),{data:userData,error:userError}=await admin.auth.getUser(bearer(req));
  if(userError||!userData?.user)return res.status(401).json({error:"Unauthorized"});
  const user=userData.user,body=readJson(req),query=norm(body.query);
  if(!query)return res.status(400).json({error:"Query required"});

  const {data:threads,error:tErr}=await admin.from("titan_threads").select("*").eq("user_id",user.id).limit(200);
  if(tErr)throw tErr;
  const scored=(threads||[]).map(t=>{
   const label=norm(t.label),key=norm(t.thread_key);
   let score=0;
   if(query===label)score=100;
   else if(query.includes(label)||label.includes(query))score=90;
   else{
    const words=query.split(/\s+/).filter(x=>x.length>2);
    score=Math.round(words.filter(w=>label.includes(w)||key.includes(w)).length/Math.max(1,words.length)*80);
   }
   return{...t,match_score:score};
  }).sort((a,b)=>b.match_score-a.match_score);
  const thread=scored[0];
  if(!thread||thread.match_score<40)return res.status(200).json({thread:null,items:[],open_loops:[],suggested_actions:[]});

  const {data:links}=await admin.from("titan_thread_items").select("*").eq("thread_id",thread.id).limit(200);
  const nodeIds=(links||[]).map(x=>x.memory_node_id).filter(Boolean);
  let nodes=[];
  if(nodeIds.length){
   const result=await admin.from("titan_memory_nodes").select("*").in("id",nodeIds).eq("user_id",user.id);
   if(result.error)throw result.error;nodes=result.data||[];
  }
  const {data:loops}=await admin.from("titan_open_loops").select("*").eq("user_id",user.id).eq("status","open").contains("context",{thread_id:thread.id}).limit(50);

  const suggested=[];
  if(thread.type==="vehicle")suggested.push({label:"Review maintenance",command:`Show maintenance for ${thread.label}`},{label:"Add expense",command:`Add an expense to ${thread.label}`});
  if(thread.type==="customer")suggested.push({label:"View jobs",command:`Show jobs for ${thread.label}`},{label:"Check invoices",command:`Show invoices for ${thread.label}`});
  if(thread.type==="project")suggested.push({label:"Review status",command:`What's the status of ${thread.label}?`});

  return res.status(200).json({thread,items:nodes,open_loops:loops||[],suggested_actions:suggested});
 }catch(error){return res.status(error?.status||500).json({error:error?.message||"Thread resolution failed"});}
}
