
import test from"node:test";import assert from"node:assert/strict";import{evaluateCheckpoint4W}from"../src/lib/titanCheckpoint4W.js";
test("4W verifies only with every hardening gate",()=>{const keys=["tests","control_plane","imports","plan_security","storage","dangerous_apis","debug_output","android","secrets","syntax"];assert.equal(evaluateCheckpoint4W(Object.fromEntries(keys.map(k=>[k,true]))).status,"verified")});
test("4W blocks missing dangerous API audit",()=>assert.ok(evaluateCheckpoint4W({tests:true}).failed.includes("dangerous_apis")));
