
CREATE TABLE IF NOT EXISTS public.titan_multimodal_analyses(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,input_kind TEXT NOT NULL,source_name TEXT,source_ref TEXT,provider_name TEXT,
 object_type TEXT,confidence NUMERIC(4,3),analysis JSONB NOT NULL DEFAULT '{}'::jsonb,structured_object JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_by_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_titan_multimodal_user_created ON public.titan_multimodal_analyses(user_id,created_at DESC);
ALTER TABLE public.titan_multimodal_analyses ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS titan_multimodal_owner_all ON public.titan_multimodal_analyses;
CREATE POLICY titan_multimodal_owner_all ON public.titan_multimodal_analyses FOR ALL TO authenticated USING(user_id=auth.uid() OR public.is_admin()) WITH CHECK(user_id=auth.uid() AND created_by_id=auth.uid());
NOTIFY pgrst,'reload schema';
