
import test from"node:test";import assert from"node:assert/strict";import{releaseStatus}from"../src/lib/titanReleaseStatus.js";
test("code-only verification is checkpoint not candidate",()=>assert.equal(releaseStatus({codeVerified:true}).stage,"checkpoint"));
test("all verification yields release candidate",()=>assert.equal(releaseStatus({codeVerified:true,environmentVerified:true,mobileVerified:true}).stage,"release_candidate"));
