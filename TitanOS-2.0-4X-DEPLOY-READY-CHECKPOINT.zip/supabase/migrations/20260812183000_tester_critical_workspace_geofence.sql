-- TitanOS tester critical fix: workspace customer access + job geofence schema parity
-- Safe/idempotent production migration.

-- Canonical job_checkins geofence fields used by the web/mobile client.
ALTER TABLE public.job_checkins
  ADD COLUMN IF NOT EXISTS geofence_ok BOOLEAN,
  ADD COLUMN IF NOT EXISTS geofence_m INTEGER;

COMMENT ON COLUMN public.job_checkins.geofence_m IS
  'Measured distance in meters between check-in GPS and the configured job site.';
COMMENT ON COLUMN public.job_checkins.geofence_ok IS
  'True when the recorded position was inside the configured job geofence.';

-- Business/workspace ownership for shared CRM records.
ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS company_id TEXT;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS company_id TEXT;
ALTER TABLE public.estimates ADD COLUMN IF NOT EXISTS company_id TEXT;
ALTER TABLE public.invoices ADD COLUMN IF NOT EXISTS company_id TEXT;

CREATE INDEX IF NOT EXISTS idx_customers_company ON public.customers(company_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_company ON public.jobs(company_id, scheduled_date DESC);
CREATE INDEX IF NOT EXISTS idx_estimates_company ON public.estimates(company_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_invoices_company ON public.invoices(company_id, created_at DESC);

CREATE OR REPLACE FUNCTION public.is_company_member(target_company_id TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT target_company_id IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM public.company_members m
      WHERE m.company_id = target_company_id
        AND m.user_id = auth.uid()::text
        AND m.status = 'active'
    );
$$;

REVOKE ALL ON FUNCTION public.is_company_member(TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_company_member(TEXT) TO authenticated;

-- Backfill the creator's active company when it is still available.
UPDATE public.customers r
SET company_id = p.active_company_id
FROM public.profiles p
WHERE r.company_id IS NULL
  AND r.created_by_id = p.id
  AND NULLIF(p.active_company_id, '') IS NOT NULL;

UPDATE public.jobs r
SET company_id = p.active_company_id
FROM public.profiles p
WHERE r.company_id IS NULL
  AND r.created_by_id = p.id
  AND NULLIF(p.active_company_id, '') IS NOT NULL;

UPDATE public.estimates r
SET company_id = p.active_company_id
FROM public.profiles p
WHERE r.company_id IS NULL
  AND r.created_by_id = p.id
  AND NULLIF(p.active_company_id, '') IS NOT NULL;

UPDATE public.invoices r
SET company_id = p.active_company_id
FROM public.profiles p
WHERE r.company_id IS NULL
  AND r.created_by_id = p.id
  AND NULLIF(p.active_company_id, '') IS NOT NULL;

-- Keep workspace ownership correct even for older clients that do not yet send company_id.
-- This runs before RLS evaluation and derives the workspace only from the authenticated
-- user's own profile; callers cannot use it to claim another workspace.
CREATE OR REPLACE FUNCTION public.assign_active_company_id()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.company_id IS NULL AND auth.uid() IS NOT NULL THEN
    SELECT p.active_company_id
      INTO NEW.company_id
      FROM public.profiles p
     WHERE p.id = auth.uid()::text
       AND NULLIF(p.active_company_id, '') IS NOT NULL
     LIMIT 1;
  END IF;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.assign_active_company_id() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_customers_assign_active_company ON public.customers;
CREATE TRIGGER trg_customers_assign_active_company
  BEFORE INSERT ON public.customers
  FOR EACH ROW EXECUTE FUNCTION public.assign_active_company_id();

DROP TRIGGER IF EXISTS trg_jobs_assign_active_company ON public.jobs;
CREATE TRIGGER trg_jobs_assign_active_company
  BEFORE INSERT ON public.jobs
  FOR EACH ROW EXECUTE FUNCTION public.assign_active_company_id();

DROP TRIGGER IF EXISTS trg_estimates_assign_active_company ON public.estimates;
CREATE TRIGGER trg_estimates_assign_active_company
  BEFORE INSERT ON public.estimates
  FOR EACH ROW EXECUTE FUNCTION public.assign_active_company_id();

DROP TRIGGER IF EXISTS trg_invoices_assign_active_company ON public.invoices;
CREATE TRIGGER trg_invoices_assign_active_company
  BEFORE INSERT ON public.invoices
  FOR EACH ROW EXECUTE FUNCTION public.assign_active_company_id();

-- Workspace members can legitimately read/update shared CRM data.
DROP POLICY IF EXISTS customers_company_read ON public.customers;
CREATE POLICY customers_company_read ON public.customers
  FOR SELECT TO authenticated
  USING (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  );

DROP POLICY IF EXISTS customers_company_update ON public.customers;
CREATE POLICY customers_company_update ON public.customers
  FOR UPDATE TO authenticated
  USING (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  )
  WITH CHECK (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  );

DROP POLICY IF EXISTS jobs_company_read ON public.jobs;
CREATE POLICY jobs_company_read ON public.jobs
  FOR SELECT TO authenticated
  USING (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  );

DROP POLICY IF EXISTS jobs_company_update ON public.jobs;
CREATE POLICY jobs_company_update ON public.jobs
  FOR UPDATE TO authenticated
  USING (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  )
  WITH CHECK (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  );

DROP POLICY IF EXISTS estimates_company_read ON public.estimates;
CREATE POLICY estimates_company_read ON public.estimates
  FOR SELECT TO authenticated
  USING (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  );

DROP POLICY IF EXISTS estimates_company_update ON public.estimates;
CREATE POLICY estimates_company_update ON public.estimates
  FOR UPDATE TO authenticated
  USING (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  )
  WITH CHECK (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  );

DROP POLICY IF EXISTS invoices_company_read ON public.invoices;
CREATE POLICY invoices_company_read ON public.invoices
  FOR SELECT TO authenticated
  USING (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  );

DROP POLICY IF EXISTS invoices_company_update ON public.invoices;
CREATE POLICY invoices_company_update ON public.invoices
  FOR UPDATE TO authenticated
  USING (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  )
  WITH CHECK (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR public.is_company_member(company_id)
  );

-- Check-ins are readable by their creator or by members of the job's workspace.
DROP POLICY IF EXISTS job_checkins_workspace_read ON public.job_checkins;
CREATE POLICY job_checkins_workspace_read ON public.job_checkins
  FOR SELECT TO authenticated
  USING (
    created_by_id = auth.uid()
    OR public.is_admin()
    OR EXISTS (
      SELECT 1
      FROM public.jobs j
      WHERE j.id::text = job_checkins.job_id
        AND public.is_company_member(j.company_id)
    )
  );

-- Remove stale CRM references when a customer is deleted so deleted contacts
-- cannot remain clickable through jobs/estimates/invoices.
CREATE OR REPLACE FUNCTION public.detach_deleted_customer_references()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.jobs
     SET customer_id = NULL
   WHERE customer_id = OLD.id::text;

  UPDATE public.estimates
     SET customer_id = NULL
   WHERE customer_id = OLD.id::text;

  UPDATE public.invoices
     SET customer_id = NULL
   WHERE customer_id = OLD.id::text;

  RETURN OLD;
END;
$$;

DROP TRIGGER IF EXISTS trg_detach_deleted_customer_references ON public.customers;
CREATE TRIGGER trg_detach_deleted_customer_references
  AFTER DELETE ON public.customers
  FOR EACH ROW EXECUTE FUNCTION public.detach_deleted_customer_references();

-- Ask PostgREST to refresh the schema cache after deployment.
NOTIFY pgrst, 'reload schema';
