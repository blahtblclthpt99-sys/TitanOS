
import test from"node:test";import assert from"node:assert/strict";import{retryDelayMs,canRetry,nextRetryState}from"../src/lib/titanRetryPolicy.js";
test("retry delay grows with attempts",()=>assert.ok(retryDelayMs(3)>retryDelayMs(1)));
test("validation errors are not retried",()=>assert.equal(canRetry({attempt:0,last_error_code:"validation_error"}),false));
test("retry state records next retry",()=>{const r=nextRetryState({retry_count:0},{code:"timeout",message:"x"});assert.equal(r.retry_count,1);assert.ok(r.next_retry_at)});
