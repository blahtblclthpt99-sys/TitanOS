
function clean(v,max=8000){return String(v||"").replace(/\s+/g," ").trim().slice(0,max);}
export function configuredMultimodalProvider(env=process.env){if(!env.TITAN_MULTIMODAL_URL)return null;return{name:env.TITAN_MULTIMODAL_NAME||"Configured Multimodal Provider",url:env.TITAN_MULTIMODAL_URL,token:env.TITAN_MULTIMODAL_TOKEN||""};}
export async function analyzeWithProvider(provider,payload){
 if(!provider)throw new Error("No multimodal provider configured");
 const headers={"Content-Type":"application/json","Accept":"application/json"};if(provider.token)headers.Authorization=`Bearer ${provider.token}`;
 const response=await fetch(provider.url,{method:"POST",headers,body:JSON.stringify({kind:payload.kind,file_url:payload.file_url||null,file_name:clean(payload.file_name,500),file_type:clean(payload.file_type,200),text:clean(payload.text,12000),context:payload.context||{}}),signal:AbortSignal.timeout(20000)});
 if(!response.ok)throw new Error(`${provider.name} returned ${response.status}`);const body=await response.json();return body?.analysis||body;
}
