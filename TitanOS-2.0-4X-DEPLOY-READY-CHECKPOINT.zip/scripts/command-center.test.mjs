import test from "node:test";
import assert from "node:assert/strict";
import {
  buildCredentialAlerts,
  buildCustomerFollowUps,
  countAssignedToday,
  countVehicleAlerts,
} from "../src/lib/commandCenter.js";

test("Command Center ranks only expiring credential alerts", () => {
  const rows = [
    { id: "current", days: 90 },
    { id: "soon", days: 10 },
    { id: "expired", days: -2 },
  ];
  const alerts = buildCredentialAlerts(rows, (row) => ({ id: row.id, days: row.days }));
  assert.deepEqual(alerts.map((row) => row.credential.id), ["expired", "soon"]);
});

test("Command Center follow-up queue keeps lead-like customers only", () => {
  const rows = [
    { id: 1, first_name: "Ada", last_name: "Lead", status: "lead" },
    { id: 2, first_name: "Pat", last_name: "Active", status: "active" },
    { id: 3, company_name: "North Co", status: "prospect" },
  ];
  assert.deepEqual(buildCustomerFollowUps(rows).map((row) => row.name), ["Ada Lead", "North Co"]);
});

test("Command Center counts unique assigned team members", () => {
  assert.equal(countAssignedToday([
    { assigned_name: "Alex" },
    { assigned_name: "Alex" },
    { assigned_name: "Sam" },
    { assigned_name: "" },
  ]), 2);
});

test("Command Center flags fleet deadlines inside 30 days", () => {
  const now = new Date("2026-08-13T12:00:00Z").getTime();
  assert.equal(countVehicleAlerts([
    { next_service_date: "2026-08-20" },
    { warranty_expires: "2026-09-30" },
    { next_service_date: "2026-08-01" },
  ], now, 30), 2);
});
