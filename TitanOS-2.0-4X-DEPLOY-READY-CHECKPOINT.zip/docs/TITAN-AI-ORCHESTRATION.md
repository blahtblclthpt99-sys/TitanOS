# TitanAI Orchestration

TitanOS now uses a hybrid planner.

Known/high-confidence commands continue through deterministic planning. Ambiguous or open-ended commands can use TitanAI through Vercel AI Gateway.

Pipeline:

Unified input -> hybrid planner -> validated structured plan -> Action Engine -> approval policy -> trusted server execution -> durable run -> memory/context.

AI plans are schema-validated before they enter the Action Engine. High/critical actions are forced to require approval. If AI planning fails or returns invalid structure, Titan falls back to a non-consequential `titan.reason` plan and does not execute anything.

This preserves the invisible-interface experience without making the model itself the execution authority.
