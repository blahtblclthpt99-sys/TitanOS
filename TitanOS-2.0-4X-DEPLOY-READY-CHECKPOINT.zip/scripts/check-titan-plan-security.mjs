
import fs from"node:fs";import path from"node:path";
const files=[];
function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(/\.(js|jsx|ts|tsx)$/.test(e.name))files.push(p)}}
walk("src");walk("api");
const violations=[];
for(const f of files){
 const s=fs.readFileSync(f,"utf8");
 if(/requiresApproval\s*:\s*false[\s\S]{0,180}(money\.pay|external\.apply|documents\.sign|messages\.send)/.test(s))
  violations.push(`${f}: critical tool appears near requiresApproval=false`);
 if(/risk\s*:\s*["']low["'][\s\S]{0,180}(money\.pay|external\.apply|documents\.sign|messages\.send)/.test(s))
  violations.push(`${f}: critical tool appears near low risk`);
 if(/api\.functions\.invoke\(\s*["']executeTitanAction["']/.test(s)&&!f.endsWith("src/lib/titanServerExecutionApi.js"))
  violations.push(`${f}: direct executeTitanAction invocation outside canonical bridge`);
}
if(violations.length){console.error(violations.join("\n"));process.exit(1)}
console.log(`Titan plan-security audit passed (${files.length} source files scanned).`);
